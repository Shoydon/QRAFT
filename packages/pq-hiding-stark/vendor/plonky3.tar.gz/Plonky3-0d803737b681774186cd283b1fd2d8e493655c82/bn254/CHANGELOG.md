# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [0.8.0] - 2026-09-23
### Merged PRs
- Ci: fail on unused dependencies, and drop the ones already there (#2029)

## [0.7.0] - 2026-09-04
## [0.6.0] - 2026-06-11
### Merged PRs
- Fix(bn254): add Poseidon2 round-number constants and fix benchmark (#1557)
- Add BN254 deserialize boundary regression tests (#1583)
- Ci: tighten doc/release/TOML checks (#1689)
- Chore: update CHANGELOGs (#1785)

## [0.5.3] - 2026-05-15
## [0.5.2] - 2026-03-27
## [0.5.1] - 2026-03-16
## [0.5.0] - 2026-03-10
### Merged PRs
- Fix(bn254): use subtraction instead of multiplication for negation (#1263)
- Refactor: minor code cleanups across blake3-air, bn254, challenger (#1287)
- Deps: update rand and rand_xoshiro (#1314)
- Feat: implement PermutationMonomial<5> for Bn254 (#1346)
- Poseidon: add Rust constants for rounds (#1416)

## [0.4.2] - 2026-01-05
### Merged PRs
- Refactor: add public const `new` and `new_array` for all fields (#1222) (Adrian Hamelink)

### Authors
- Adrian Hamelink

## [0.4.1] - 2025-12-18
### Authors

## [0.4.0] - 2025-12-12
### Merged PRs
- Porting BN254 to our own code base (#913) (AngusG)
- Interleaved Montgomery Multiplication (#915) (AngusG)
- Chore: add descriptions to all sub-crate manifests (#906) (Himess)
- Custom halve impl for Bn254 (#919) (AngusG)
- From_biguint method for Bn254 (#914) (AngusG)
- Bn254 Binary Euclidean Inversion (#920) (AngusG)
- Fast GCD Inverse for Goldilocks  (#925) (AngusG)
- Adding Macros to remove boilerplate impls (#943) (AngusG)
- Adding Degree 8 extensions for KoalaBear and BabyBear. (#954) (AngusG)
- Move halve to ring (#969) (AngusG)
- Must Use (#996) (AngusG)
- Refactor: remove redundant clones in crypto modules (#1086) (Skylar Ray)
- Clippy: small step (#1102) (Thomas Coratger)
- Clippy: add nursery (#1103) (Thomas Coratger)
- Clippy: add semicolon_if_nothing_returned (#1107) (Thomas Coratger)
- Clippy: add `needless_pass_by_value` (#1112) (Thomas Coratger)
- Refactor: deduplicate field JSON serialization tests (#1162) (andrewshab)

### Authors
- AngusG
- Himess
- Skylar Ray
- Thomas Coratger
- andrewshab

