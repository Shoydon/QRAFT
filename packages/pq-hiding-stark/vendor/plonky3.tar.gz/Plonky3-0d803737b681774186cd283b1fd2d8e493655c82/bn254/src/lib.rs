//! **Deprecated since 0.9.0.** This crate is planned for removal in a future release.
//! Avoid using it in new projects.
//!
//! The scalar field of the BN254 curve, defined as `F_P` where `P = 21888242871839275222246405745257275088548364400416034343698204186575808495617`.
#![deprecated(
    since = "0.9.0",
    note = "p3-bn254 is planned for removal in a future release."
)]
#![no_std]

extern crate alloc;

mod bn254;
mod helpers;
mod poseidon2;

pub use bn254::*;
pub use poseidon2::{
    BN254_POSEIDON2_HALF_FULL_ROUNDS, BN254_POSEIDON2_PARTIAL_ROUNDS_3, BN254_S_BOX_DEGREE,
    Poseidon2Bn254,
};
