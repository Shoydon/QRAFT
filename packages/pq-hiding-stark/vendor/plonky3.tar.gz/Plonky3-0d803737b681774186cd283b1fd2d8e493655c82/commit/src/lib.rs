#![doc = include_str!("../README.md")]
#![no_std]

extern crate alloc;

mod adapters;
mod domain;
mod encoder;
mod mmcs;
mod pcs;
mod periodic;

#[cfg(any(test, feature = "test-utils"))]
pub mod testing;

pub use adapters::*;
pub use domain::*;
pub use encoder::*;
pub use mmcs::*;
pub use pcs::*;
pub use periodic::*;
