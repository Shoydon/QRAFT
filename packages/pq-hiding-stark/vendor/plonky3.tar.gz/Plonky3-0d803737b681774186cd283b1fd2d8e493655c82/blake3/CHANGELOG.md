# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [0.8.0] - 2026-09-23
### Merged PRs
- Optimize Goldilocks and wasm-simd128 primitives (#2116)
- Perf(blake3): hash a batch of messages through one SIMD compression (#2151)

## [0.7.0] - 2026-09-04
## [0.6.0] - 2026-06-11
### Merged PRs
- Ci: tighten doc/release/TOML checks (#1689)
- Chore: update CHANGELOGs (#1785)

## [0.5.3] - 2026-05-15
## [0.5.2] - 2026-03-27
## [0.5.1] - 2026-03-16
## [0.5.0] - 2026-03-10
## [0.4.2] - 2026-01-05
### Authors

## [0.4.1] - 2025-12-18
### Authors

## [0.4.0] - 2025-12-12
### Merged PRs
- Chore: add descriptions to all sub-crate manifests (#906) (Himess)
- Clippy: small step (#1102) (Thomas Coratger)

### Authors
- Himess
- Thomas Coratger

