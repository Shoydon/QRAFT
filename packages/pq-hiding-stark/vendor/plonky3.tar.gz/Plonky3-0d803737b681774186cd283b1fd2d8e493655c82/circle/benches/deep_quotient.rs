use std::hint::black_box;
use std::time::Duration;

use criterion::{BenchmarkId, Criterion, criterion_group, criterion_main};
use p3_circle::Point;
use p3_field::{
    ExtensionField, PackedFieldExtension, PrimeCharacteristicRing, batch_multiplicative_inverse,
};
use p3_matrix::Matrix;
use p3_matrix::dense::RowMajorMatrix;
use p3_maybe_rayon::prelude::*;
use p3_mersenne_31::{Mersenne31, QM31};
use rand::rngs::SmallRng;
use rand::{RngExt, SeedableRng};

type F = Mersenne31;
type EF = QM31;

/// The points of `CircleDomain::standard(log_n)` in natural order.
///
/// `CircleDomain::points` is crate-private, so this spells out the same interleaved cosets.
fn domain_points(log_n: usize) -> Vec<Point<F>> {
    let generator = Point::generator(log_n - 1);
    let mut coset_0 = Point::generator(log_n + 1);
    let mut coset_1 = generator - coset_0;
    let mut points = Vec::with_capacity(1 << log_n);
    for _ in 0..1 << (log_n - 1) {
        points.push(coset_0);
        points.push(coset_1);
        coset_0 += generator;
        coset_1 += generator;
    }
    points
}

/// Baseline that keeps `re` and `im` and inverts `re^2 + im^2` without the circle identity.
fn unfactored_geometry(points: &[Point<F>], zeta: Point<EF>) -> (Vec<EF>, Vec<EF>, Vec<EF>) {
    let (re, im): (Vec<_>, Vec<_>) = points.iter().map(|&point| point.v_p(zeta)).unzip();
    let denoms = re
        .iter()
        .zip(&im)
        .map(|(&re, &im)| re.square() + im.square())
        .collect::<Vec<_>>();
    (re, im, batch_multiplicative_inverse(&denoms))
}

/// Serial copy of the crate-private `compute_vanishing_parts`, which stores `im / (2 re)`.
fn factored_geometry(points: &[Point<F>], zeta: Point<EF>) -> Vec<EF> {
    let (re, im): (Vec<_>, Vec<_>) = points.iter().map(|&point| point.v_p(zeta)).unzip();
    let denoms = re.iter().map(|re| re.double()).collect::<Vec<_>>();
    let denom_inv = batch_multiplicative_inverse(&denoms);
    im.into_iter()
        .zip(denom_inv)
        .map(|(im, denom_inv)| im * denom_inv)
        .collect()
}

/// Baseline accumulation over the `re`, `im` and `1 / (re^2 + im^2)` from `unfactored_geometry`.
#[allow(clippy::too_many_arguments)]
fn unfactored_accumulate(
    ro: &mut [EF],
    alpha_offset: EF,
    alpha_pow_width: EF,
    reduced_rows: &[EF],
    re: &[EF],
    im: &[EF],
    denom_inv: &[EF],
    reduced_at_zeta: EF,
) {
    for ((((ro, &row), &re), &im), &denom_inv) in ro
        .iter_mut()
        .zip(reduced_rows)
        .zip(re)
        .zip(im)
        .zip(denom_inv)
    {
        *ro += alpha_offset * (re - alpha_pow_width * im) * denom_inv * (row - reduced_at_zeta);
    }
}

/// Serial copy of the crate-private `accumulate_deep_quotient`.
fn factored_accumulate(
    ro: &mut [EF],
    alpha_offset: EF,
    alpha_pow_width: EF,
    reduced_rows: &[EF],
    im_over_twice_re: &[EF],
    reduced_at_zeta: EF,
) {
    let alpha_offset_over_two = alpha_offset.halve();
    let alpha_offset_alpha_pow_width = alpha_offset * alpha_pow_width;
    for ((ro, &row), &im_over_twice_re) in ro.iter_mut().zip(reduced_rows).zip(im_over_twice_re) {
        *ro += (alpha_offset_over_two - alpha_offset_alpha_pow_width * im_over_twice_re)
            * (row - reduced_at_zeta);
    }
}

fn bench_deep_quotient(c: &mut Criterion) {
    let points = domain_points(18);
    let zeta = Point::<EF>::from_projective_line(EF::from_u8(9));
    let alpha_offset = EF::from_u8(7);
    let alpha_pow_width = EF::from_u8(11);
    let reduced_at_zeta = EF::from_u8(13);
    let reduced_rows = (0..points.len())
        .map(|i| EF::from_u64(i as u64 + 1))
        .collect::<Vec<_>>();
    let (re, im, denom_inv) = unfactored_geometry(&points, zeta);
    let im_over_twice_re = factored_geometry(&points, zeta);

    let mut group = c.benchmark_group("circle/deep_quotient/log_n=18");
    group.bench_function("geometry/unfactored", |b| {
        b.iter(|| black_box(unfactored_geometry(black_box(&points), black_box(zeta))));
    });
    group.bench_function("geometry/factored", |b| {
        b.iter(|| black_box(factored_geometry(black_box(&points), black_box(zeta))));
    });

    let mut unfactored_ro = EF::zero_vec(points.len());
    group.bench_function("accumulate/unfactored", |b| {
        b.iter(|| {
            unfactored_accumulate(
                black_box(&mut unfactored_ro),
                alpha_offset,
                alpha_pow_width,
                black_box(&reduced_rows),
                black_box(&re),
                black_box(&im),
                black_box(&denom_inv),
                reduced_at_zeta,
            );
            black_box(&unfactored_ro);
        });
    });

    let mut factored_ro = EF::zero_vec(points.len());
    group.bench_function("accumulate/factored", |b| {
        b.iter(|| {
            factored_accumulate(
                black_box(&mut factored_ro),
                alpha_offset,
                alpha_pow_width,
                black_box(&reduced_rows),
                black_box(&im_over_twice_re),
                reduced_at_zeta,
            );
            black_box(&factored_ro);
        });
    });
    group.finish();
}

/// Include the production matrix traversal in the DEEP quotient measurement.
/// The geometry-only cases above receive already reduced rows and miss the packed dots.
fn bench_deep_quotient_matrix(c: &mut Criterion) {
    const LOG_ROWS: usize = 14;
    let points = domain_points(LOG_ROWS);
    let mut rng = SmallRng::seed_from_u64(1);
    let zeta = Point::<EF>::from_projective_line(rng.random());
    let im_over_twice_re = factored_geometry(&points, zeta);
    let alpha = rng.random::<EF>();
    let mut group = c.benchmark_group("circle/deep_quotient/matrix/log_n=14");
    for width in [16, 64, 256] {
        let matrix = RowMajorMatrix::<F>::rand_nonzero(&mut rng, 1 << LOG_ROWS, width);
        let powers =
            <EF as ExtensionField<F>>::ExtensionPacking::packed_ext_powers_capped(alpha, width)
                .collect::<Vec<_>>();
        let alpha_pow_width = alpha.exp_u64(width as u64);
        group.bench_with_input(
            BenchmarkId::new("alpha_reduce_and_accumulate", width),
            &matrix,
            |b, matrix| {
                b.iter(|| {
                    let reduced_rows = black_box(matrix)
                        .rowwise_packed_dot_product::<EF>(black_box(&powers))
                        .collect::<Vec<_>>();
                    let mut ro = EF::zero_vec(reduced_rows.len());
                    factored_accumulate(
                        &mut ro,
                        alpha,
                        alpha_pow_width,
                        &reduced_rows,
                        &im_over_twice_re,
                        EF::from_u8(13),
                    );
                    black_box(ro)
                });
            },
        );
    }
    group.finish();
}

criterion_group! {
    name = deep_quotient;
    config = Criterion::default()
        .sample_size(10)
        .warm_up_time(Duration::from_secs(1))
        .measurement_time(Duration::from_secs(2));
    targets = bench_deep_quotient, bench_deep_quotient_matrix
}
criterion_main!(deep_quotient);
