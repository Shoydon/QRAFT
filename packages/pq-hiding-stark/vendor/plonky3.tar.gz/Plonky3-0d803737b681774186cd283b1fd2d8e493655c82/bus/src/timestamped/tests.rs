use alloc::string::String;
use alloc::vec;
use alloc::vec::Vec;
use core::num::NonZeroUsize;
use std::collections::HashMap;
use std::panic::{AssertUnwindSafe, catch_unwind};
use std::sync::OnceLock;

use p3_air::symbolic::AirLayout;
use p3_air::{Air, BaseAir, WindowAccess, check_constraints};
use p3_binary_field::{BinaryField32, BinaryField64, BinaryField128};
use p3_field::{Field, PrimeCharacteristicRing};
use p3_matrix::dense::RowMajorMatrix;
use p3_multilinear_util::point::Point;
use p3_sumcheck::layout::Table;
use proptest::prelude::*;
use rand::rngs::SmallRng;
use rand::{RngExt, SeedableRng};

use super::*;
use crate::{BusDebugInstance, BusDebugReport, BusPlanInput, BusSymbolicBuilder};

/// Bus field.
type F = BinaryField128;

/// Clock field, whose generator ticks the clock.
type C = BinaryField64;

/// Memory under test.
type Memory = TimestampedMemory<C, F>;

/// Channel carrying the memory tuples.
const MEMORY: &str = "tm-memory";

/// Read-only table of low gap factors.
const LOW: &str = "tm-low";

/// Read-only table of high gap factors.
const HIGH: &str = "tm-high";

/// Accesses one row of the machine makes.
const SLOTS: usize = 2;

/// Rows of the machine table.
const ROWS: usize = 4;

/// Cells of the memory, one boundary row each.
const CELLS: usize = 8;

/// Columns of one access: address, previous, old, new, then two range reads of three.
const SLOT_WIDTH: usize = 10;

/// Builds the memory under test, with one value component per cell.
fn memory() -> Memory {
    Memory::new(MEMORY, LOW, HIGH, 1).expect("the fixture names are valid")
}

/// A distinguishable stored value, zero for tag zero.
fn value(tag: u128) -> F {
    F::from_le_bytes(tag.to_le_bytes())
}

/// The clock at exponent `exponent`, which is `g^exponent`.
fn time(exponent: u64) -> F {
    Memory::tick().exp_u64(exponent)
}

/// Address of cell `cell`.
fn cell(cell: usize) -> F {
    TimestampedBoundaryAir::<C, F>::cell_address(cell)
}

/// One access as the attack tests see it, before range counts are assigned.
#[derive(Clone, Debug)]
struct Access {
    /// Cell address.
    address: F,
    /// Time of the last access to that cell.
    previous: F,
    /// Value the last access left.
    old: F,
    /// Value this access leaves.
    new: F,
    /// Low range factor.
    low: F,
    /// High range factor.
    high: F,
}

impl Access {
    /// A padding access, which sits at time zero and reads the smallest range entries.
    fn padding() -> Self {
        Self {
            address: cell(0),
            previous: F::ZERO,
            old: F::ZERO,
            new: F::ZERO,
            low: ClockRangeAir::<C, F>::low(0),
            high: ClockRangeAir::<C, F>::high(0),
        }
    }
}

/// One machine row: its clock and one access per slot.
#[derive(Clone, Debug)]
struct Row {
    /// Clock of the row, zero on padding.
    clock: F,
    /// Accesses in slot order.
    slots: [Access; SLOTS],
}

/// Every table's contents before range counts are assigned.
#[derive(Clone, Debug)]
struct Witness {
    /// Machine rows.
    rows: Vec<Row>,
    /// Starting value of every cell, in cell order.
    starts: Vec<F>,
    /// Last time and final value of every cell, in cell order.
    closes: Vec<(F, F)>,
}

/// One logical operation: a cell and an optional written value.
type Op = (usize, Option<u128>);

/// Runs a program honestly from all-zero cells, padding the machine table to `ROWS`.
///
/// Each entry is a clock exponent and one operation per slot.
fn run(program: &[(u64, [Op; SLOTS])]) -> Witness {
    run_from(&[F::ZERO; CELLS], program)
}

/// Runs a program honestly from the given starting values.
fn run_from(starts: &[F], program: &[(u64, [Op; SLOTS])]) -> Witness {
    // Every cell starts at time `g^0` holding its starting value.
    let mut state = starts
        .iter()
        .map(|&start| (0u64, start))
        .collect::<Vec<_>>();
    let mut rows = Vec::new();
    for &(clock, ops) in program {
        let slots = core::array::from_fn(|slot| {
            let (target, write) = ops[slot];
            let now = clock + slot as u64;
            let (last, old) = state[target];
            let new = write.map_or(old, value);
            let (low, high) = Memory::gap_factors(now - last).expect("the fixture gaps fit");
            state[target] = (now, new);
            Access {
                address: cell(target),
                previous: time(last),
                old,
                new,
                low,
                high,
            }
        });
        rows.push(Row {
            clock: time(clock),
            slots,
        });
    }
    while rows.len() < ROWS {
        rows.push(Row {
            clock: F::ZERO,
            slots: core::array::from_fn(|_| Access::padding()),
        });
    }
    let closes = state
        .iter()
        .map(|&(last, final_value)| (time(last), final_value))
        .collect();
    Witness {
        rows,
        starts: starts.to_vec(),
        closes,
    }
}

/// The issue's example on cell 5, with two slots per row and one wide gap.
///
/// ```text
///     row 0  clock g^4      write 5 := 7        read 2
///     row 1  clock g^9      read 5              write 5 := 3
///     row 2  clock g^2^20   read 2              write 7 := 9
///     row 3  padding
/// ```
fn honest() -> Witness {
    run(&[
        (4, [(5, Some(7)), (2, None)]),
        (9, [(5, None), (5, Some(3))]),
        (1 << 20, [(2, None), (7, Some(9))]),
    ])
}

/// Stand-in for a machine table making `SLOTS` accesses per row.
struct MachineAir {
    /// Memory the accesses go to.
    memory: Memory,
}

impl<F2> BaseAir<F2> for MachineAir {
    fn width(&self) -> usize {
        1 + SLOTS * SLOT_WIDTH
    }
}

impl<AB: BusInteractionBuilder<F = F>> Air<AB> for MachineAir {
    fn eval(&self, builder: &mut AB) {
        let row: Vec<AB::Expr> = {
            let main = builder.main();
            main.current_slice().iter().map(|&v| v.into()).collect()
        };
        for slot in 0..SLOTS {
            let c = &row[1 + slot * SLOT_WIDTH..1 + (slot + 1) * SLOT_WIDTH];
            let read = |offset: usize| RangeRead {
                value: c[offset].clone(),
                count: c[offset + 1].clone(),
                count_inverse: c[offset + 2].clone(),
            };
            let access = TimestampedAccess {
                address: c[0].clone(),
                previous: c[1].clone(),
                old: vec![c[2].clone()],
                new: vec![c[3].clone()],
                gap: ClockGap {
                    low: read(4),
                    high: read(7),
                },
            };
            builder.timestamped_access(&self.memory, row[0].clone(), slot, access);
        }
    }
}

/// Concrete traces of the three tables.
struct Traces {
    /// Machine table.
    machine: RowMajorMatrix<F>,
    /// Seed and close block.
    boundary: RowMajorMatrix<F>,
    /// Both range tables.
    range: RowMajorMatrix<F>,
}

/// The entries of one range table, in row order and indexed by value.
struct RangeColumn {
    /// Entry on each row.
    entries: Vec<F>,
    /// Row of each entry.
    rows: HashMap<F, usize>,
}

impl RangeColumn {
    /// The geometric column `first * step^row`, one product per row.
    fn geometric(first: F, step: F) -> Self {
        let height = ClockRangeAir::<C, F>::HEIGHT;
        let entries = core::iter::successors(Some(first), |&entry| Some(entry * step))
            .take(height)
            .collect::<Vec<_>>();
        let rows = entries
            .iter()
            .enumerate()
            .map(|(row, &entry)| (entry, row))
            .collect();
        Self { entries, rows }
    }
}

/// Both range tables, built once and shared by every test.
///
/// Each has `2^16` rows.
///
/// Rebuilding them on every check, one exponentiation per entry, would dominate the suite.
fn range_columns() -> &'static (RangeColumn, RangeColumn) {
    static COLUMNS: OnceLock<(RangeColumn, RangeColumn)> = OnceLock::new();
    COLUMNS.get_or_init(|| {
        // Consecutive rows differ by one fixed factor in both tables.
        //
        //     low(row)   =  g^(row + 1)        =  low(0)  * low(0)^row
        //     high(row)  =  step^row           =  high(0) * high(1)^row
        let low =
            RangeColumn::geometric(ClockRangeAir::<C, F>::low(0), ClockRangeAir::<C, F>::low(0));
        let high = RangeColumn::geometric(
            ClockRangeAir::<C, F>::high(0),
            ClockRangeAir::<C, F>::high(1),
        );

        // The products must land on the closed forms, checked at the last row.
        let last = ClockRangeAir::<C, F>::HEIGHT - 1;
        assert_eq!(low.entries[last], ClockRangeAir::<C, F>::low(last));
        assert_eq!(high.entries[last], ClockRangeAir::<C, F>::high(last));
        (low, high)
    })
}

/// Assigns read-only counts and lays out every table, for a block with this seed.
fn traces(witness: &Witness, seed: &TimestampedSeed<F>) -> Traces {
    let height = ClockRangeAir::<C, F>::HEIGHT;
    let (low_column, high_column) = range_columns();
    let (low_index, high_index) = (&low_column.rows, &high_column.rows);
    let mut low_reads = vec![0u64; height];
    let mut high_reads = vec![0u64; height];

    // The k-th read of an entry holds count `G^k`; a forged factor reads no entry.
    let count = |reads: &mut [u64], index: &HashMap<F, usize>, factor: F| {
        index.get(&factor).map_or(F::ONE, |&row| {
            let count = F::GENERATOR.exp_u64(reads[row]);
            reads[row] += 1;
            count
        })
    };

    let mut machine = Vec::new();
    for row in &witness.rows {
        machine.push(row.clock);
        for access in &row.slots {
            let low = count(&mut low_reads, low_index, access.low);
            let high = count(&mut high_reads, high_index, access.high);
            machine.extend([
                access.address,
                access.previous,
                access.old,
                access.new,
                access.low,
                low,
                low.inverse(),
                access.high,
                high,
                high.inverse(),
            ]);
        }
    }

    // A private block commits the starting value after the final one.
    let private = matches!(seed, TimestampedSeed::Private(_));
    let boundary = witness
        .closes
        .iter()
        .zip(&witness.starts)
        .enumerate()
        .flat_map(|(row, (&(last, final_value), &start))| {
            [cell(row), last, final_value]
                .into_iter()
                .chain(private.then_some(start))
        })
        .collect();

    let range = (0..height)
        .flat_map(|row| {
            [
                low_column.entries[row],
                F::GENERATOR.exp_u64(low_reads[row]),
                high_column.entries[row],
                F::GENERATOR.exp_u64(high_reads[row]),
            ]
        })
        .collect();

    Traces {
        machine: RowMajorMatrix::new(machine, 1 + SLOTS * SLOT_WIDTH),
        boundary: RowMajorMatrix::new(boundary, if private { 4 } else { 3 }),
        range: RowMajorMatrix::new(range, 4),
    }
}

/// Column-major view of a trace, as the bus replay reads it.
fn table(trace: &RowMajorMatrix<F>) -> Table<F> {
    let (height, width) = (trace.values.len() / trace.width, trace.width);
    let columns = (0..width)
        .flat_map(|column| (0..height).map(move |row| trace.values[row * width + column]))
        .collect();
    Table::new(RowMajorMatrix::new(columns, height))
}

/// The three AIRs under test, with a zero seed.
fn airs() -> (
    MachineAir,
    TimestampedBoundaryAir<C, F>,
    ClockRangeAir<C, F>,
) {
    airs_with(TimestampedSeed::Zero)
}

/// The three AIRs under test, with a given seed.
fn airs_with(
    seed: TimestampedSeed<F>,
) -> (
    MachineAir,
    TimestampedBoundaryAir<C, F>,
    ClockRangeAir<C, F>,
) {
    (
        MachineAir { memory: memory() },
        TimestampedBoundaryAir::new(memory(), seed).expect("the fixture seed fits"),
        ClockRangeAir::new(memory()),
    )
}

/// Symbolic declarations of one AIR.
fn profile<A>(air: &A) -> BusSymbolicBuilder<F, F>
where
    A: BaseAir<F> + Air<BusSymbolicBuilder<F, F>>,
{
    BusSymbolicBuilder::from_air(air, AirLayout::from_air::<F>(air))
}

/// Whether every table satisfies its constraints, with a zero seed.
fn constraints_hold(witness: &Witness) -> bool {
    constraints_hold_with(witness, TimestampedSeed::Zero)
}

/// Whether every table satisfies its constraints, with a given seed.
fn constraints_hold_with(witness: &Witness, seed: TimestampedSeed<F>) -> bool {
    let traces = traces(witness, &seed);
    let (machine, boundary, range) = airs_with(seed);
    catch_unwind(AssertUnwindSafe(|| {
        check_constraints(&machine, &traces.machine, &[]);
        check_constraints(&boundary, &traces.boundary, &[]);
        check_constraints(&range, &traces.range, &[]);
    }))
    .is_ok()
}

/// Names of the buses that do not balance, sorted, with a zero seed.
fn unbalanced(witness: &Witness) -> Vec<String> {
    unbalanced_with(witness, TimestampedSeed::Zero)
}

/// Names of the buses that do not balance, sorted, with a given seed.
fn unbalanced_with(witness: &Witness, seed: TimestampedSeed<F>) -> Vec<String> {
    let traces = traces(witness, &seed);
    let (machine, boundary, range) = airs_with(seed);
    let profiles = [profile(&machine), profile(&boundary), profile(&range)];
    let tables = [
        table(&traces.machine),
        table(&traces.boundary),
        table(&traces.range),
    ];

    // The replay reads a public image as the boundary block's periodic columns.
    let periodic = boundary.periodic_columns();
    let periodic = (!periodic.is_empty()).then(|| {
        let values = (0..CELLS)
            .flat_map(|row| periodic.iter().map(move |column| column[row]))
            .collect();
        table(&RowMajorMatrix::new(values, periodic.len()))
    });
    let mut instances = tables
        .iter()
        .zip(&profiles)
        .map(|(table, profile)| {
            BusDebugInstance::new(table, None, &[], profile).expect("the fixture matches")
        })
        .collect::<Vec<_>>();
    if let Some(periodic) = &periodic {
        instances[1] = instances[1].with_periodic(periodic);
    }
    let mut names = BusDebugReport::check(&instances)
        .expect("the fixture declarations are well formed")
        .buses
        .into_iter()
        .map(|bus| bus.bus_name)
        .collect::<Vec<_>>();
    names.sort();
    names
}

/// Plan of the three tables at their given heights.
fn plan(log_machine: usize) -> BusPlan {
    let (machine, boundary, range) = airs();
    let profiles = [profile(&machine), profile(&boundary), profile(&range)];
    let heights = [
        log_machine,
        CELLS.trailing_zeros() as usize,
        CLOCK_RANGE_BITS,
    ];
    let inputs = profiles
        .iter()
        .zip(heights)
        .map(|(profile, log_height)| BusPlanInput {
            log_height,
            interactions: profile.interactions(),
        })
        .collect::<Vec<_>>();
    BusPlan::build(&inputs)
        .expect("the fixture uses a valid bus shape")
        .expect("the fixture declares tuples")
}

#[test]
fn an_honest_run_balances_every_bus() {
    let witness = honest();

    // Row 1 touches cell 5 in both slots, so slot times must differ.
    assert_eq!(witness.rows[1].slots[1].previous, time(9));

    // The close of cell 5 is the write in slot 1 of row 1.
    assert_eq!(witness.closes[5], (time(10), value(3)));

    assert!(constraints_hold(&witness));
    assert!(unbalanced(&witness).is_empty());
}

#[test]
fn a_stale_read_leaves_the_memory_unbalanced() {
    let mut witness = honest();

    // The read of cell 5 at `g^9` claims the seed's zero instead of the write's 7.
    let read = &mut witness.rows[1].slots[0];
    read.previous = time(0);
    read.old = F::ZERO;
    read.new = F::ZERO;
    (read.low, read.high) = Memory::gap_factors(9).unwrap();

    // The gap is honest, so only the memory bus can catch it.
    assert!(constraints_hold(&witness));
    assert_eq!(unbalanced(&witness), [MEMORY]);
}

#[test]
fn a_forged_load_leaves_the_memory_unbalanced() {
    let mut witness = honest();

    // The read of cell 5 at `g^9` returns 42, which no access ever wrote.
    let read = &mut witness.rows[1].slots[0];
    read.old = value(42);
    read.new = value(42);

    assert!(constraints_hold(&witness));
    assert_eq!(unbalanced(&witness), [MEMORY]);
}

#[test]
fn a_gap_of_zero_leaves_a_range_table_unbalanced() {
    let mut witness = honest();

    // A real row at `g^20` claims any value of untouched cell 3 in both slots.
    //
    // Each access pulls what it pushes, so the memory bus stays balanced.
    witness.rows[3].clock = time(20);
    for (slot, access) in witness.rows[3].slots.iter_mut().enumerate() {
        let now = time(20 + slot as u64);
        *access = Access {
            address: cell(3),
            previous: now,
            old: value(42),
            new: value(42),
            // `lo = hi` satisfies the gap equation, and `g` sits only in the low table.
            low: Memory::tick(),
            high: Memory::tick(),
        };
    }

    assert!(constraints_hold(&witness));
    assert_eq!(unbalanced(&witness), [HIGH]);
}

#[test]
fn a_padding_row_touching_a_real_cell_leaves_a_range_table_unbalanced() {
    let mut witness = honest();

    // Padding pulls the last tuple of cell 5 and pushes it back at time zero.
    //
    // The close of cell 5 then pulls that zero-time tuple, so the memory bus balances.
    witness.rows[3].slots[0] = Access {
        address: cell(5),
        previous: time(10),
        old: value(3),
        new: value(3),
        // With `now = 0` the gap equation forces `lo = 0`, which no table holds.
        low: F::ZERO,
        high: F::ONE,
    };
    witness.closes[5] = (F::ZERO, value(3));

    assert!(constraints_hold(&witness));
    assert_eq!(unbalanced(&witness), [LOW]);
}

#[test]
fn the_range_table_pins_its_height() {
    let (_, _, range) = airs();

    // Dropping the last entry leaves `g^(2^16 - 1)` on the last row.
    let full = traces(&honest(), &TimestampedSeed::Zero).range;
    let shorter = RowMajorMatrix::new(full.values[..full.values.len() / 2].to_vec(), 4);
    assert!(
        catch_unwind(AssertUnwindSafe(|| check_constraints(
            &range,
            &shorter,
            &[]
        )))
        .is_err()
    );
}

#[test]
fn gap_factors_cover_exactly_one_to_two_to_the_thirty_two() {
    // Both ends of the range, and a gap crossing a digit boundary.
    for gap in [
        1,
        2,
        1 << CLOCK_RANGE_BITS,
        (1 << CLOCK_RANGE_BITS) + 1,
        1 << CLOCK_GAP_BITS,
    ] {
        let (low, high) = Memory::gap_factors(gap).unwrap();
        assert_eq!(time(1) * low, time(1 + gap) * high, "gap {gap}");
    }

    // A zero gap or one past the top has no factors.
    assert_eq!(Memory::gap_factors(0), None);
    assert_eq!(Memory::gap_factors((1 << CLOCK_GAP_BITS) + 1), None);
}

#[test]
fn checked_gap_digits_keep_both_range_indices() {
    for (gap, low, high) in [
        (1, 0, 0),
        (65_536, 65_535, 0),
        (65_537, 0, 1),
        (4_294_967_296, 65_535, 65_535),
    ] {
        let digits = ClockGapDigits::new(gap).unwrap();
        assert_eq!((digits.low(), digits.high()), (low, high));
        let (lo, hi) = digits.factors::<C, F>();
        assert_eq!(time(7) * lo, time(7 + gap) * hi);
        assert_eq!(Some((lo, hi)), Memory::gap_factors(gap));
    }
    for gap in [0, 4_294_967_297, u64::MAX] {
        assert_eq!(ClockGapDigits::new(gap), None);
    }
}

#[test]
fn range_witness_counts_shared_slots_and_padding() {
    let mut witness = ClockRangeWitness::<C, F>::new();
    let generator = F::GENERATOR;
    // Two slots per row, then two padding slots using the smallest factors.
    let gaps = [[1, 65_536], [65_537, 4_294_967_296], [1, 1]];
    let expected_counts = [
        [(F::ONE, F::ONE), (F::ONE, generator)],
        [(generator, F::ONE), (generator, F::ONE)],
        [
            (generator.square(), generator.square()),
            (generator.exp_u64(3), generator.exp_u64(3)),
        ],
    ];
    for (row, expected) in gaps.into_iter().zip(expected_counts) {
        for (gap, (low_count, high_count)) in row.into_iter().zip(expected) {
            let read = witness.read(ClockGapDigits::new(gap).unwrap());
            let factors = match gap {
                1 => (time(1), F::ONE),
                65_536 => (time(65_536), F::ONE),
                65_537 => (time(1), time(65_536).inverse()),
                4_294_967_296 => (time(65_536), time(4_294_901_760).inverse()),
                _ => unreachable!(),
            };
            assert_eq!((read.low.value, read.high.value), factors);
            for (read, expected) in [(read.low, low_count), (read.high, high_count)] {
                assert_eq!(read.count, expected);
                assert_eq!(read.count * read.count_inverse, F::ONE);
            }
        }
    }
    let [low, low_final, high, high_final] = witness.into_columns();
    assert_eq!(
        [low.len(), low_final.len(), high.len(), high_final.len()],
        [65_536; 4]
    );
    for row in [0, 1, 7, 65_535] {
        assert_eq!(low[row], time(row as u64 + 1));
        assert_eq!(high[row], time(65_536).inverse().exp_u64(row as u64));
    }
    assert_eq!(low_final[0], generator.exp_u64(4));
    assert_eq!(low_final[65_535], generator.square());
    assert_eq!(high_final[0], generator.exp_u64(4));
    assert_eq!(high_final[1], generator);
    assert_eq!(high_final[65_535], generator);
    assert_eq!((low_final[7], high_final[7]), (F::ONE, F::ONE));
}

#[test]
fn the_handle_refuses_what_it_cannot_prove() {
    // One channel in two roles would let their tuples cancel.
    assert_eq!(
        Memory::new(MEMORY, MEMORY, HIGH, 1),
        Err(TimestampedMemoryError::DuplicateBus {
            name: MEMORY.into()
        })
    );

    // A cell must carry a value.
    assert_eq!(
        Memory::new(MEMORY, LOW, HIGH, 0),
        Err(TimestampedMemoryError::EmptyValue)
    );

    // A 32-bit clock has order `2^32 - 1`, so a gap of `2^32 - 1` would be zero.
    assert_eq!(
        TimestampedMemory::<BinaryField32, F>::new(MEMORY, LOW, HIGH, 1),
        Err(TimestampedMemoryError::ClockOrbitTooShort {
            orbit_bits: 32,
            minimum_bits: 33
        })
    );

    // A 64-bit bus field is too small for the read-only range lookups.
    assert!(matches!(
        TimestampedMemory::<C, C>::new(MEMORY, LOW, HIGH, 1),
        Err(TimestampedMemoryError::RangeTable(_))
    ));
}

#[test]
fn the_plan_check_bounds_the_accesses() {
    let memory = memory();

    // A small machine fits, and its term is the plan's own.
    let small = plan(ROWS.trailing_zeros() as usize);
    let field_bits = NonZeroUsize::new(128).unwrap();
    assert_eq!(
        memory.security_term::<F>(&small),
        Ok(small.security_term(field_bits))
    );

    // The plan charges every range read, seed and close as a leaf.
    //
    // Pushes: per access one memory tuple and two range reads, per cell one seed, per entry two seeds.
    let accesses = ROWS * SLOTS;
    let range = 2 * ClockRangeAir::<C, F>::HEIGHT;
    assert_eq!(
        small.security_geometry().non_padding_leaf_counts(),
        [3 * accesses + CELLS + range, 3 * accesses + CELLS + range]
    );

    // At `2^32` rows a forged cycle could climb the whole 64-bit orbit.
    let large = plan(32);
    assert!(matches!(
        memory.check_against(&large),
        Err(TimestampedMemoryError::TooManyAccesses { .. })
    ));

    // A memory of a different value width does not fit this plan.
    let wide = Memory::new(MEMORY, LOW, HIGH, 2).unwrap();
    assert_eq!(
        wide.check_against(&small),
        Err(TimestampedMemoryError::PayloadWidth {
            name: MEMORY.into(),
            expected: 4,
            actual: 3
        })
    );
}

/// The public image under test: cell 2 holds 11, cells 5 and 6 hold 7 and 9.
fn image() -> PublicImage<F> {
    PublicImage::new(
        &memory(),
        CELLS.trailing_zeros() as usize,
        vec![(2, vec![value(11)]), (5, vec![value(7), value(9)])],
    )
    .expect("the fixture runs fit")
}

#[test]
fn public_image_periodic_rows_read_runs_and_gaps_without_materializing_columns() {
    let wide_memory = Memory::new(MEMORY, LOW, HIGH, 2).unwrap();
    let image = PublicImage::new(
        &wide_memory,
        3,
        vec![
            (1, vec![value(11), value(12), value(21), value(22)]),
            (5, vec![value(51), value(52)]),
            (7, vec![value(71), value(72)]),
        ],
    )
    .unwrap();
    let boundary =
        TimestampedBoundaryAir::new(wide_memory, TimestampedSeed::Public(image)).unwrap();
    let expected = [
        [0, 0],
        [11, 12],
        [21, 22],
        [0, 0],
        [0, 0],
        [51, 52],
        [0, 0],
        [71, 72],
    ];

    super::image::COLUMN_MATERIALIZATIONS.with(|count| count.set(0));
    for row in 0..16 {
        assert_eq!(boundary.periodic_values(row), expected[row % 8].map(value));
    }
    for runs in [vec![], vec![(0, vec![value(4)])]] {
        let expected = if runs.is_empty() { F::ZERO } else { value(4) };
        let image = PublicImage::new(&memory(), 0, runs).unwrap();
        let boundary =
            TimestampedBoundaryAir::new(memory(), TimestampedSeed::Public(image)).unwrap();
        assert_eq!(boundary.periodic_values(usize::MAX), [expected]);
    }
    for seed in [
        TimestampedSeed::Zero,
        TimestampedSeed::Private(PrivateRegion::new(0, 3).unwrap()),
    ] {
        let boundary = TimestampedBoundaryAir::new(memory(), seed).unwrap();
        assert!(boundary.periodic_values(0).is_empty());
    }
    super::image::COLUMN_MATERIALIZATIONS.with(|count| assert_eq!(count.get(), 0));
}

#[test]
fn public_image_diagnostics_materialize_only_for_shape_validation() {
    use p3_air::check_all_constraints;

    let boundary = TimestampedBoundaryAir::new(memory(), TimestampedSeed::Public(image())).unwrap();
    let trace = RowMajorMatrix::new(
        (0..CELLS)
            .flat_map(|row| [cell(row), time(0), F::ZERO])
            .collect(),
        3,
    );

    super::image::COLUMN_MATERIALIZATIONS.with(|count| count.set(0));
    check_constraints(&boundary, &trace, &[]);
    super::image::COLUMN_MATERIALIZATIONS.with(|count| assert_eq!(count.get(), 1));

    super::image::COLUMN_MATERIALIZATIONS.with(|count| count.set(0));
    assert!(check_all_constraints(&boundary, &trace, &[], None).is_ok());
    super::image::COLUMN_MATERIALIZATIONS.with(|count| assert_eq!(count.get(), 1));

    let mut forged = trace.clone();
    forged.values[3 * 3] += F::ONE;
    let report = check_all_constraints(&boundary, &forged, &[], None);
    assert_eq!(
        report
            .failures
            .iter()
            .map(|failure| (failure.row, failure.constraint))
            .collect::<Vec<_>>(),
        [(2, 1), (3, 1)]
    );
    let panic = catch_unwind(AssertUnwindSafe(|| {
        check_constraints(&boundary, &forged, &[]);
    }))
    .unwrap_err();
    let message = panic.downcast_ref::<String>().unwrap();
    assert!(message.contains("row 2"), "{message}");

    // Sparse row lookup must not bypass the full column-period validation.
    let short = RowMajorMatrix::new(trace.values[..4 * 3].to_vec(), 3);
    assert!(
        catch_unwind(AssertUnwindSafe(|| check_constraints(
            &boundary,
            &short,
            &[]
        )))
        .is_err()
    );
    assert!(
        catch_unwind(AssertUnwindSafe(|| {
            check_all_constraints(&boundary, &short, &[], None)
        }))
        .is_err()
    );
}

/// A program reading the three image words, then overwriting one.
const IMAGE_PROGRAM: [(u64, [Op; SLOTS]); 2] =
    [(4, [(5, None), (2, None)]), (9, [(6, None), (5, Some(3))])];

#[test]
fn a_public_image_seeds_its_words() {
    // The prover starts from the image the verifier holds.
    let seed = TimestampedSeed::Public(image());
    let witness = run_from(&image().columns()[0], &IMAGE_PROGRAM);
    assert_eq!(witness.rows[0].slots[0].old, value(7));

    assert!(constraints_hold_with(&witness, seed.clone()));
    assert!(unbalanced_with(&witness, seed).is_empty());
}

#[test]
fn a_wrong_public_word_leaves_the_memory_unbalanced() {
    // The prover claims cell 5 started as 5, while the image says 7.
    let mut starts = image().columns().remove(0);
    starts[5] = value(5);
    let witness = run_from(&starts, &IMAGE_PROGRAM);

    // Nothing committed carries the image, so only the memory bus can catch it.
    let seed = TimestampedSeed::Public(image());
    assert!(constraints_hold_with(&witness, seed.clone()));
    assert_eq!(unbalanced_with(&witness, seed), [MEMORY]);
}

#[test]
fn a_seeded_block_pins_its_height() {
    let seed = TimestampedSeed::Private(PrivateRegion::new(0, 3).unwrap());
    let (_, boundary, _) = airs_with(seed.clone());
    let full = traces(&run(&[]), &seed).boundary;
    check_constraints(&boundary, &full, &[]);

    // Dropping the last four cells ends the block before the region does.
    let shorter = RowMajorMatrix::new(full.values[..full.values.len() / 2].to_vec(), 4);
    assert!(
        catch_unwind(AssertUnwindSafe(|| check_constraints(
            &boundary,
            &shorter,
            &[]
        )))
        .is_err()
    );
}

#[test]
fn a_private_region_may_end_at_the_last_machine_word() {
    // A single cell at the top index is its own first and last cell.
    let top = PrivateRegion::new(usize::MAX, 0).unwrap();
    assert_eq!(top.last_cell(), usize::MAX);

    // The widest region ending at the top index.
    let log_cells = usize::BITS as usize - 1;
    let first_cell = usize::MAX - ((1 << log_cells) - 1);
    let widest = PrivateRegion::new(first_cell, log_cells).unwrap();
    assert_eq!(widest.last_cell(), usize::MAX);

    // One cell further would end past the top index.
    assert_eq!(PrivateRegion::new(usize::MAX, 1), None);
    assert_eq!(PrivateRegion::new(first_cell + 1, log_cells), None);

    // A region of `2^BITS` cells cannot be counted in a machine word.
    assert_eq!(PrivateRegion::new(0, usize::BITS as usize), None);
}

#[test]
fn a_public_image_refuses_malformed_runs() {
    let log_cells = CELLS.trailing_zeros() as usize;
    let image = |runs| PublicImage::new(&memory(), log_cells, runs);

    // An empty run holds no word.
    assert_eq!(
        image(vec![(0, vec![])]),
        Err(TimestampedMemoryError::ImageRunWidth {
            run: 0,
            len: 0,
            value_width: 1
        })
    );

    // A run starting inside the previous one would give a cell two starting words.
    assert_eq!(
        image(vec![(2, vec![value(1), value(2)]), (3, vec![value(3)])]),
        Err(TimestampedMemoryError::OverlappingImageRuns { run: 1 })
    );

    // A run ending past the last cell names a cell outside the block.
    assert_eq!(
        image(vec![(7, vec![value(1), value(2)])]),
        Err(TimestampedMemoryError::ImageRunOutOfRange {
            run: 0,
            cells: CELLS
        })
    );

    // An image of two-component words does not fit a one-component memory.
    let wide = Memory::new(MEMORY, LOW, HIGH, 2).unwrap();
    let words = PublicImage::new(&wide, log_cells, vec![(0, vec![value(1), value(2)])]).unwrap();
    assert_eq!(
        TimestampedBoundaryAir::new(memory(), TimestampedSeed::Public(words)),
        Err(TimestampedMemoryError::ImageWidth {
            expected: 1,
            actual: 2
        })
    );
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(4))]

    #[test]
    fn a_private_region_accepts_any_start_and_binds_every_read_to_it(
        starts in prop::collection::vec(any::<u128>(), CELLS),
        forged in 1u128..,
    ) {
        let seed = TimestampedSeed::Private(PrivateRegion::new(0, 3).unwrap());
        let starts = starts.into_iter().map(value).collect::<Vec<_>>();

        // Any committed starting values balance an honest run from them.
        let witness = run_from(&starts, &IMAGE_PROGRAM);
        prop_assert!(constraints_hold_with(&witness, seed.clone()));
        prop_assert!(unbalanced_with(&witness, seed.clone()).is_empty());

        // The first read of cell 2 returns something other than its committed start.
        let mut witness = witness;
        let read = &mut witness.rows[0].slots[1];
        read.old += value(forged);
        read.new = read.old;
        prop_assert!(constraints_hold_with(&witness, seed.clone()));
        prop_assert_eq!(unbalanced_with(&witness, seed), [MEMORY]);
    }

    #[test]
    fn the_sparse_image_evaluation_matches_the_dense_column(
        log_cells in 0usize..7,
        value_width in 1usize..3,
        runs in prop::collection::vec((0usize..6, 1usize..10), 0..5),
        seed in any::<u64>(),
    ) {
        // Lay the runs out left to right, with gaps between them, clipped to the image.
        let cells = 1usize << log_cells;
        let mut rng = SmallRng::seed_from_u64(seed);
        let mut next = 0;
        let mut layout = Vec::new();
        for (gap, len) in runs {
            let start = next + gap;
            let len = len.min(cells.saturating_sub(start));
            if len == 0 {
                break;
            }
            let words = (0..len * value_width).map(|_| rng.random::<F>()).collect();
            layout.push((start, words));
            next = start + len;
        }
        let memory = Memory::new(MEMORY, LOW, HIGH, value_width).unwrap();
        let image = PublicImage::new(&memory, log_cells, layout).unwrap();

        // The dense reference sums every cell, zero or not.
        let point = (0..log_cells).map(|_| rng.random::<F>()).collect::<Vec<_>>();
        let weights = Point::new(point.as_slice()).equality_weights_msb();
        let dense = image
            .columns()
            .iter()
            .map(|column| column.iter().zip(&weights).map(|(&v, &w)| v * w).sum::<F>())
            .collect::<Vec<_>>();
        prop_assert_eq!(image.evaluate(&point), dense);
    }
}

#[test]
fn a_second_boundary_over_an_image_cell_lets_a_read_skip_the_image_word() {
    // Invariant: every bus balances, so only the boundary check refuses two blocks over one cell.
    //
    //     image block     seed (a, g^0, image word)    close (a, g^0, image word)   untouched
    //     private block   seed (a, g^0, forged word)   close (a, last, final)       carries the run
    //
    // Two blocks seed the same eight cells: the public image, and a private region the prover fills.
    let public = TimestampedSeed::Public(image());
    let private = TimestampedSeed::Private(PrivateRegion::new(0, 3).unwrap());
    let image_starts = image().columns().remove(0);

    // The private starts copy the image except cell 5, which holds 5 where the image says 7.
    let mut forged = image_starts.clone();
    forged[5] = value(5);
    let witness = run_from(&forged, &IMAGE_PROGRAM);
    assert_eq!(witness.rows[0].slots[0].old, value(5));

    // The private block carries the run, and the image block closes every cell untouched at `g^0`.
    let run = traces(&witness, &private);
    let untouched = Witness {
        rows: witness.rows,
        starts: image_starts.clone(),
        closes: image_starts.iter().map(|&start| (time(0), start)).collect(),
    };
    let shadow = traces(&untouched, &public);
    let machine = MachineAir { memory: memory() };
    let public_air = TimestampedBoundaryAir::new(memory(), public).unwrap();
    let private_air = TimestampedBoundaryAir::new(memory(), private).unwrap();
    let range = ClockRangeAir::new(memory());

    // Every table holds its constraints and every bus balances, so only the boundary check is left.
    check_constraints(&machine, &run.machine, &[]);
    check_constraints(&private_air, &run.boundary, &[]);
    check_constraints(&public_air, &shadow.boundary, &[]);
    check_constraints(&range, &run.range, &[]);
    let profiles = [
        profile(&machine),
        profile(&public_air),
        profile(&private_air),
        profile(&range),
    ];
    let tables = [
        table(&run.machine),
        table(&shadow.boundary),
        table(&run.boundary),
        table(&run.range),
    ];
    let periodic = public_air.periodic_columns();
    let values = (0..CELLS)
        .flat_map(|row| periodic.iter().map(move |column| column[row]))
        .collect();
    let periodic = table(&RowMajorMatrix::new(values, periodic.len()));
    let mut instances = tables
        .iter()
        .zip(&profiles)
        .map(|(table, profile)| BusDebugInstance::new(table, None, &[], profile).unwrap())
        .collect::<Vec<_>>();
    instances[1] = instances[1].with_periodic(&periodic);
    assert!(BusDebugReport::check(&instances).unwrap().buses.is_empty());

    let log_cells = CELLS.trailing_zeros() as usize;
    assert_eq!(
        memory().check_boundaries(&[(&public_air, log_cells), (&private_air, log_cells)]),
        Err(TimestampedMemoryError::OverlappingBoundaries { cell: 0 })
    );
}

#[test]
fn the_boundary_check_accepts_disjoint_blocks_and_names_the_first_shared_cell() {
    // Invariant: blocks pass exactly when their cell spans are disjoint.
    //
    //     image 0..=7      region 8..=11    ->  disjoint   ->  accepted
    //     zero  0..=3      region 4..=7     ->  disjoint   ->  accepted
    //     zero  0..=7      region 4..=7     ->  cell 4     ->  refused
    //     image 0..=7      region 4..=7     ->  cell 4     ->  refused
    let block = |seed| TimestampedBoundaryAir::new(memory(), seed).unwrap();
    let image = block(TimestampedSeed::Public(image()));
    let zero = block(TimestampedSeed::Zero);
    let above = block(TimestampedSeed::Private(PrivateRegion::new(8, 2).unwrap()));
    let inside = block(TimestampedSeed::Private(PrivateRegion::new(4, 2).unwrap()));

    // The image covers cells 0 to 7, so a region from cell 8 on is disjoint from it.
    assert_eq!(
        memory().check_boundaries(&[(&image, 3), (&above, 2)]),
        Ok(())
    );
    assert_eq!(
        memory().check_boundaries(&[(&above, 2), (&image, 3)]),
        Ok(())
    );

    // A zero seed covers one cell per row, so its height decides where it ends.
    assert_eq!(
        memory().check_boundaries(&[(&zero, 2), (&inside, 2)]),
        Ok(())
    );
    assert_eq!(
        memory().check_boundaries(&[(&zero, 3), (&inside, 2)]),
        Err(TimestampedMemoryError::OverlappingBoundaries { cell: 4 })
    );
    assert_eq!(
        memory().check_boundaries(&[(&image, 3), (&inside, 2)]),
        Err(TimestampedMemoryError::OverlappingBoundaries { cell: 4 })
    );
}

#[test]
fn the_boundary_check_refuses_a_block_of_another_memory() {
    // Invariant: a block counts only toward the memory it seeds.
    let other = Memory::new("tm-other", LOW, HIGH, 1).unwrap();
    let foreign = TimestampedBoundaryAir::new(other, TimestampedSeed::Zero).unwrap();
    assert_eq!(
        memory().check_boundaries(&[(&foreign, 3)]),
        Err(TimestampedMemoryError::ForeignBoundary { block: 0 })
    );
}
