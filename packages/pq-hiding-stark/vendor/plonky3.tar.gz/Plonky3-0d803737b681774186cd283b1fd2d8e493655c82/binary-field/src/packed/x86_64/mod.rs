//! The packings over the wide carryless multiply, `VPCLMULQDQ` on 256- and 512-bit registers.

mod ghash128;
pub(crate) mod lanes;
// Scalar extension elements times weights, read in place where a 512-bit multiply exists.
#[cfg(target_feature = "avx512f")]
pub(crate) mod mixed_dot;
// Sums of products pair their terms where a 512-bit multiply exists.
#[cfg(all(
    target_feature = "avx512f",
    not(all(feature = "wide-poly", target_feature = "avx512bw"))
))]
pub(crate) mod pairs;

pub use ghash128::PackedGhash128;
