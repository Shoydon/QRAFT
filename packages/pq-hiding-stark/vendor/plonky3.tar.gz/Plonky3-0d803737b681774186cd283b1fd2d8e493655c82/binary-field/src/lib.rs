#![doc = include_str!("../README.md")]
#![no_std]

extern crate alloc;

mod aes;
mod bitslice;
pub mod byteslice;
mod cantor;
mod challenger;
mod clmul;
mod coordinates;
mod extension;
mod fold_rows;
mod gf2;
mod ghash;
mod linear;
mod packed;
mod poly192;
mod poly64;
pub mod poly_basis;
mod poly_slice;
mod subfield;
mod tables;
mod tower;
mod transcript;
mod unreduced;

pub use aes::{
    ByteMatrix, LinearizedPoly8b, PackedRijndael8b, Rijndael8b, RijndaelPowerAccumulator,
};
pub use bitslice::{
    Divisible, M128, M256, M512, PackedGf2, PackedGf2x8, PackedGf2x16, PackedGf2x32, PackedGf2x64,
    PackedGf2x128, PackedGf2x256, PackedGf2x512, Underlier, Word, transpose_8x8,
};
pub use challenger::BinaryChallenger;
pub use coordinates::BitCoordinates;
pub use fold_rows::fold_rows;
pub use gf2::Gf2;
pub use ghash::Ghash128;
#[cfg(any(
    all(
        target_arch = "x86_64",
        target_feature = "vpclmulqdq",
        any(target_feature = "avx2", target_feature = "avx512f")
    ),
    all(
        target_arch = "aarch64",
        target_endian = "little",
        target_feature = "aes"
    )
))]
pub use packed::PackedGhash128;
#[cfg(any(
    all(
        target_arch = "x86_64",
        target_feature = "vpclmulqdq",
        any(target_feature = "avx2", target_feature = "avx512f")
    ),
    all(
        target_arch = "aarch64",
        target_endian = "little",
        target_feature = "aes"
    )
))]
pub use packed::{PackedPoly64, PackedPoly192, PackedPoly192Unreduced};
pub use poly64::Poly64;
pub use poly192::{Poly192, Poly192MixedAccumulator};
pub use tower::{
    BinaryField2, BinaryField4, BinaryField8, BinaryField16, BinaryField32, BinaryField64,
    BinaryField128, TowerLevel,
};
pub use unreduced::Poly192Unreduced;
