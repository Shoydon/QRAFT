#[path = "common/config.rs"]
mod config;

use core::borrow::Borrow;
use core::fmt::Debug;
use core::slice::from_ref;
use std::borrow::Cow;

use config::{
    Challenge, CircleChallenge, CircleConfig, CircleVal, MyConfig, MyConfigWide, MyHidingConfig,
    Val, make_circle_config, make_config, make_config_allow_tiny_trace, make_config_wide,
    make_config_zk, make_two_adic_compat_config,
};
use p3_air::{
    Air, AirBuilder, BaseAir, NextRowTrace, PermutationAirBuilder, SymbolicExpression, WindowAccess,
};
use p3_batch_stark::proof::{BatchProof, OpenedValuesWithLookups};
use p3_batch_stark::verifier::commitments_with_opening_points;
use p3_batch_stark::{
    BatchShape, BatchTranscriptFailure, BatchVerificationError, ProverData, ProvingError,
    StarkGenericConfig, StarkInstance, VerificationError, prove_batch, verify_batch,
};
use p3_challenger::testing::pow_difficulties;
use p3_field::{Field, PrimeCharacteristicRing, PrimeField64, TwoAdicField};
use p3_fri::{FriParameters, FriShape, PcsShape};
use p3_lookup::{
    Count, InteractionBuilder, LookupError, LookupTerminal, Lookups, SymbolicInteraction,
};
use p3_matrix::Matrix;
use p3_matrix::dense::RowMajorMatrix;
use p3_security::grinding::{GrindingBudget, GrindingSites, RecordedGrind};
use p3_uni_stark::{InvalidProofShapeError, OpeningShape, PeriodicColumnShapeError};
use p3_util::log2_strict_usize;

const TWO_ADIC_FIXTURE: &str = "tests/fixtures/batch_stark_two_adic_v0_8_0.postcard";
const CIRCLE_FIXTURE: &str = "tests/fixtures/batch_stark_circle_v0_8_0.postcard";

// --- Simple Fibonacci AIR and trace ---

#[derive(Debug, Clone, Copy)]
struct FibonacciAir {
    /// log2 of the trace height; used to size preprocessed columns.
    log_height: usize,
    /// Index to tamper with in preprocessed trace (None = no tampering).
    tamper_index: Option<usize>,
}

impl<F: Field> BaseAir<F> for FibonacciAir {
    fn width(&self) -> usize {
        2
    }

    fn num_public_values(&self) -> usize {
        3
    }

    fn preprocessed_trace(&self) -> Option<RowMajorMatrix<F>> {
        let n = 1 << self.log_height;
        let mut m = RowMajorMatrix::new(F::zero_vec(n), 1);
        for (i, v) in m.values.iter_mut().enumerate().take(n) {
            *v = F::from_u64(i as u64);
        }
        if let Some(idx) = self.tamper_index
            && idx < n
        {
            m.values[idx] += F::ONE;
        }
        Some(m)
    }

    fn preprocessed_width(&self) -> usize {
        1
    }
}

impl<AB: AirBuilder> Air<AB> for FibonacciAir
where
    AB::F: Field,
{
    fn eval(&self, builder: &mut AB) {
        let main = builder.main();
        let pis = builder.public_values();
        let a0 = pis[0];
        let b0 = pis[1];
        let x = pis[2];

        let local: &FibRow<AB::Var> = main.current_slice().borrow();
        let next: &FibRow<AB::Var> = main.next_slice().borrow();

        let mut wf = builder.when_first_row();
        wf.assert_eq(local.left, a0);
        wf.assert_eq(local.right, b0);

        let mut wt = builder.when_transition();
        wt.assert_eq(local.right, next.left);
        wt.assert_eq(local.left + local.right, next.right);

        builder.when_last_row().assert_eq(local.right, x);
    }
}

#[derive(Clone, Copy, Debug)]
struct FibRow<F> {
    left: F,
    right: F,
}
impl<F> Borrow<FibRow<F>> for [F] {
    fn borrow(&self) -> &FibRow<F> {
        debug_assert_eq!(self.len(), 2);
        let (prefix, shorts, suffix) = unsafe { self.align_to::<FibRow<F>>() };
        debug_assert!(prefix.is_empty());
        debug_assert!(suffix.is_empty());
        debug_assert_eq!(shorts.len(), 1);
        &shorts[0]
    }
}

fn fib_trace<F: PrimeField64>(a: u64, b: u64, n: usize) -> RowMajorMatrix<F> {
    assert!(n.is_power_of_two());
    let mut trace = RowMajorMatrix::new(F::zero_vec(n * 2), 2);
    let (prefix, rows, suffix) = unsafe { trace.values.align_to_mut::<FibRow<F>>() };
    assert!(prefix.is_empty() && suffix.is_empty());
    rows[0] = FibRow {
        left: F::from_u64(a),
        right: F::from_u64(b),
    };
    for i in 1..n {
        rows[i] = FibRow {
            left: rows[i - 1].right,
            right: rows[i - 1].left + rows[i - 1].right,
        };
    }
    trace
}

fn fib_n(n: usize) -> u64 {
    fib_n_from(0, 1, n)
}

fn fib_n_from(a0: u64, b0: u64, n: usize) -> u64 {
    let mut a = a0;
    let mut b = b0;
    for _ in 0..n {
        let t = a + b;
        a = b;
        b = t;
    }
    a
}

// --- Simple multiplication AIR and trace ---
// The AIR has 3 * `reps` columns:
// - for each rep, 3 columns: `a`, `b`, `c` where we enforce `a * b = c`
// - an extra column at the end which is a permutation of the first `a` column (used for local lookups in `MulAirLookups`)

#[derive(Debug, Clone, Copy)]
struct MulAir {
    reps: usize,
}
impl Default for MulAir {
    fn default() -> Self {
        Self { reps: 2 }
    }
}
impl<F> BaseAir<F> for MulAir {
    fn width(&self) -> usize {
        self.reps * 3 + 1
    }
}
impl<AB: AirBuilder> Air<AB> for MulAir {
    fn eval(&self, builder: &mut AB) {
        let main = builder.main();
        let local = main.current_slice();
        let next = main.next_slice();
        for i in 0..self.reps {
            let s = i * 3;
            let a = local[s];
            let b = local[s + 1];
            let c = local[s + 2];
            builder.assert_eq(a * b, c);

            builder.when_transition().assert_eq(b, next[s]);
            builder.when_transition().assert_eq(a + b, next[s + 1]);
        }
    }
}

#[derive(Clone)]
struct PeriodicAir<F> {
    periodic: Vec<Vec<F>>,
}

impl<F: Field + PrimeCharacteristicRing> PeriodicAir<F> {
    fn new() -> Self {
        Self {
            periodic: vec![
                vec![
                    F::from_u64(1),
                    F::from_u64(2),
                    F::from_u64(3),
                    F::from_u64(4),
                ],
                vec![F::from_u64(10), F::from_u64(20)],
            ],
        }
    }

    fn valid_trace(&self, rows: usize) -> RowMajorMatrix<F> {
        let mut values = F::zero_vec(rows * 2);
        for (i, row) in values.as_chunks_mut::<2>().0.iter_mut().enumerate() {
            row[0] = self.periodic[0][i % self.periodic[0].len()];
            row[1] = self.periodic[1][i % self.periodic[1].len()];
        }
        RowMajorMatrix::new(values, 2)
    }
}

impl<F: Field> BaseAir<F> for PeriodicAir<F> {
    fn width(&self) -> usize {
        2
    }

    fn num_periodic_columns(&self) -> usize {
        self.periodic.len()
    }

    fn periodic_columns(&self) -> Cow<'_, [Vec<F>]> {
        Cow::Borrowed(&self.periodic)
    }
}

impl<AB: AirBuilder> Air<AB> for PeriodicAir<AB::F>
where
    AB::F: Field,
{
    fn eval(&self, builder: &mut AB) {
        let main = builder.main();
        let local = main.current_slice();
        let p0 = builder.periodic_values()[0].into();
        let p1 = builder.periodic_values()[1].into();
        builder.assert_eq(local[0], p0);
        builder.assert_eq(local[1], p1);
    }
}

// --- MulAirLookups structure for local and global lookups ---
// This AIR is a `MulAir` that can register global lookups with `FibAirLookups`, as well as local lookups with a lookup column. Its inputs are the Fibonacci values.
// - when `is_local` is true, this AIR creates local lookups between its first column and its last column.
//   The latter corresponds to a permutation of the first column:
//     - it receives the first column with multiplicity 1
//     - it sends the last column (permuted values) with multiplicity 1
// - when `is_global` is true, this AIR creates global lookups between its inputs and `FibAirLookups` AIR's inputs:
//     - For each `rep`, it sends its first two columns (a,b) to the global lookup with name `global_names[rep]` and multiplicity 1
// - `num_lookups` tracks the number of registered lookups. It is 0 when the structure is created,
//   and increments every time a new lookup is registered.
#[derive(Clone, Default)]
struct MulAirLookups {
    air: MulAir,
    is_local: bool,
    is_global: bool,
    global_names: Vec<String>,
}

impl MulAirLookups {
    const fn new(air: MulAir, is_local: bool, is_global: bool, global_names: Vec<String>) -> Self {
        Self {
            air,
            is_local,
            is_global,
            global_names,
        }
    }
}

impl<F> BaseAir<F> for MulAirLookups {
    fn width(&self) -> usize {
        <MulAir as BaseAir<F>>::width(&self.air)
    }
}

impl<AB> Air<AB> for MulAirLookups
where
    AB::Var: Debug,
    AB: AirBuilder + PermutationAirBuilder + InteractionBuilder,
{
    fn eval(&self, builder: &mut AB) {
        self.air.eval(builder);

        // Cross-AIR and intra-AIR interactions.
        let main = builder.main();
        let local = main.current_slice();
        let last_idx = <Self as BaseAir<AB::F>>::width(self) - 1;
        let lut = local[last_idx]; // Extra column: permutation of 'a'

        for rep in 0..self.air.reps {
            let base_idx = rep * 3;
            let a = local[base_idx];
            let b = local[base_idx + 1];

            // Local lookup: 'a' against the permuted column.
            if self.is_local {
                builder.push_local_interaction(vec![
                    (vec![a.into()], Count::bounded(AB::Expr::ONE, 1)), // query (receive)
                    (vec![lut.into()], Count::provided(-AB::Expr::ONE)), // table (send, negated)
                ]);
            }

            // Global lookup: send (a, b) to FibAirLookups.
            if self.is_global {
                // Send = one message per row, so a constant count of -1.
                builder.push_interaction(&self.global_names[rep], [a.into(), b.into()], -1);
            }
        }
    }
}

fn mul_trace<F: Field>(rows: usize, reps: usize) -> RowMajorMatrix<F> {
    assert!(rows.is_power_of_two());
    // The extra column corresponds to a permutation of the first column.
    let w = reps * 3 + 1;
    let mut v = F::zero_vec(rows * w);
    let last_idx = w - 1;

    for rep in 0..reps {
        let mut a = F::ZERO;
        let mut b = F::ONE;
        for i in 0..rows {
            let idx = i * w + rep * 3;
            v[idx] = a;
            v[idx + 1] = b;
            v[idx + 2] = v[idx] * v[idx + 1];
            if i != rows - 1 {
                v[i * w + last_idx] = b;
            }
            let tmp = a + b;
            a = b;
            b = tmp;
        }
    }
    RowMajorMatrix::new(v, w)
}

// --- FibAirLookups structure for global lookups ---
// This AIR is a `FibonacciAir` that can register global lookups with `MulAir` AIRs.
// - when `is_global` is true, this AIR creates global lookups between its inputs and MulAir AIR's inputs:
//     - it receives its two columns (left,right) from the global lookup with name `name_and_mult.0`
//       and multiplicity `name_and_mult.1`. The default for `name_and_mult` is ("MulFib", 2).
// - `num_lookups` tracks the number of registered lookups. It is 0 when the structure is created,
//    and increments every time a new lookup is registered.
// - `name_and_mult` is used when `is_global` is true. If provided, it specifies the name and multiplicity of the global lookup.
//   If not provided and `is_global` is true, a default name "MulFib" and multiplicity 2 is used.
#[derive(Debug, Clone)]
struct FibAirLookups {
    air: FibonacciAir,
    is_global: bool,
    name_and_mult: Option<(String, u64)>,
}

impl Default for FibAirLookups {
    fn default() -> Self {
        Self {
            air: FibonacciAir {
                log_height: 3,
                tamper_index: None,
            },
            is_global: false,
            name_and_mult: None,
        }
    }
}

impl FibAirLookups {
    const fn new(air: FibonacciAir, is_global: bool, name_and_mult: Option<(String, u64)>) -> Self {
        Self {
            air,
            is_global,
            name_and_mult,
        }
    }
}

impl<F: Field> BaseAir<F> for FibAirLookups {
    fn width(&self) -> usize {
        <FibonacciAir as BaseAir<F>>::width(&self.air)
    }

    fn num_public_values(&self) -> usize {
        <FibonacciAir as BaseAir<F>>::num_public_values(&self.air)
    }

    fn preprocessed_trace(&self) -> Option<RowMajorMatrix<F>> {
        self.air.preprocessed_trace()
    }

    fn preprocessed_width(&self) -> usize {
        <FibonacciAir as BaseAir<F>>::preprocessed_width(&self.air)
    }
}

impl<AB: PermutationAirBuilder + InteractionBuilder> Air<AB> for FibAirLookups {
    fn eval(&self, builder: &mut AB) {
        self.air.eval(builder);

        // Global interaction — receive (left, right) from MulAirLookups.
        if self.is_global {
            let main = builder.main();
            let left = main.current(0).unwrap();
            let right = main.current(1).unwrap();

            let (name, multiplicity) = match &self.name_and_mult {
                Some((n, m)) => (n.clone(), *m),
                None => ("MulFib".to_string(), 2),
            };

            // Receive = positive count (counterpart to MulAirLookups' negative send).
            //
            // Each active row receives `multiplicity` copies, so that constant is also
            // the per-row magnitude bound feeding the height check.
            builder.push_interaction(
                &name,
                [left.into(), right.into()],
                Count::bounded(AB::Expr::from_u64(multiplicity), multiplicity as u32),
            );
        }
    }
}

// --- Preprocessed multiplication AIR and trace ---

#[derive(Debug, Clone, Copy)]
struct PreprocessedMulAir {
    /// log2 of the trace height; used to size preprocessed columns.
    log_height: usize,
    /// Multiplier to use in constraint (2 for correct, 3 for incorrect test).
    multiplier: u64,
}

impl<F: Field> BaseAir<F> for PreprocessedMulAir {
    fn width(&self) -> usize {
        1
    }

    fn preprocessed_trace(&self) -> Option<RowMajorMatrix<F>> {
        let n = 1 << self.log_height;
        let mut m = RowMajorMatrix::new(F::zero_vec(n), 1);
        for (i, v) in m.values.iter_mut().enumerate().take(n) {
            *v = F::from_u64(i as u64);
        }
        Some(m)
    }

    fn preprocessed_width(&self) -> usize {
        1
    }

    fn preprocessed_next_row_columns(&self) -> Vec<usize> {
        vec![]
    }
}

impl<AB> Air<AB> for PreprocessedMulAir
where
    AB: AirBuilder,
    AB::F: Field,
{
    fn eval(&self, builder: &mut AB) {
        let main = builder.main();
        let local_main = main.current_slice();

        // Copy the preprocessed value so the immutable borrow on `builder`
        // is released before the mutable `assert_eq` call.
        let prep_val = builder.preprocessed().current(0).unwrap();

        // Enforce: main[0] = multiplier * preprocessed[0]
        builder.assert_eq(
            local_main[0],
            prep_val * AB::Expr::from_u64(self.multiplier),
        );
    }
}

fn preprocessed_mul_trace<F: Field>(rows: usize, multiplier: u64) -> RowMajorMatrix<F> {
    assert!(rows.is_power_of_two());
    let mut v = F::zero_vec(rows);
    // main[0] = multiplier * preprocessed[0], where preprocessed[0] = row_index
    for (i, val) in v.iter_mut().enumerate() {
        *val = F::from_u64(i as u64 * multiplier);
    }
    RowMajorMatrix::new(v, 1)
}

// Heterogeneous enum wrapper for batching
#[derive(Clone, Copy)]
enum DemoAir {
    Fib(FibonacciAir),
    Mul(MulAir),
    PreprocessedMul(PreprocessedMulAir),
}
impl<F: PrimeField64> BaseAir<F> for DemoAir {
    fn width(&self) -> usize {
        match self {
            Self::Fib(a) => <FibonacciAir as BaseAir<F>>::width(a),
            Self::Mul(a) => <MulAir as BaseAir<F>>::width(a),
            Self::PreprocessedMul(a) => <PreprocessedMulAir as BaseAir<F>>::width(a),
        }
    }

    fn num_public_values(&self) -> usize {
        match self {
            Self::Fib(a) => <FibonacciAir as BaseAir<F>>::num_public_values(a),
            Self::Mul(a) => <MulAir as BaseAir<F>>::num_public_values(a),
            Self::PreprocessedMul(a) => <PreprocessedMulAir as BaseAir<F>>::num_public_values(a),
        }
    }

    fn preprocessed_trace(&self) -> Option<RowMajorMatrix<F>> {
        match self {
            Self::Fib(a) => <FibonacciAir as BaseAir<F>>::preprocessed_trace(a),
            Self::Mul(_) => None,
            Self::PreprocessedMul(a) => <PreprocessedMulAir as BaseAir<F>>::preprocessed_trace(a),
        }
    }

    fn preprocessed_width(&self) -> usize {
        match self {
            Self::Fib(a) => <FibonacciAir as BaseAir<F>>::preprocessed_width(a),
            Self::Mul(a) => <MulAir as BaseAir<F>>::preprocessed_width(a),
            Self::PreprocessedMul(a) => <PreprocessedMulAir as BaseAir<F>>::preprocessed_width(a),
        }
    }

    fn preprocessed_next_row_columns(&self) -> Vec<usize> {
        match self {
            Self::Fib(a) => <FibonacciAir as BaseAir<F>>::preprocessed_next_row_columns(a),
            Self::Mul(a) => <MulAir as BaseAir<F>>::preprocessed_next_row_columns(a),
            Self::PreprocessedMul(a) => {
                <PreprocessedMulAir as BaseAir<F>>::preprocessed_next_row_columns(a)
            }
        }
    }
}

// Heterogeneous enum wrapper for lookup-enabled AIRs
// `FibLookups` receives its inputs from `MulAirLookups` AIRs
// (see `FibAirLookups` and `MulAirLookups` definitions for more details)
#[derive(Clone)]
enum DemoAirWithLookups {
    FibLookups(FibAirLookups),
    MulLookups(MulAirLookups),
}

impl<F: Field> BaseAir<F> for DemoAirWithLookups {
    fn width(&self) -> usize {
        match self {
            Self::FibLookups(a) => <FibAirLookups as BaseAir<F>>::width(a),
            Self::MulLookups(a) => <MulAirLookups as BaseAir<F>>::width(a),
        }
    }

    fn num_public_values(&self) -> usize {
        match self {
            Self::FibLookups(a) => <FibAirLookups as BaseAir<F>>::num_public_values(a),
            Self::MulLookups(a) => <MulAirLookups as BaseAir<F>>::num_public_values(a),
        }
    }

    fn preprocessed_trace(&self) -> Option<RowMajorMatrix<F>> {
        match self {
            Self::FibLookups(a) => <FibAirLookups as BaseAir<F>>::preprocessed_trace(a),
            Self::MulLookups(a) => <MulAirLookups as BaseAir<F>>::preprocessed_trace(a),
        }
    }

    fn preprocessed_width(&self) -> usize {
        match self {
            Self::FibLookups(a) => <FibAirLookups as BaseAir<F>>::preprocessed_width(a),
            Self::MulLookups(a) => <MulAirLookups as BaseAir<F>>::preprocessed_width(a),
        }
    }
}

impl<AB: PermutationAirBuilder + InteractionBuilder> Air<AB> for DemoAirWithLookups
where
    AB::Var: Debug,
{
    fn eval(&self, builder: &mut AB) {
        match self {
            Self::FibLookups(a) => <FibAirLookups as Air<AB>>::eval(a, builder),
            Self::MulLookups(a) => <MulAirLookups as Air<AB>>::eval(a, builder),
        }
    }
}

impl<AB: PermutationAirBuilder> Air<AB> for DemoAir
where
    AB::Var: Debug,
    AB::F: PrimeField64,
{
    fn eval(&self, b: &mut AB) {
        match self {
            Self::Fib(a) => a.eval(b),
            Self::Mul(a) => a.eval(b),
            Self::PreprocessedMul(a) => a.eval(b),
        }
    }
}

/// Creates a Fibonacci instance with specified log height.
fn create_fib_instance(log_height: usize) -> (DemoAir, RowMajorMatrix<Val>, Vec<Val>) {
    let n = 1 << log_height;
    let air = DemoAir::Fib(FibonacciAir {
        log_height,
        tamper_index: None,
    });
    let trace = fib_trace::<Val>(0, 1, n);
    let pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(n))];
    (air, trace, pis)
}

/// Creates a multiplication instance with specified configuration.
fn create_mul_instance(log_height: usize, reps: usize) -> (DemoAir, RowMajorMatrix<Val>, Vec<Val>) {
    let n = 1 << log_height;
    let mul = MulAir { reps };
    let air = DemoAir::Mul(mul);
    let trace = mul_trace::<Val>(n, reps);
    let pis = vec![];
    (air, trace, pis)
}

/// Creates a preprocessed multiplication instance with specified configuration.
fn create_preprocessed_mul_instance(
    log_height: usize,
    multiplier: u64,
) -> (DemoAir, RowMajorMatrix<Val>, Vec<Val>) {
    let n = 1 << log_height;
    let air = DemoAir::PreprocessedMul(PreprocessedMulAir {
        log_height,
        multiplier,
    });
    let trace = preprocessed_mul_trace::<Val>(n, multiplier);
    let pis = vec![];
    (air, trace, pis)
}

#[test]
fn test_two_instances() -> Result<(), impl Debug> {
    let config = make_config(1337);

    let (air_fib, fib_trace, fib_pis) = create_fib_instance(4); // 16 rows
    let (air_mul, mul_trace, mul_pis) = create_mul_instance(4, 2); // 16 rows, 2 reps

    let instances = vec![
        StarkInstance {
            air: &air_fib,
            trace: &fib_trace,
            public_values: fib_pis.clone(),
        },
        StarkInstance {
            air: &air_mul,
            trace: &mul_trace,
            public_values: mul_pis.clone(),
        },
    ];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    let airs = vec![air_fib, air_mul];
    let pvs = vec![fib_pis, mul_pis];
    verify_batch(&config, &airs, &proof, &pvs, common)
}

/// Showcases `p3-security`: prove a real batch sharing a LogUp bus, then
/// estimate its proven soundness with and without accounting for the lookup
/// argument. The batch config above uses toy sizes for speed, so the estimate
/// uses representative deployment-scale parameters.
#[test]
fn security_estimate_with_and_without_lookups() {
    use p3_batch_stark::security::num_batched_openings;
    use p3_security::grinding::GrindingSites;
    use p3_security::logup::{self, LOGUP_LABEL, LogUpAir};
    use p3_security::shape::{InstanceShape, StarkAirParams};
    use p3_security::stark::proven_security_report;

    // A real batch: MulAir sends (a, b) on a bus, FibAir receives it.
    let config = make_config(1337);
    let (air_fib, fib_trace, fib_pis) = create_fib_instance(4);
    let (air_mul, mul_trace, mul_pis) = create_mul_instance(4, 2);
    let instances = vec![
        StarkInstance {
            air: &air_fib,
            trace: &fib_trace,
            public_values: fib_pis.clone(),
        },
        StarkInstance {
            air: &air_mul,
            trace: &mul_trace,
            public_values: mul_pis.clone(),
        },
    ];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    verify_batch(
        &config,
        &[air_fib, air_mul],
        &proof,
        &[fib_pis, mul_pis],
        common,
    )
    .unwrap();

    // Deployment-scale FRI parameters. `security_regime()` mirrors the runtime
    // FRI config into the soundness model with no hand-copying.
    let deployment_fri: FriParameters<()> = FriParameters {
        log_blowup: 1,
        log_final_poly_len: 0,
        max_log_arity: 3,
        num_queries: 256,
        batch_proof_of_work_bits: 0,
        commit_proof_of_work_bits: 0,
        query_proof_of_work_bits: 16,
        mmcs: (),
    };
    let regime = deployment_fri.security_regime();

    // AIR shape and instance shape. The challenge field is the degree-4
    // BabyBear extension; Keccak commitments give 128-bit collision resistance;
    // the batch random-linear-combines several committed matrices into one FRI
    // instance.
    let air = StarkAirParams {
        num_constraints: 3,
        max_constraint_degree: 2,
        num_quotient_chunks: 1,
        max_combo: 2,
    };
    // A width-100 AIR that reads its own next row, committing two quotient chunks over the
    // degree-4 extension, plus eight lookup interactions on the shared bus: the count
    // `TwoAdicFriPcs::open` actually batches, not a hand-picked stand-in.
    let num_batched_functions =
        num_batched_openings(100, true, 0, false, 2, 8, 4, OpeningShape::new());
    let shape = InstanceShape {
        log_trace_length: 22,
        modulus_bits: <Challenge as Field>::bits(),
        collision_resistance: 128,
        num_batched_functions,
    };

    // The shared bus carries width-2 messages; a lookup-heavy deployment issues
    // many such interactions per row (range checks, memory, …).
    let lookups = LogUpAir {
        num_interactions: 256,
        num_interactions_per_proof: 0,
        max_message_width: 16,
    };

    // The batch grinds only inside FRI, which `regime` already carries.
    let grinding = GrindingSites::NONE;

    let without = proven_security_report(&regime, &air, &shape, &[], &grinding);
    let lookup_term =
        logup::security_term(&lookups, &shape, &grinding).expect("batch uses a LogUp bus");
    let with = proven_security_report(&regime, &air, &shape, &[lookup_term], &grinding);
    let lookup_bits = logup::fingerprint_error(&lookups, &shape).bits();

    let (wo_regime, wo_bind) = without.binding();
    let (wi_regime, wi_bind) = with.binding();
    println!(
        "batch-stark proven security @ deployment params ({}-bit field, {} committed fns):",
        shape.modulus_bits, shape.num_batched_functions
    );
    println!(
        "  without lookups: {:.1} bits (binds: {} in {wo_regime:?})",
        without.security_bits(),
        wo_bind.label
    );
    println!(
        "  with lookups:    {:.1} bits (binds: {} in {wi_regime:?})",
        with.security_bits(),
        wi_bind.label
    );
    println!("  logup fingerprint term: {lookup_bits:.1} bits");

    // The lookup argument is an extra independent soundness term: it can only
    // hold or lower the reported security, and never exceeds its own fingerprint.
    assert!(with.security_bits() <= without.security_bits());
    assert!(with.security_bits() <= lookup_bits + 1e-9);
    assert!(with.udr.terms().iter().any(|t| t.label == LOGUP_LABEL));
    // At these parameters the fingerprint sits below the lookup-free bound, so
    // accounting for lookups strictly lowers security and the term binds.
    if lookup_bits < without.security_bits() {
        assert!(with.security_bits() < without.security_bits());
        assert_eq!(with.binding().1.label, LOGUP_LABEL);
    }
}

#[test]
fn test_periodic_air() -> Result<(), impl Debug> {
    let config = make_config(42);
    let air = PeriodicAir::<Val>::new();
    let trace = air.valid_trace(1 << 6);
    let instances = vec![StarkInstance {
        air: &air,
        trace: &trace,
        public_values: vec![],
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    verify_batch(&config, &[air], &proof, &[vec![]], common)
}

#[test]
fn periodic_column_non_power_of_two_is_rejected() {
    let config = make_config(42);

    // Prover: well-formed AIR, periodic column lengths 4 and 2 over a 64-row trace.
    let good = PeriodicAir::<Val>::new();
    let trace = good.valid_trace(1 << 6);
    let instances = vec![StarkInstance {
        air: &good,
        trace: &trace,
        public_values: vec![],
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Verifier: same symbolic shape, width 2 and two periodic columns.
    // The first column now has length 3, which has no evaluation subdomain.
    //
    //     prover periods:   [4, 2]   -> verifies
    //     verifier periods: [3, 2]   -> 3 is not a power of two -> rejected
    let bad = PeriodicAir::<Val> {
        periodic: vec![
            vec![Val::from_u64(1), Val::from_u64(2), Val::from_u64(3)],
            vec![Val::from_u64(10), Val::from_u64(20)],
        ],
    };
    let result = verify_batch(&config, &[bad], &proof, &[vec![]], common);

    // The shape rule fires here exactly as it does in the single-AIR verifier.
    assert!(
        matches!(
            result,
            Err(BatchVerificationError::Verification(
                VerificationError::PeriodicColumn(PeriodicColumnShapeError::LengthNotPowerOfTwo {
                    index: 0,
                    length: 3
                })
            ))
        ),
        "expected column 0 to be reported as a non-power-of-two length, got {result:?}"
    );
}

#[test]
fn test_periodic_air_wide_period_range() -> Result<(), impl Debug> {
    let config = make_config(42);

    // A constant period-1 column alongside a period-32 column over a 64-row
    // trace: one period is smaller than every packed field width used in
    // practice, the other spans several packed row groups on all of them.
    let air = PeriodicAir::<Val> {
        periodic: vec![vec![Val::from_u64(7)], (0..32).map(Val::from_u64).collect()],
    };
    let trace = air.valid_trace(1 << 6);
    let instances = vec![StarkInstance {
        air: &air,
        trace: &trace,
        public_values: vec![],
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    verify_batch(&config, &[air], &proof, &[vec![]], common)
}

#[test]
fn test_periodic_air_tiny_quotient() -> Result<(), impl Debug> {
    let config = make_config_allow_tiny_trace(77_008);

    // A 2-row trace with period-1 and period-2 columns. The constraint degree is
    // padded to 2, so the quotient domain has size 2 here: smaller than every
    // packed field width used in practice.
    let air = PeriodicAir::<Val> {
        periodic: vec![
            vec![Val::from_u64(9)],
            vec![Val::from_u64(1), Val::from_u64(2)],
        ],
    };
    let trace = air.valid_trace(2);
    let instances = vec![StarkInstance {
        air: &air,
        trace: &trace,
        public_values: vec![],
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    verify_batch(&config, &[air], &proof, &[vec![]], common)
}

#[test]
fn hiding_budget_failure_aborts_batch_transcript() {
    let config = make_config_zk(1234);
    let air = PeriodicAir::<Val>::new();
    let trace = air.valid_trace(4);
    let instances = [StarkInstance {
        air: &air,
        trace: &trace,
        public_values: vec![],
    }];
    let data = ProverData::from_instances(&config, &instances).unwrap();
    let result = prove_batch(&config, &instances, &data);
    assert!(matches!(
        result,
        Err(p3_batch_stark::ProvingError::Pcs {
            phase: "trace commitment",
            source: p3_fri::HidingFriProverError::HidingBudgetExceeded { mask_height: 4, .. },
        })
    ));
}

#[test]
fn hiding_budget_failure_propagates_from_batch_setup() {
    let config = make_config_zk(1234);
    let (air, trace, public_values) = create_fib_instance(2);
    let instances = [StarkInstance {
        air: &air,
        trace: &trace,
        public_values,
    }];
    let result = ProverData::from_instances(&config, &instances);
    assert!(matches!(
        result,
        Err(p3_batch_stark::ProvingError::Pcs {
            phase: "preprocessing commitment",
            source: p3_fri::HidingFriProverError::HidingBudgetExceeded { mask_height: 4, .. },
        })
    ));
}

#[test]
fn test_periodic_air_zk() -> Result<(), impl Debug> {
    let config = make_config_zk(1234);
    let air = PeriodicAir::<Val>::new();
    let trace = air.valid_trace(1 << 6);
    let instances = vec![StarkInstance {
        air: &air,
        trace: &trace,
        public_values: vec![],
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    verify_batch(&config, &[air], &proof, &[vec![]], common)
}

#[test]
fn test_two_instances_zk() -> Result<(), impl Debug> {
    let config = make_config_zk(1337);

    let (air_fib, fib_trace, fib_pis) = create_fib_instance(5); // 32 rows
    let (air_mul, mul_trace, mul_pis) = create_mul_instance(5, 2); // 32 rows, 2 reps

    let instances = vec![
        StarkInstance {
            air: &air_fib,
            trace: &fib_trace,
            public_values: fib_pis.clone(),
        },
        StarkInstance {
            air: &air_mul,
            trace: &mul_trace,
            public_values: mul_pis.clone(),
        },
    ];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    let airs = vec![air_fib, air_mul];
    let pvs = vec![fib_pis, mul_pis];
    verify_batch(&config, &airs, &proof, &pvs, common)
}

#[test]
fn test_three_instances_mixed_sizes() -> Result<(), impl Debug> {
    let config = make_config(2025);

    let (air_fib16, fib16_trace, fib16_pis) = create_fib_instance(4); // 16 rows
    let (air_mul8, mul8_trace, mul8_pis) = create_mul_instance(3, 2); // 8 rows
    let (air_fib8, fib8_trace, fib8_pis) = create_fib_instance(3); // 8 rows

    let instances = vec![
        StarkInstance {
            air: &air_fib16,
            trace: &fib16_trace,
            public_values: fib16_pis.clone(),
        },
        StarkInstance {
            air: &air_mul8,
            trace: &mul8_trace,
            public_values: mul8_pis.clone(),
        },
        StarkInstance {
            air: &air_fib8,
            trace: &fib8_trace,
            public_values: fib8_pis.clone(),
        },
    ];

    let prover_data: ProverData<MyConfig> =
        ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    let airs = vec![air_fib16, air_mul8, air_fib8];
    let pvs = vec![fib16_pis, mul8_pis, fib8_pis];
    verify_batch(&config, &airs, &proof, &pvs, common)
}

#[test]
fn test_invalid_public_values_rejected() -> Result<(), Box<dyn std::error::Error>> {
    let config = make_config(7);

    let (air_fib, trace, fib_pis) = create_fib_instance(4); // 16 rows
    let correct_x = fib_n(16);

    let instances = vec![StarkInstance {
        air: &air_fib,
        trace: &trace,
        public_values: fib_pis,
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Wrong public value at verify => should reject
    let airs = vec![air_fib];
    let wrong_pvs = vec![vec![
        Val::from_u64(0),
        Val::from_u64(1),
        Val::from_u64(correct_x + 1),
    ]];
    let res = verify_batch(&config, &airs, &proof, &wrong_pvs, common);
    assert!(res.is_err(), "Should reject wrong public values");
    Ok::<_, Box<dyn std::error::Error>>(())
}

#[test]
fn test_short_public_values_rejected() -> Result<(), Box<dyn std::error::Error>> {
    let config = make_config(7);

    let (air_fib, trace, fib_pis) = create_fib_instance(4);
    let instances = vec![StarkInstance {
        air: &air_fib,
        trace: &trace,
        public_values: fib_pis,
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    let airs = vec![air_fib];
    let short_pvs = vec![vec![Val::from_u64(0), Val::from_u64(1)]];
    let err = verify_batch(&config, &airs, &proof, &short_pvs, common)
        .expect_err("Should reject short public values");
    match err {
        BatchVerificationError::Verification(VerificationError::InvalidProofShape(
            InvalidProofShapeError::PublicValuesLengthMismatch { expected, got },
        )) => {
            assert_eq!(expected, 3);
            assert_eq!(got, 2);
        }
        _ => panic!("unexpected error: {err:?}"),
    }
    Ok::<_, Box<dyn std::error::Error>>(())
}

#[test]
fn test_degree_bits_too_large_rejected() -> Result<(), Box<dyn std::error::Error>> {
    // The verifier constructs evaluation domains via `1 << degree_bits`.
    // A malicious proof can set degree_bits >= usize::BITS (e.g. 64 on
    // a 64-bit platform), which would panic on the left shift. The guard
    // must reject this before any domain construction happens.

    // Non-ZK config — the overflow check is independent of the ZK setting.
    let config = make_config(7);

    // Build a valid Fibonacci proof with a 2^4 = 16-row trace.
    let (air_fib, trace, fib_pis) = create_fib_instance(4);
    let instances = vec![StarkInstance {
        air: &air_fib,
        trace: &trace,
        public_values: fib_pis.clone(),
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let mut proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Mutation: overwrite the first AIR's degree_bits to exactly the bit
    // width of usize, which is the smallest value that overflows.
    //
    //     degree_bits = 64  (on 64-bit)
    //     1_usize << 64  →  shift overflow  →  must be caught
    proof.degree_bits[0] = usize::BITS as usize;

    let airs = vec![air_fib];

    // Verification must fail with a structured error, not a panic.
    let err = verify_batch(&config, &airs, &proof, &[fib_pis], common)
        .expect_err("Should reject oversized degree_bits");

    // Verify the error carries the correct diagnostic fields:
    //   - air: Some(0)          — first (and only) AIR instance
    //   - maximum: TWO_ADICITY  — largest degree supported by the PCS
    //   - got: BITS             — the tampered value we injected (64)
    match err {
        BatchVerificationError::Verification(VerificationError::InvalidProofShape(
            InvalidProofShapeError::DegreeBitsTooLarge { air, maximum, got },
        )) => {
            assert_eq!(air, Some(0));
            assert_eq!(maximum, Val::TWO_ADICITY);
            assert_eq!(got, usize::BITS as usize);
        }
        _ => panic!("unexpected error: {err:?}"),
    }
    Ok::<_, Box<dyn std::error::Error>>(())
}

#[test]
fn test_degree_bits_too_small_for_zk_rejected() -> Result<(), Box<dyn std::error::Error>> {
    // In ZK mode the prover extends the trace by one bit (is_zk = 1), so
    // the verifier computes `base_degree_bits = degree_bits - is_zk`.
    // If degree_bits < is_zk that subtraction underflows. The guard must
    // reject this with a clear minimum-threshold error.

    // ZK-enabled config — is_zk = 1, meaning degree_bits must be >= 1.
    let config = make_config_zk(1337);

    // Build a valid Fibonacci proof with a 2^5 = 32-row trace.
    let (air_fib, trace, fib_pis) = create_fib_instance(5);
    let instances = vec![StarkInstance {
        air: &air_fib,
        trace: &trace,
        public_values: fib_pis.clone(),
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let mut proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Mutation: set degree_bits to 0, which is below the ZK minimum.
    //
    //     is_zk = 1
    //     degree_bits = 0
    //     base_degree_bits = 0 - 1  →  underflow  →  must be caught
    proof.degree_bits[0] = 0;

    let airs = vec![air_fib];

    // Verification must fail before any domain arithmetic.
    let err = verify_batch(&config, &airs, &proof, &[fib_pis], common)
        .expect_err("Should reject too-small degree_bits in zk mode");

    // Verify the error carries the correct diagnostic fields:
    //   - air: Some(0)   — first (and only) AIR instance
    //   - minimum: 1     — is_zk, the smallest acceptable degree_bits
    //   - got: 0         — the tampered value we injected
    match err {
        BatchVerificationError::Verification(VerificationError::InvalidProofShape(
            InvalidProofShapeError::DegreeBitsTooSmall { air, minimum, got },
        )) => {
            assert_eq!(air, Some(0));
            assert_eq!(minimum, 1);
            assert_eq!(got, 0);
        }
        _ => panic!("unexpected error: {err:?}"),
    }
    Ok::<_, Box<dyn std::error::Error>>(())
}

#[test]
fn test_different_widths() -> Result<(), impl Debug> {
    let config = make_config(4242);

    // Mul with reps=2 (width=6) and reps=3 (width=9)
    let (air_mul2, mul2_trace, mul2_pis) = create_mul_instance(3, 2); // 8 rows, width=6
    let (air_fib, fib_trace, fib_pis) = create_fib_instance(3); // 8 rows, width=2
    let (air_mul3, mul3_trace, mul3_pis) = create_mul_instance(4, 3); // 16 rows, width=9

    let instances = vec![
        StarkInstance {
            air: &air_mul2,
            trace: &mul2_trace,
            public_values: mul2_pis.clone(),
        },
        StarkInstance {
            air: &air_fib,
            trace: &fib_trace,
            public_values: fib_pis.clone(),
        },
        StarkInstance {
            air: &air_mul3,
            trace: &mul3_trace,
            public_values: mul3_pis.clone(),
        },
    ];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    let airs = vec![air_mul2, air_fib, air_mul3];
    let pvs = vec![mul2_pis, fib_pis, mul3_pis];
    verify_batch(&config, &airs, &proof, &pvs, common)
}

#[test]
fn test_preprocessed_tampered_fails() -> Result<(), Box<dyn std::error::Error>> {
    let config = make_config(9999);

    // Single Fibonacci instance with 8 rows and preprocessed index column.
    let (air, trace, fib_pis) = create_fib_instance(3);
    let instances = vec![StarkInstance {
        air: &air,
        trace: &trace,
        public_values: fib_pis.clone(),
    }];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // First, sanity-check that verification succeeds with matching preprocessed data.
    let airs = vec![air];
    let ok_res = verify_batch(&config, &airs, &proof, from_ref(&fib_pis), common);
    assert!(
        ok_res.is_ok(),
        "Expected verification to succeed with matching preprocessed data"
    );

    // Now tamper with the preprocessed trace by modifying the tamper_index in the AIR
    // used to derive the preprocessed commitment for verification.
    // The proof was generated with the original AIR, but we verify with a tampered AIR
    // that would produce different preprocessed columns.
    let air_tampered = DemoAir::Fib(FibonacciAir {
        log_height: 3,
        tamper_index: Some(2),
    });
    // Create CommonData with tampered AIR to test verification failure
    // Use the proof's degree_bits (which are log_degrees since ZK is not supported)
    let degree_bits = proof.degree_bits.clone();
    let airs_tampered = vec![air_tampered];
    let prover_data_tampered =
        ProverData::from_airs_and_degrees(&config, &airs_tampered, &degree_bits).unwrap();
    let common_tampered = &prover_data_tampered.common;

    let res = verify_batch(&config, &airs_tampered, &proof, &[fib_pis], common_tampered);
    assert!(
        res.is_err(),
        "Verification should fail with tampered preprocessed columns"
    );
    Ok(())
}

#[test]
fn test_preprocessed_rejects_present_preprocessed_next() {
    let config = make_config(1337);

    // Fixture state: two instances, each reading its preprocessed trace on the current row.
    //
    // Two rather than one, so a reported index of 1 cannot come from a constant or an off-by-one.
    let (air0, trace0, pis0) = create_preprocessed_mul_instance(4, 2);
    let (air1, trace1, pis1) = create_preprocessed_mul_instance(4, 3);
    let instances = vec![
        StarkInstance {
            air: &air0,
            trace: &trace0,
            public_values: pis0.clone(),
        },
        StarkInstance {
            air: &air1,
            trace: &trace1,
            public_values: pis1.clone(),
        },
    ];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let mut proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Both AIRs declare one preprocessed column, opened on the current row only.
    let pre_w = proof.opened_values.instances[1]
        .base_opened_values
        .preprocessed_local()
        .expect("instance 1 declares preprocessed columns")
        .len();
    assert_eq!(pre_w, 1);
    assert!(
        proof.opened_values.instances[1]
            .base_opened_values
            .preprocessed_next()
            .is_none()
    );

    let airs = vec![air0, air1];
    let pvs = vec![pis0, pis1];

    // The untampered proof verifies, so every rejection below is caused by the mutation alone.
    verify_batch(&config, &airs, &proof, &pvs, common).expect("untampered proof verifies");

    // Invariant: a proof carries exactly the openings its AIR reads, and no others.
    //
    // Mutation: give instance 1 an empty next-row preprocessed opening.
    //
    //     honest:   instance 1 preprocessed next = absent
    //     tampered: instance 1 preprocessed next = [] (present, zero columns)
    //
    // Zero columns is the width expected of an absent opening, so presence is what rejects it.
    proof.opened_values.instances[1]
        .base_opened_values
        .preprocessed
        .as_mut()
        .unwrap()
        .next = Some(vec![]);

    let err = verify_batch(&config, &airs, &proof, &pvs, common)
        .expect_err("a present next-row preprocessed opening must be rejected");

    // The reported index is 1, the instance that was tampered with.
    assert!(
        matches!(
            err,
            BatchVerificationError::Verification(VerificationError::InvalidProofShape(
                InvalidProofShapeError::UnexpectedPreprocessedNext { air: Some(1) },
            ))
        ),
        "unexpected error: {err:?}"
    );

    // Mutation: the other half of the same rule, a next-row opening of full width.
    //
    //     tampered: instance 1 preprocessed next = [0] (present, one column)
    //
    // This one is caught by the width comparison rather than by presence.
    proof.opened_values.instances[1]
        .base_opened_values
        .preprocessed
        .as_mut()
        .unwrap()
        .next = Some(vec![Challenge::ZERO; pre_w]);

    let err = verify_batch(&config, &airs, &proof, &pvs, common)
        .expect_err("a full-width next-row preprocessed opening must be rejected");
    assert!(
        matches!(
            err,
            BatchVerificationError::Verification(VerificationError::InvalidProofShape(
                InvalidProofShapeError::PreprocessedWidthMismatch { air: 1 },
            ))
        ),
        "unexpected error: {err:?}"
    );
}

#[test]
fn test_preprocessed_reuse_common_multi_proofs() -> Result<(), Box<dyn std::error::Error>> {
    let config = make_config(2026);

    // Single Fibonacci instance with preprocessed index column, 8 rows.
    let log_height = 3;
    let n = 1 << log_height;
    let air = DemoAir::Fib(FibonacciAir {
        log_height,
        tamper_index: None,
    });

    // First proof: standard Fibonacci trace starting from (0, 1).
    let trace1 = fib_trace::<Val>(0, 1, n);
    let fib_pis1 = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(n))];
    let instances1 = vec![StarkInstance {
        air: &air,
        trace: &trace1,
        public_values: fib_pis1.clone(),
    }];
    let prover_data = ProverData::from_instances(&config, &instances1).unwrap();
    let common = &prover_data.common;
    let proof1 = prove_batch(&config, &instances1, &prover_data).unwrap();

    // Verify the first proof.
    let airs = vec![air];
    let res1 = verify_batch(&config, &airs, &proof1, from_ref(&fib_pis1), common);
    assert!(res1.is_ok(), "First verification should succeed");

    // Second proof: DIFFERENT initial values (2, 3) - demonstrates CommonData is truly reusable
    // across different traces with the same AIR and degree.
    let trace2 = fib_trace::<Val>(2, 3, n);
    let fib_pis2 = vec![
        Val::from_u64(2),
        Val::from_u64(3),
        Val::from_u64(fib_n_from(2, 3, n)),
    ];
    let instances2 = vec![StarkInstance {
        air: &airs[0],
        trace: &trace2,
        public_values: fib_pis2.clone(),
    }];
    let proof2 = prove_batch(&config, &instances2, &prover_data).unwrap();

    let res2 = verify_batch(&config, &airs, &proof2, &[fib_pis2], common);
    assert!(
        res2.is_ok(),
        "Second verification should succeed with different trace values"
    );

    Ok(())
}

#[test]
fn test_single_instance() -> Result<(), impl Debug> {
    // Single-instance sanity test: prove and verify a single Fibonacci instance.
    let config = make_config(9999);

    let (air_fib, fib_trace, fib_pis) = create_fib_instance(5); // 32 rows

    let instances = vec![StarkInstance {
        air: &air_fib,
        trace: &fib_trace,
        public_values: fib_pis.clone(),
    }];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    let airs = vec![air_fib];
    verify_batch(&config, &airs, &proof, &[fib_pis], common)
}

#[test]
fn test_quotient_domain_size_not_multiple_of_packed_field_width() -> Result<(), impl Debug> {
    let config = make_config_allow_tiny_trace(77_007);

    // 2 rows → log2(trace)=1, one quotient chunk → quotient domain size = 2^1 = 2.
    let (air_fib, fib_trace, fib_pis) = create_fib_instance(1);

    let instances = vec![StarkInstance {
        air: &air_fib,
        trace: &fib_trace,
        public_values: fib_pis.clone(),
    }];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    let airs = vec![air_fib];
    verify_batch(&config, &airs, &proof, &[fib_pis], common)
}

#[test]
fn test_mixed_preprocessed() -> Result<(), impl Debug> {
    let config = make_config(8888);

    let (air_fib, fib_trace, fib_pis) = create_fib_instance(4); // 16 rows, has preprocessed
    let (air_mul, mul_trace, mul_pis) = create_mul_instance(4, 2); // 16 rows, no preprocessed

    let instances = vec![
        StarkInstance {
            air: &air_fib,
            trace: &fib_trace,
            public_values: fib_pis.clone(),
        },
        StarkInstance {
            air: &air_mul,
            trace: &mul_trace,
            public_values: mul_pis.clone(),
        },
    ];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;

    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    let airs = vec![air_fib, air_mul];
    let pvs = vec![fib_pis, mul_pis];

    verify_batch(&config, &airs, &proof, &pvs, common)
}

#[test]
fn test_invalid_trace_width_rejected() {
    // This test verifies that the verifier rejects proofs with incorrect trace width.
    use p3_batch_stark::proof::{BatchCommitments, BatchOpenedValues};
    use p3_uni_stark::OpenedValues;

    let config = make_config(55555);

    let (air_fib, fib_trace, fib_pis) = create_fib_instance(4); // 16 rows

    let instances = vec![StarkInstance {
        air: &air_fib,
        trace: &fib_trace,
        public_values: fib_pis.clone(),
    }];

    // Generate a valid proof
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let valid_proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Tamper with the proof: change trace_local to have wrong width
    let mut tampered_proof = p3_batch_stark::proof::BatchProof {
        commitments: BatchCommitments {
            main: valid_proof.commitments.main,
            quotient_chunks: valid_proof.commitments.quotient_chunks,
            permutation: valid_proof.commitments.permutation,
            random: valid_proof.commitments.random,
        },
        opened_values: BatchOpenedValues {
            instances: vec![OpenedValuesWithLookups {
                base_opened_values: OpenedValues {
                    trace_local: vec![
                        valid_proof.opened_values.instances[0]
                            .base_opened_values
                            .trace_local[0],
                    ], // Wrong width: 1 instead of 2
                    trace_next: valid_proof.opened_values.instances[0]
                        .base_opened_values
                        .trace_next
                        .clone(),
                    preprocessed: None,
                    quotient_chunks: valid_proof.opened_values.instances[0]
                        .base_opened_values
                        .quotient_chunks
                        .clone(),
                    random: None,
                },
                permutation_local: valid_proof.opened_values.instances[0]
                    .permutation_local
                    .clone(),
                permutation_next: valid_proof.opened_values.instances[0]
                    .permutation_next
                    .clone(),
            }],
        },
        opening_proof: valid_proof.opening_proof.clone(),
        lookup_terminals: valid_proof.lookup_terminals.clone(),
        degree_bits: valid_proof.degree_bits.clone(),
        lookup_pow_witness: valid_proof.lookup_pow_witness,
        ood_pow_witness: valid_proof.ood_pow_witness,
    };

    // Verification should fail due to width mismatch
    let airs = vec![air_fib];
    let res = verify_batch(&config, &airs, &tampered_proof, from_ref(&fib_pis), common);
    assert!(
        res.is_err(),
        "Verifier should reject trace with wrong width"
    );

    // Also test wrong trace_next width
    tampered_proof.opened_values.instances[0]
        .base_opened_values
        .trace_local = valid_proof.opened_values.instances[0]
        .base_opened_values
        .trace_local
        .clone();
    tampered_proof.opened_values.instances[0]
        .base_opened_values
        .trace_next = Some(vec![
        valid_proof.opened_values.instances[0]
            .base_opened_values
            .trace_next
            .as_ref()
            .unwrap()[0],
    ]); // Wrong width

    let res = verify_batch(&config, &airs, &tampered_proof, from_ref(&fib_pis), common);
    assert!(
        res.is_err(),
        "Verifier should reject trace_next with wrong width"
    );
}

#[test]
fn test_reorder_instances_rejected() {
    // Reordering AIRs at verify should break transcript binding and be rejected.
    let config = make_config(123);

    let (air_a, tr_a, pv_a) = create_fib_instance(4);
    let (air_b, tr_b, pv_b) = create_mul_instance(4, 2);

    let instances = vec![
        StarkInstance {
            air: &air_a,
            trace: &tr_a,
            public_values: pv_a.clone(),
        },
        StarkInstance {
            air: &air_b,
            trace: &tr_b,
            public_values: pv_b.clone(),
        },
    ];

    // DemoAir::Fib has preprocessed columns, so compute degrees for swapped verification
    let degrees: Vec<usize> = instances.iter().map(|i| i.trace.height()).collect();
    let log_degrees: Vec<usize> = degrees.iter().copied().map(log2_strict_usize).collect();

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Swap order at verify -> should fail (create new CommonData with swapped AIRs)
    let airs_swapped = vec![air_b, air_a];
    let prover_data_swapped =
        ProverData::from_airs_and_degrees(&config, &airs_swapped, &log_degrees).unwrap();
    let common_swapped = &prover_data_swapped.common;
    let res = verify_batch(
        &config,
        &airs_swapped,
        &proof,
        &[pv_b, pv_a],
        common_swapped,
    );
    assert!(res.is_err(), "Verifier should reject reordered instances");
}

#[test]
fn test_quotient_chunk_element_len_rejected() {
    // Truncating an element from a quotient chunk should be rejected by shape checks.
    use core::slice::from_ref;

    let config = make_config(321);
    let (air, tr, pv) = create_fib_instance(4);

    let instances = vec![StarkInstance {
        air: &air,
        trace: &tr,
        public_values: pv.clone(),
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    let mut tampered = proof;
    tampered.opened_values.instances[0]
        .base_opened_values
        .quotient_chunks[0]
        .pop();

    let airs = vec![air];
    let res = verify_batch(&config, &airs, &tampered, from_ref(&pv), common);
    assert!(
        res.is_err(),
        "Verifier should reject truncated quotient chunk element"
    );
}

#[test]
fn test_circle_stark_batch() -> Result<(), impl Debug> {
    // Test batch-stark with Circle PCS (non-two-adic field)
    let config = make_circle_config();

    // Create two Fibonacci instances with different sizes.
    // Here we don't use preprocessed columns (Circle PCS + plain FibonacciAir).
    let air_fib1 = FibonacciAir {
        log_height: 0,
        tamper_index: None,
    };
    let air_fib2 = FibonacciAir {
        log_height: 0,
        tamper_index: None,
    };

    let fib_pis1 = vec![
        CircleVal::from_u64(0),
        CircleVal::from_u64(1),
        CircleVal::from_u64(fib_n(8)),
    ]; // F_8 = 21
    let fib_pis2 = vec![
        CircleVal::from_u64(0),
        CircleVal::from_u64(1),
        CircleVal::from_u64(fib_n(4)),
    ]; // F_4 = 3

    let trace1 = fib_trace::<CircleVal>(0, 1, 8);
    let trace2 = fib_trace::<CircleVal>(0, 1, 4);

    let airs = vec![air_fib1, air_fib2];

    let instances = vec![
        StarkInstance {
            air: &airs[0],
            trace: &trace1,
            public_values: fib_pis1.clone(),
        },
        StarkInstance {
            air: &airs[1],
            trace: &trace2,
            public_values: fib_pis2.clone(),
        },
    ];

    // Generate batch-proof
    // Plain FibonacciAir doesn't have preprocessed columns
    let prover_data = ProverData::empty(airs.len());
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Verify batch-proof
    let public_values = vec![fib_pis1, fib_pis2];
    let common = &prover_data.common;
    verify_batch(&config, &airs, &proof, &public_values, common)
        .map_err(|e| format!("Verification failed: {:?}", e))
}

#[test]
fn test_batch_degree_bits_below_circle_pcs_minimum_rejected() {
    // Invariant: a claimed trace height is proof data, and the circle scheme needs four rows.
    //
    // The verifier builds each trace domain from that claim before the opening argument runs.
    // A claim that is too small therefore has to be rejected up front.
    let config = make_circle_config();

    // Fixture state: two instances without preprocessed columns.
    //
    //     instance 0: 8 rows -> claimed height of 3 bits
    //     instance 1: 4 rows -> claimed height of 2 bits, exactly the minimum
    let airs = vec![
        FibonacciAir {
            log_height: 0,
            tamper_index: None,
        },
        FibonacciAir {
            log_height: 0,
            tamper_index: None,
        },
    ];
    let pis0 = vec![
        CircleVal::from_u64(0),
        CircleVal::from_u64(1),
        CircleVal::from_u64(fib_n(8)),
    ];
    let pis1 = vec![
        CircleVal::from_u64(0),
        CircleVal::from_u64(1),
        CircleVal::from_u64(fib_n(4)),
    ];
    let trace0 = fib_trace::<CircleVal>(0, 1, 8);
    let trace1 = fib_trace::<CircleVal>(0, 1, 4);
    let instances = vec![
        StarkInstance {
            air: &airs[0],
            trace: &trace0,
            public_values: pis0.clone(),
        },
        StarkInstance {
            air: &airs[1],
            trace: &trace1,
            public_values: pis1.clone(),
        },
    ];

    let prover_data = ProverData::empty(airs.len());
    let common = &prover_data.common;
    let mut proof = prove_batch(&config, &instances, &prover_data).unwrap();
    let public_values = vec![pis0, pis1];
    assert_eq!(proof.degree_bits, vec![3, 2]);

    // The smaller instance sits exactly on the boundary, so an honest batch there verifies.
    // The rejection below is therefore strictly less than, not less than or equal.
    verify_batch(&config, &airs, &proof, &public_values, common)
        .expect("a claim exactly at the minimum must verify");

    // Mutation: shrink the second instance's claimed height below the minimum.
    //
    //     honest:   degree_bits = [3, 2]
    //     tampered: degree_bits = [3, 1]
    proof.degree_bits[1] = 1;

    let err = verify_batch(&config, &airs, &proof, &public_values, common)
        .expect_err("a claim below the minimum trace height must be rejected");

    // The rejection names the offending instance and the backend's own minimum.
    match err {
        BatchVerificationError::Verification(VerificationError::InvalidProofShape(
            InvalidProofShapeError::DegreeBitsTooSmall { air, minimum, got },
        )) => {
            assert_eq!(air, Some(1));
            assert_eq!(minimum, 2);
            assert_eq!(got, 1);
        }
        other => panic!("unexpected error: {other:?}"),
    }

    // Recursive verifiers reach this public builder directly, never the whole-proof entry point.
    //
    // It re-derives every trace domain from the claimed heights, so it applies the same bound.
    // The heights are rejected before any of the later arguments are read.
    let err = commitments_with_opening_points::<CircleConfig, _>(
        &config,
        &airs,
        CircleChallenge::ZERO,
        &proof.commitments,
        &proof.opened_values,
        common,
        &proof.degree_bits,
        &[0, 0],
        &[0, 0],
    )
    .expect_err("the opening-claim builder must apply the same bound");
    match err {
        BatchVerificationError::Verification(VerificationError::InvalidProofShape(
            InvalidProofShapeError::DegreeBitsTooSmall { air, minimum, got },
        )) => {
            assert_eq!(air, Some(1));
            assert_eq!(minimum, 2);
            assert_eq!(got, 1);
        }
        other => panic!("unexpected error: {other:?}"),
    }
}

#[test]
fn test_batch_degree_bits_at_circle_pcs_maximum_rejected() {
    // Invariant: a claimed height whose quotient domain leaves the circle group is rejected.
    //
    // Fixture state: the circle PCS accepts trace heights up to 2^30.
    //
    // The quotient domain of such a trace has size at least 2^31.
    //
    // Its shift would need a point of order 2^32, which the Mersenne31 circle group lacks.
    let config = make_circle_config();
    let airs = vec![
        FibonacciAir {
            log_height: 0,
            tamper_index: None,
        },
        FibonacciAir {
            log_height: 0,
            tamper_index: None,
        },
    ];
    let pis0 = vec![
        CircleVal::from_u64(0),
        CircleVal::from_u64(1),
        CircleVal::from_u64(fib_n(8)),
    ];
    let pis1 = vec![
        CircleVal::from_u64(0),
        CircleVal::from_u64(1),
        CircleVal::from_u64(fib_n(4)),
    ];
    let trace0 = fib_trace::<CircleVal>(0, 1, 8);
    let trace1 = fib_trace::<CircleVal>(0, 1, 4);
    let instances = vec![
        StarkInstance {
            air: &airs[0],
            trace: &trace0,
            public_values: pis0.clone(),
        },
        StarkInstance {
            air: &airs[1],
            trace: &trace1,
            public_values: pis1.clone(),
        },
    ];

    let prover_data = ProverData::empty(airs.len());
    let common = &prover_data.common;
    let mut proof = prove_batch(&config, &instances, &prover_data).unwrap();
    let public_values = vec![pis0, pis1];

    // Mutation: claim the largest height the PCS accepts for the second instance.
    proof.degree_bits[1] = 30;
    let err = verify_batch(&config, &airs, &proof, &public_values, common)
        .expect_err("a quotient domain beyond the circle group must be rejected");
    match err {
        BatchVerificationError::Verification(VerificationError::InvalidProofShape(
            InvalidProofShapeError::QuotientDomainTooLarge { air, maximum, .. },
        )) => {
            assert_eq!(air, Some(1));
            assert_eq!(maximum, 30);
        }
        other => panic!("unexpected error: {other:?}"),
    }
}

#[derive(Clone)]
struct NonlinearTransitionAir {
    degree_hint: Option<usize>,
}

impl<F> BaseAir<F> for NonlinearTransitionAir {
    fn width(&self) -> usize {
        1
    }

    fn max_constraint_degree(&self) -> Option<usize> {
        self.degree_hint
    }
}

impl<AB: AirBuilder> Air<AB> for NonlinearTransitionAir {
    fn eval(&self, builder: &mut AB) {
        let main = builder.main();
        let local = main.current_slice()[0];
        let next = main.next_slice()[0];
        builder.when_first_row().assert_eq(local, AB::Expr::TWO);
        builder
            .when_transition()
            .assert_eq(next, local.into().cube() + AB::Expr::ONE);
    }
}

fn check_circle_nonlinear_transition(with_hint: bool) {
    let config = make_circle_config();
    let airs = [
        NonlinearTransitionAir {
            degree_hint: with_hint.then_some(3),
        },
        NonlinearTransitionAir {
            degree_hint: with_hint.then_some(3),
        },
    ];
    let traces = [16, 32].map(|height| {
        let mut value = CircleVal::TWO;
        RowMajorMatrix::new_col(
            (0..height)
                .map(|_| {
                    let current = value;
                    value = value.cube() + CircleVal::ONE;
                    current
                })
                .collect(),
        )
    });
    let instances = airs
        .iter()
        .zip(&traces)
        .map(|(air, trace)| StarkInstance {
            air,
            trace,
            public_values: vec![],
        })
        .collect::<Vec<_>>();
    let prover_data = ProverData::empty(airs.len());
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    assert!(
        verify_batch(
            &config,
            &airs,
            &proof,
            &[vec![], vec![]],
            &prover_data.common
        )
        .is_ok(),
        "valid Circle transitions rejected (hint={with_hint})"
    );
}

#[test]
fn circle_nonlinear_transition_without_hint() {
    check_circle_nonlinear_transition(false);
}

#[test]
fn circle_nonlinear_transition_with_hint() {
    check_circle_nonlinear_transition(true);
}

#[derive(Clone)]
struct CircleTransitionLookupAir {
    receive: bool,
}

impl<F> BaseAir<F> for CircleTransitionLookupAir {
    fn width(&self) -> usize {
        2
    }

    fn max_constraint_degree(&self) -> Option<usize> {
        Some(0)
    }
}

impl<AB: PermutationAirBuilder + InteractionBuilder> Air<AB> for CircleTransitionLookupAir {
    fn eval(&self, builder: &mut AB) {
        let main = builder.main();
        let transition = builder.is_transition();
        for &value in main.current_slice() {
            builder.push_interaction(
                "transition-payload",
                [transition.clone() * value],
                if self.receive { 1 } else { -1 },
            );
        }
    }
}

#[test]
fn circle_lookup_packing_preserves_quotient_budget() {
    let config = make_circle_config();
    let airs = [
        CircleTransitionLookupAir { receive: true },
        CircleTransitionLookupAir { receive: false },
    ];
    let trace = RowMajorMatrix::new(
        (0..16)
            .flat_map(|i| [CircleVal::from_u32(i), CircleVal::from_u32(i * i + 1)])
            .collect(),
        2,
    );
    let instances = airs
        .iter()
        .map(|air| StarkInstance {
            air,
            trace: &trace,
            public_values: vec![],
        })
        .collect::<Vec<_>>();
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    for lookups in &prover_data.common.lookups {
        // Each transition * payload has degree 2. Two such tuples would pin
        // at degree 5 and exceed the unpacked degree-3 quotient bucket.
        assert_eq!(lookups.len(), 2);
    }
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    assert!(
        verify_batch(
            &config,
            &airs,
            &proof,
            &[vec![], vec![]],
            &prover_data.common
        )
        .is_ok()
    );
}

type CompatCase<Config, V> = (
    Config,
    Vec<DemoAirWithLookups>,
    Vec<RowMajorMatrix<V>>,
    Vec<Vec<V>>,
    Vec<usize>,
);

fn two_adic_compat_case() -> CompatCase<MyConfig, Val> {
    let config = make_two_adic_compat_config(777);
    let reps = 2;
    let log_n = 5;
    let n = 1 << log_n;

    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(
        mul_air,
        false,
        true,
        vec!["MulFib".to_string(), "MulFib".to_string()],
    );

    let fibonacci_air = FibonacciAir {
        log_height: log_n,
        tamper_index: None,
    };
    let fib_air_lookups = FibAirLookups::new(fibonacci_air, true, None);

    let mul_trace = mul_trace::<Val>(n, reps);
    let fib_trace = fib_trace::<Val>(0, 1, n);
    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(n))];

    let air1 = DemoAirWithLookups::MulLookups(mul_air_lookups);
    let air2 = DemoAirWithLookups::FibLookups(fib_air_lookups);

    let is_zk = config.is_zk();
    let log_degrees: Vec<usize> = vec![mul_trace.height(), fib_trace.height()]
        .into_iter()
        .map(|height| log2_strict_usize(height) + is_zk)
        .collect();
    (
        config,
        vec![air1, air2],
        vec![mul_trace, fib_trace],
        vec![vec![], fib_pis],
        log_degrees,
    )
}

fn circle_compat_case() -> CompatCase<CircleConfig, CircleVal> {
    let config = make_circle_config();
    let reps = 2;
    let log_n = 3;
    let n = 1 << log_n;

    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(
        mul_air,
        false,
        true,
        vec!["MulFib".to_string(), "MulFib".to_string()],
    );

    let fibonacci_air = FibonacciAir {
        log_height: log_n,
        tamper_index: None,
    };
    let fib_air_lookups = FibAirLookups::new(fibonacci_air, true, None);

    let mul_trace = mul_trace::<CircleVal>(n, reps);
    let fib_trace = fib_trace::<CircleVal>(0, 1, n);
    let fib_pis = vec![
        CircleVal::from_u64(0),
        CircleVal::from_u64(1),
        CircleVal::from_u64(fib_n(n)),
    ];

    let air1 = DemoAirWithLookups::MulLookups(mul_air_lookups);
    let air2 = DemoAirWithLookups::FibLookups(fib_air_lookups);

    let is_zk = config.is_zk();
    let log_degrees: Vec<usize> = vec![mul_trace.height(), fib_trace.height()]
        .into_iter()
        .map(|height| log2_strict_usize(height) + is_zk)
        .collect();
    (
        config,
        vec![air1, air2],
        vec![mul_trace, fib_trace],
        vec![vec![], fib_pis],
        log_degrees,
    )
}

fn write_fixture(path: &str, bytes: &[u8]) -> std::io::Result<()> {
    let full_path = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join(path);
    if let Some(parent) = full_path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    std::fs::write(full_path, bytes)
}

fn read_fixture(path: &str) -> std::io::Result<Vec<u8>> {
    let full_path = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join(path);
    std::fs::read(full_path)
}

#[test]
fn verify_two_adic_compat_fixture() -> Result<(), Box<dyn std::error::Error>> {
    let (config, airs, _traces, pvs, _log_degrees) = two_adic_compat_case();
    let proof_bytes = read_fixture(TWO_ADIC_FIXTURE)
        .expect("Missing fixture. Run: cargo test -p p3-batch-stark --test simple -- --ignored");
    let proof: BatchProof<MyConfig> = postcard::from_bytes(&proof_bytes)?;
    let prover_data =
        ProverData::from_airs_and_degrees(&config, &airs, &proof.degree_bits).unwrap();
    let common = &prover_data.common;
    verify_batch(&config, &airs, &proof, &pvs, common)?;

    // Re-encoding must reproduce the stored bytes.
    // The wire layout is then pinned in both directions, not just on decode.
    assert_eq!(postcard::to_allocvec(&proof)?, proof_bytes);
    Ok(())
}

#[test]
fn verify_circle_compat_fixture() -> Result<(), Box<dyn std::error::Error>> {
    let (config, airs, _traces, pvs, _log_degrees) = circle_compat_case();
    let proof_bytes = read_fixture(CIRCLE_FIXTURE)
        .expect("Missing fixture. Run: cargo test -p p3-batch-stark --test simple -- --ignored");
    let proof: BatchProof<CircleConfig> = postcard::from_bytes(&proof_bytes)?;
    let prover_data =
        ProverData::from_airs_and_degrees(&config, &airs, &proof.degree_bits).unwrap();
    let common = &prover_data.common;
    verify_batch(&config, &airs, &proof, &pvs, common)?;

    // Re-encoding must reproduce the stored bytes.
    // The wire layout is then pinned in both directions, not just on decode.
    assert_eq!(postcard::to_allocvec(&proof)?, proof_bytes);
    Ok(())
}

#[test]
#[ignore]
fn generate_two_adic_fixture() -> Result<(), Box<dyn std::error::Error>> {
    // Regen: cargo test -p p3-batch-stark --test simple -- --ignored
    let (config, airs, traces, pvs, log_degrees) = two_adic_compat_case();
    let prover_data = ProverData::from_airs_and_degrees(&config, &airs, &log_degrees).unwrap();
    let _common = &prover_data.common;
    let traces = [&traces[0], &traces[1]];
    let instances = StarkInstance::new_multiple(&airs, &traces, &pvs);
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    let bytes = postcard::to_allocvec(&proof)?;
    write_fixture(TWO_ADIC_FIXTURE, &bytes)?;
    Ok(())
}

#[test]
#[ignore]
fn generate_circle_fixture() -> Result<(), Box<dyn std::error::Error>> {
    // Regen: cargo test -p p3-batch-stark --test simple -- --ignored
    let (config, airs, traces, pvs, log_degrees) = circle_compat_case();
    let prover_data = ProverData::from_airs_and_degrees(&config, &airs, &log_degrees).unwrap();
    let _common = &prover_data.common;
    let traces = [&traces[0], &traces[1]];
    let instances = StarkInstance::new_multiple(&airs, &traces, &pvs);
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    let bytes = postcard::to_allocvec(&proof)?;
    write_fixture(CIRCLE_FIXTURE, &bytes)?;
    Ok(())
}

#[test]
fn test_preprocessed_constraint_zk() {
    let config = make_config_zk(8888);
    let (air, trace, pis) = create_preprocessed_mul_instance(5, 2);
    let instances = vec![StarkInstance {
        air: &air,
        trace: &trace,
        public_values: pis.clone(),
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    assert!(prover_data.common.preprocessed.is_some());
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    verify_batch(&config, &[air], &proof, &[pis], &prover_data.common).unwrap();
}

#[test]
fn test_preprocessed_constraint_positive() -> Result<(), impl Debug> {
    // Test that preprocessed columns are correctly used in constraints
    // Enforces: main[0] = 2 * preprocessed[0]
    let config = make_config(8888);

    let (air, trace, pis) = create_preprocessed_mul_instance(4, 2); // 16 rows, multiplier=2

    let instances = vec![StarkInstance {
        air: &air,
        trace: &trace,
        public_values: pis.clone(),
    }];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    let airs = vec![air];
    verify_batch(&config, &airs, &proof, &[pis], common)
}

#[test]
fn test_preprocessed_constraint_negative() -> Result<(), Box<dyn std::error::Error>> {
    // Test that incorrect preprocessed constraints are caught via OOD evaluation mismatch
    // Proof is generated with multiplier=2, but verification uses multiplier=3
    let config = make_config(9999);

    // Generate proof with multiplier=2
    let (air_prove, trace, pis) = create_preprocessed_mul_instance(4, 2); // 16 rows, multiplier=2

    let instances = vec![StarkInstance {
        air: &air_prove,
        trace: &trace,
        public_values: pis.clone(),
    }];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Verify with wrong multiplier=3 (should fail)
    let air_verify = DemoAir::PreprocessedMul(PreprocessedMulAir {
        log_height: 4,
        multiplier: 3, // Wrong multiplier!
    });
    let airs = vec![air_verify];
    let degree_bits = proof.degree_bits.clone();
    let prover_data_verify =
        ProverData::from_airs_and_degrees(&config, &airs, &degree_bits).unwrap();
    let common_verify = &prover_data_verify.common;

    let res = verify_batch(&config, &airs, &proof, &[pis], common_verify);
    let err = res.expect_err(
        "Verification should fail when preprocessed constraint multiplier doesn't match",
    );
    match err {
        BatchVerificationError::Verification(VerificationError::OodEvaluationMismatch {
            ..
        }) => (),
        _ => panic!("unexpected error: {err:?}"),
    }
    Ok(())
}

#[test]
fn test_mixed_preprocessed_constraints() -> Result<(), impl Debug> {
    // Test batching PreprocessedMulAir (uses pp in constraints) with MulAir and FibonacciAir
    // This exercises matrix_to_instance routing and point-scheduling with heterogeneous instances
    // while preprocessed values actually affect constraints.
    let config = make_config(1111);

    let (air_fib, fib_trace, fib_pis) = create_fib_instance(4); // 16 rows, has pp but doesn't use in constraints
    let (air_mul, mul_trace, mul_pis) = create_mul_instance(4, 2); // 16 rows, no pp
    let (air_pp_mul, pp_mul_trace, pp_mul_pis) = create_preprocessed_mul_instance(4, 2); // 16 rows, uses pp in constraints

    let instances = vec![
        StarkInstance {
            air: &air_fib,
            trace: &fib_trace,
            public_values: fib_pis.clone(),
        },
        StarkInstance {
            air: &air_mul,
            trace: &mul_trace,
            public_values: mul_pis.clone(),
        },
        StarkInstance {
            air: &air_pp_mul,
            trace: &pp_mul_trace,
            public_values: pp_mul_pis.clone(),
        },
    ];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    let airs = vec![air_fib, air_mul, air_pp_mul];
    let pvs = vec![fib_pis, mul_pis, pp_mul_pis];
    verify_batch(&config, &airs, &proof, &pvs, common)
}

// Tests for local and global lookup handling in multi-stark.

/// Test with local lookups only using MulAirLookups
#[test]
fn test_batch_stark_one_instance_local_only() -> Result<(), impl Debug> {
    let config = make_config(2024);

    let reps = 1;
    // Create MulAir instance with local lookups configuration
    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(mul_air, true, false, vec![]); // local only

    let log_height = 3; // 8 rows
    let mul_trace = mul_trace::<Val>(1 << log_height, reps);

    let airs = [DemoAirWithLookups::MulLookups(mul_air_lookups)];

    // Get lookups from the lookup-enabled AIRs
    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_height]).unwrap();
    let common = &prover_data.common;
    let traces = [&mul_trace];

    let instances = StarkInstance::new_multiple(&airs, &traces, &[vec![]]);

    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    let pvs = vec![vec![]];
    verify_batch(&config, &airs, &proof, &pvs, common)
}

/// Test with local lookups only, which fail due to wrong permutation column.
///
/// Under the single-terminal layout the AIR's per-row constraints can still be
/// satisfied with a non-zero terminal, so the debug `check_lookups` walker is
/// what surfaces the multiset imbalance during proof generation.
#[cfg(debug_assertions)]
#[test]
#[should_panic(expected = "Lookup mismatch")]
fn test_batch_stark_one_instance_local_fails() {
    let config = make_config(2024);

    let reps = 2;
    // Create MulAir instance with local lookups configuration
    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(mul_air, true, false, vec![]); // local only

    let log_height = 3; // 8 rows
    let mut mul_trace = mul_trace::<Val>(1 << log_height, reps);

    // Tamper with the permutation column to cause lookup failure.
    mul_trace.values[reps * 3] = Val::from_u64(9999);

    let airs = [DemoAirWithLookups::MulLookups(mul_air_lookups)];

    // Get lookups from the lookup-enabled AIRs
    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_height]).unwrap();
    let _common = &prover_data.common;
    let traces = [&mul_trace];

    let instances = StarkInstance::new_multiple(&airs, &traces, &[vec![]]);

    prove_batch(&config, &instances, &prover_data).unwrap();
}

/// Test with local lookups only, which fail due to wrong permutation column.
///
/// Under the single-terminal layout the prover commits a non-zero terminal that
/// the cross-AIR sum then rejects when the lookup multiset is unbalanced.
#[cfg(not(debug_assertions))]
#[test]
fn test_batch_stark_one_instance_local_fails() {
    let config = make_config(2024);

    let reps = 2;
    let log_height = 3; // 8 rows
    // Create MulAir instance with local lookups configuration
    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(mul_air, true, false, vec![]); // local only

    let mut mul_trace = mul_trace::<Val>(1 << log_height, reps);

    // Tamper with the permutation column to cause lookup failure.
    mul_trace.values[reps * 3] = Val::from_u64(9999);

    let airs = [DemoAirWithLookups::MulLookups(mul_air_lookups)];

    // Get lookups from the lookup-enabled AIRs
    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_height]).unwrap();
    let common = &prover_data.common;
    let traces = [&mul_trace];

    let instances = StarkInstance::new_multiple(&airs, &traces, &[vec![]]);

    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    assert!(verify_batch(&config, &airs, &proof, &[vec![]], common).is_err());
}

/// Test with local lookups only using MulAirLookups
#[test]
fn test_batch_stark_local_lookups_only() -> Result<(), impl Debug> {
    let config = make_config(2024);

    let log_height = 4; // 16 rows
    let height = 1 << log_height;
    // Create MulAir instance with local lookups configuration
    let mul_air = MulAir { reps: 2 };
    let mul_air_lookups = MulAirLookups::new(mul_air, true, false, vec![]); // local only
    let fib_air_lookups = FibAirLookups::new(
        FibonacciAir {
            log_height,
            tamper_index: None,
        },
        false,
        None,
    ); // no lookups

    let mul_trace = mul_trace::<Val>(height, 2);
    let fib_trace = fib_trace::<Val>(0, 1, 16);
    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(16))];

    // Use the enum wrapper for heterogeneous types
    let air1 = DemoAirWithLookups::MulLookups(mul_air_lookups);
    let air2 = DemoAirWithLookups::FibLookups(fib_air_lookups);

    let airs = [air1, air2];

    // Get lookups from the lookup-enabled AIRs
    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_height, log_height])
            .unwrap();
    let common = &prover_data.common;
    let traces = [&mul_trace, &fib_trace];

    let instances = StarkInstance::new_multiple(&airs, &traces, &[vec![], fib_pis.clone()]);

    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    let pvs = vec![vec![], fib_pis];
    verify_batch(&config, &airs, &proof, &pvs, common)
}

/// Difficulty small enough to grind instantly, large enough that a wrong
/// witness is rejected with overwhelming probability.
const LOOKUP_POW_BITS: usize = 8;

/// The two-AIR fixture used by the lookup-grinding tests: a `MulAir` with local
/// lookups and a `FibonacciAir` with none.
const fn lookup_grinding_airs() -> [DemoAirWithLookups; 2] {
    let log_height = 4;
    let mul_air_lookups = MulAirLookups::new(MulAir { reps: 2 }, true, false, vec![]);
    let fib_air_lookups = FibAirLookups::new(
        FibonacciAir {
            log_height,
            tamper_index: None,
        },
        false,
        None,
    );
    [
        DemoAirWithLookups::MulLookups(mul_air_lookups),
        DemoAirWithLookups::FibLookups(fib_air_lookups),
    ]
}

/// The same shape with lookups switched off on both AIRs, so the batch samples
/// no lookup challenge at all.
const fn no_lookup_airs() -> [DemoAirWithLookups; 2] {
    let log_height = 4;
    let mul_air_lookups = MulAirLookups::new(MulAir { reps: 2 }, false, false, vec![]);
    let fib_air_lookups = FibAirLookups::new(
        FibonacciAir {
            log_height,
            tamper_index: None,
        },
        false,
        None,
    );
    [
        DemoAirWithLookups::MulLookups(mul_air_lookups),
        DemoAirWithLookups::FibLookups(fib_air_lookups),
    ]
}

/// Run one prove/verify round of the fixture, letting the caller tamper with the
/// proof and verify under a possibly different config.
fn lookup_grinding_case(
    prover_config: &MyConfig,
    verifier_config: &MyConfig,
    airs: &[DemoAirWithLookups; 2],
    tamper: impl FnOnce(&mut BatchProof<MyConfig>),
) -> Result<(), BatchVerificationError<impl Debug>> {
    let log_height = 4;
    let height = 1 << log_height;
    let mul_trace = mul_trace::<Val>(height, 2);
    let fib_trace = fib_trace::<Val>(0, 1, 16);
    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(16))];

    let prover_data = ProverData::<MyConfig>::from_airs_and_degrees(
        prover_config,
        airs,
        &[log_height, log_height],
    )
    .unwrap();
    let common = &prover_data.common;
    let traces = [&mul_trace, &fib_trace];
    let instances = StarkInstance::new_multiple(airs, &traces, &[vec![], fib_pis.clone()]);

    let mut proof = prove_batch(prover_config, &instances, &prover_data).unwrap();
    tamper(&mut proof);

    let pvs = vec![vec![], fib_pis];
    verify_batch(verifier_config, airs, &proof, &pvs, common)
}

/// A proof produced with lookup grinding verifies, and carries the witness.
#[test]
fn lookup_grinding_round_trips() {
    let config = make_config(2024).with_lookup_proof_of_work_bits(LOOKUP_POW_BITS);
    let airs = lookup_grinding_airs();

    lookup_grinding_case(&config, &config, &airs, |proof| {
        assert!(
            proof.lookup_pow_witness.is_some(),
            "a batch with lookups must carry a witness"
        );
    })
    .expect("ground proof verifies");
}

/// A tampered witness is rejected even at the difficulty the proof was produced
/// with, which is what makes the grind binding rather than decorative.
#[test]
fn tampered_lookup_pow_witness_is_rejected() {
    let config = make_config(2024).with_lookup_proof_of_work_bits(LOOKUP_POW_BITS);
    let airs = lookup_grinding_airs();

    let err = lookup_grinding_case(&config, &config, &airs, |proof| {
        proof.lookup_pow_witness = proof.lookup_pow_witness.map(|w| w + Val::ONE);
    })
    .expect_err("a tampered witness must be rejected");

    assert!(
        matches!(
            err,
            BatchVerificationError::Transcript(BatchTranscriptFailure::LookupPowWitness {
                bits: LOOKUP_POW_BITS
            })
        ),
        "wrong error variant: {err:?}"
    );
}

/// A verifier demanding more grinding than the prover paid rejects. This is the
/// failure mode of a prover/verifier config mismatch, and it must be a rejection
/// rather than a silently weaker proof.
#[test]
fn lookup_pow_difficulty_mismatch_is_rejected() {
    let prover_config = make_config(2024);
    let verifier_config = make_config(2024).with_lookup_proof_of_work_bits(24);
    let airs = lookup_grinding_airs();

    let err = lookup_grinding_case(&prover_config, &verifier_config, &airs, |_| {})
        .expect_err("a difficulty mismatch must be rejected");

    assert!(
        matches!(
            err,
            BatchVerificationError::Transcript(BatchTranscriptFailure::LookupPowWitness {
                bits: 24
            })
        ),
        "wrong error variant: {err:?}"
    );
}

/// A batch with no lookups samples no lookup challenge, so it grinds nothing and
/// must carry no witness — and one smuggled in is rejected rather than ignored.
#[test]
fn batch_without_lookups_carries_no_witness() {
    let config = make_config(2024).with_lookup_proof_of_work_bits(LOOKUP_POW_BITS);
    let airs = no_lookup_airs();

    lookup_grinding_case(&config, &config, &airs, |proof| {
        assert!(
            proof.lookup_pow_witness.is_none(),
            "a batch without lookups must carry no witness"
        );
    })
    .expect("ungrounded proof verifies");

    let err = lookup_grinding_case(&config, &config, &airs, |proof| {
        proof.lookup_pow_witness = Some(Val::ONE);
    })
    .expect_err("a witness for a challenge that is never sampled must be rejected");

    assert!(
        matches!(
            err,
            BatchVerificationError::Transcript(BatchTranscriptFailure::UnexpectedLookupPowWitness)
        ),
        "wrong error variant: {err:?}"
    );
}

#[test]
fn a_noncanonical_lookup_pow_witness_at_zero_difficulty_is_rejected() {
    // Invariant: a zero-difficulty lookup grind binds the bit count, never the witness.
    //
    //     bits = 0 -> nothing absorbed, alpha and beta follow -> the value floats free
    //     bits > 0 -> absorbed, bits resampled                -> the grind pins it
    //
    // The step is described whatever the difficulty, so the pattern covers the count.
    // A count is not a value, so the value is pinned to the one an honest prover emits.
    //
    // Fixture state: two instances that declare lookups, lookup grinding at 0 bits.
    let config = make_config(2024);
    assert_eq!(config.lookup_proof_of_work_bits(), 0);
    let airs = lookup_grinding_airs();

    lookup_grinding_case(&config, &config, &airs, |proof| {
        assert_eq!(proof.lookup_pow_witness, Some(Val::ZERO));
    })
    .expect("an unground proof verifies");

    // Mutation: Some(0) -> Some(1), a second encoding of the very same statement.
    let err = lookup_grinding_case(&config, &config, &airs, |proof| {
        proof.lookup_pow_witness = Some(Val::ONE);
    })
    .expect_err("a rewritten lookup witness must be rejected");

    assert!(
        matches!(
            err,
            BatchVerificationError::Transcript(
                BatchTranscriptFailure::NonCanonicalLookupPowWitness
            )
        ),
        "wrong error variant: {err:?}"
    );
}

/// Difficulty small enough to grind instantly, large enough that a wrong
/// witness is rejected with overwhelming probability.
const OOD_POW_BITS: usize = 8;

/// A proof produced with out-of-domain grinding verifies.
#[test]
fn ood_grinding_round_trips() {
    let config = make_config(2024).with_ood_proof_of_work_bits(OOD_POW_BITS);
    let airs = lookup_grinding_airs();

    lookup_grinding_case(&config, &config, &airs, |_| {}).expect("ground proof verifies");
}

/// A tampered out-of-domain witness is rejected even at the difficulty the
/// proof was produced with, which is what makes the grind binding rather than
/// decorative.
#[test]
fn tampered_ood_pow_witness_is_rejected() {
    let config = make_config(2024).with_ood_proof_of_work_bits(OOD_POW_BITS);
    let airs = lookup_grinding_airs();

    let err = lookup_grinding_case(&config, &config, &airs, |proof| {
        proof.ood_pow_witness += Val::ONE;
    })
    .expect_err("a tampered witness must be rejected");

    assert!(
        matches!(
            err,
            BatchVerificationError::Transcript(BatchTranscriptFailure::OodPowWitness {
                bits: OOD_POW_BITS
            })
        ),
        "wrong error variant: {err:?}"
    );
}

/// A verifier demanding more out-of-domain grinding than the prover paid
/// rejects. This is the failure mode of a prover/verifier config mismatch,
/// and it must be a rejection rather than a silently weaker proof.
#[test]
fn ood_pow_difficulty_mismatch_is_rejected() {
    let prover_config = make_config(2024);
    let verifier_config = make_config(2024).with_ood_proof_of_work_bits(24);
    let airs = lookup_grinding_airs();

    let err = lookup_grinding_case(&prover_config, &verifier_config, &airs, |_| {})
        .expect_err("a difficulty mismatch must be rejected");

    assert!(
        matches!(
            err,
            BatchVerificationError::Transcript(BatchTranscriptFailure::OodPowWitness { bits: 24 })
        ),
        "wrong error variant: {err:?}"
    );
}

#[test]
fn a_noncanonical_ood_pow_witness_at_zero_difficulty_is_rejected() {
    // Invariant: a zero-difficulty out-of-domain grind binds the bit count, never the witness.
    //
    //     bits = 0 -> nothing absorbed, zeta follows -> the value floats free
    //     bits > 0 -> absorbed, bits resampled       -> the grind pins it
    //
    // Left unpinned, a third party rewrites the field and keeps a verifying proof.
    //
    // Fixture state: two instances, out-of-domain grinding at 0 bits.
    let config = make_config(2024);
    assert_eq!(config.ood_proof_of_work_bits(), 0);
    let airs = lookup_grinding_airs();

    lookup_grinding_case(&config, &config, &airs, |proof| {
        assert_eq!(proof.ood_pow_witness, Val::ZERO);
    })
    .expect("an unground proof verifies");

    // Mutation: 0 -> 1, a second encoding of the very same statement.
    let err = lookup_grinding_case(&config, &config, &airs, |proof| {
        proof.ood_pow_witness = Val::ONE;
    })
    .expect_err("a rewritten out-of-domain witness must be rejected");

    assert!(
        matches!(
            err,
            BatchVerificationError::Transcript(BatchTranscriptFailure::NonCanonicalOodPowWitness)
        ),
        "wrong error variant: {err:?}"
    );
}

#[test]
fn ood_pow_difficulty_past_the_field_order_is_rejected() {
    // Invariant: an out-of-domain difficulty the base field cannot sample is a rejection, not a panic.
    //
    // Fixture state: BabyBear, p = 15 * 2^27 + 1 = 2013265921.
    //
    //     b = 30:  2^30 = 1073741824 < p    the grind runs
    //     b = 31:  2^31 = 2147483648 > p    the bit sampler cannot draw b bits
    //     b = 64:  past the word size
    //
    // Mutation: verify an honest proof under each difficulty past the bound.
    let prover_config = make_config(2024);
    let airs = lookup_grinding_airs();

    for bits in [31, 64] {
        let verifier_config = make_config(2024).with_ood_proof_of_work_bits(bits);
        match lookup_grinding_case(&prover_config, &verifier_config, &airs, |_| {}) {
            Err(BatchVerificationError::Verification(
                VerificationError::UnsupportedOodPowBits { bits: got },
            )) => assert_eq!(got, bits),
            other => panic!("expected UnsupportedOodPowBits at {bits} bits, got {other:?}"),
        }
    }
}

#[test]
fn lookup_pow_difficulty_past_the_field_order_is_rejected() {
    // Invariant: a lookup difficulty the base field cannot sample is a rejection, not a panic.
    //
    // Fixture state: BabyBear, p = 15 * 2^27 + 1 = 2013265921, one instance declaring lookups.
    //
    //     b = 31:  2^31 = 2147483648 > p    the bit sampler cannot draw b bits
    //     b = 64:  past the word size
    //
    // Mutation: verify an honest proof under each difficulty past the bound.
    let prover_config = make_config(2024);
    let airs = lookup_grinding_airs();

    for bits in [31, 64] {
        let verifier_config = make_config(2024).with_lookup_proof_of_work_bits(bits);
        match lookup_grinding_case(&prover_config, &verifier_config, &airs, |_| {}) {
            Err(BatchVerificationError::UnsupportedLookupPowBits { bits: got }) => {
                assert_eq!(got, bits);
            }
            other => panic!("expected UnsupportedLookupPowBits at {bits} bits, got {other:?}"),
        }
    }
}

#[test]
fn lookup_pow_difficulty_is_unchecked_without_lookups() {
    // Invariant: a batch with no lookups never runs the lookup grind, so its difficulty is inert.
    //
    // Fixture state: two instances, neither declaring a lookup, lookup grinding at 31 bits.
    //
    //     lookups declared -> 31 bits rejected before the transcript
    //     none declared    -> no grind, the proof verifies
    //
    // Mutation: none, the honest proof verifies under the out-of-range lookup difficulty.
    let prover_config = make_config(2024);
    let verifier_config = make_config(2024).with_lookup_proof_of_work_bits(31);
    let airs = no_lookup_airs();

    lookup_grinding_case(&prover_config, &verifier_config, &airs, |_| {})
        .expect("a batch without lookups ignores the lookup difficulty");
}

#[test]
fn grinding_difficulty_bound_sits_at_thirty_bits() {
    // Invariant: the largest difficulty BabyBear samples is 30 bits, at both grinding sites.
    //
    // Fixture state: an honest proof produced with no grinding at all.
    //
    //     b = 0:   nothing to replay           -> the proof verifies
    //     b = 30:  2^30 < p, the grind replays  -> the zero witness misses it
    //     b = 31:  2^31 > p                     -> rejected before the transcript
    //
    // Mutation: raise one site's verifier difficulty at a time.
    let prover_config = make_config(2024);
    let airs = lookup_grinding_airs();

    lookup_grinding_case(&prover_config, &prover_config, &airs, |_| {})
        .expect("0 bits at both sites verifies");

    let ood_30 = make_config(2024).with_ood_proof_of_work_bits(30);
    assert!(
        matches!(
            lookup_grinding_case(&prover_config, &ood_30, &airs, |_| {}),
            Err(BatchVerificationError::Transcript(
                BatchTranscriptFailure::OodPowWitness { bits: 30 }
            ))
        ),
        "30 out-of-domain bits must reach the grind"
    );

    let ood_31 = make_config(2024).with_ood_proof_of_work_bits(31);
    assert!(
        matches!(
            lookup_grinding_case(&prover_config, &ood_31, &airs, |_| {}),
            Err(BatchVerificationError::Verification(
                VerificationError::UnsupportedOodPowBits { bits: 31 }
            ))
        ),
        "31 out-of-domain bits must be rejected up front"
    );

    let lookup_30 = make_config(2024).with_lookup_proof_of_work_bits(30);
    assert!(
        matches!(
            lookup_grinding_case(&prover_config, &lookup_30, &airs, |_| {}),
            Err(BatchVerificationError::Transcript(
                BatchTranscriptFailure::LookupPowWitness { bits: 30 }
            ))
        ),
        "30 lookup bits must reach the grind"
    );

    let lookup_31 = make_config(2024).with_lookup_proof_of_work_bits(31);
    assert!(
        matches!(
            lookup_grinding_case(&prover_config, &lookup_31, &airs, |_| {}),
            Err(BatchVerificationError::UnsupportedLookupPowBits { bits: 31 })
        ),
        "31 lookup bits must be rejected up front"
    );
}

/// Substituting one commitment for another leaves both absorbs bound to the wrong value.
#[test]
fn a_substituted_main_commitment_is_rejected() {
    let config = make_config(2024);
    let airs = lookup_grinding_airs();

    let err = lookup_grinding_case(&config, &config, &airs, |proof| {
        proof.commitments.main = proof.commitments.quotient_chunks.clone();
    })
    .expect_err("a main commitment the prover never committed to must be rejected");

    // The transcript diverges from the first absorb, so nothing downstream lines up.
    assert!(matches!(err, BatchVerificationError::Verification(_)));
}

/// The quotient commitment is absorbed before the out-of-domain point is drawn.
#[test]
fn a_substituted_quotient_commitment_is_rejected() {
    let config = make_config(2024);
    let airs = lookup_grinding_airs();

    let err = lookup_grinding_case(&config, &config, &airs, |proof| {
        proof.commitments.quotient_chunks = proof.commitments.main.clone();
    })
    .expect_err("a quotient commitment the prover never committed to must be rejected");

    assert!(matches!(err, BatchVerificationError::Verification(_)));
}

/// The permutation commitment is absorbed before the constraint-folding challenge.
#[test]
fn a_substituted_permutation_commitment_is_rejected() {
    let config = make_config(2024);
    let airs = lookup_grinding_airs();

    let err = lookup_grinding_case(&config, &config, &airs, |proof| {
        proof.commitments.permutation = Some(proof.commitments.main.clone());
    })
    .expect_err("a permutation commitment the prover never committed to must be rejected");

    assert!(matches!(err, BatchVerificationError::Verification(_)));
}

/// Each instance's degree bits are absorbed, so a proof cannot restate its own size.
#[test]
fn a_tampered_degree_bit_is_rejected() {
    let config = make_config(2024);
    let airs = lookup_grinding_airs();

    let err = lookup_grinding_case(&config, &config, &airs, |proof| {
        proof.degree_bits[0] += 1;
    })
    .expect_err("a degree bit the prover never absorbed must be rejected");

    assert!(matches!(err, BatchVerificationError::Verification(_)));
}

/// The randomization commitment exists only under a hiding PCS, and it is absorbed too.
#[test]
fn a_substituted_randomization_commitment_is_rejected() {
    let config = make_config_zk(1337);

    let (air_fib, fib_trace, fib_pis) = create_fib_instance(5);
    let instances = vec![StarkInstance {
        air: &air_fib,
        trace: &fib_trace,
        public_values: fib_pis.clone(),
    }];

    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let mut proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Swap in the main commitment, which is a real commitment to something else.
    proof.commitments.random = Some(proof.commitments.main.clone());

    let airs = vec![air_fib];
    let err = verify_batch(&config, &airs, &proof, from_ref(&fib_pis), common)
        .expect_err("a randomization commitment the prover never committed to must be rejected");

    assert!(matches!(err, BatchVerificationError::Verification(_)));
}

/// Test with global lookups only using MulAirLookups and FibAirLookups
#[test]
fn test_batch_stark_global_lookups_only() -> Result<(), impl Debug> {
    let config = make_config(2025);

    let reps = 2;
    // Create instances with global lookups configuration
    let mul_air = MulAir { reps };
    // Both global lookups (for each rep) look into the same FibAir inputs, so they share the same name.
    let mul_air_lookups = MulAirLookups::new(
        mul_air,
        false,
        true,
        vec!["MulFib".to_string(), "MulFib".to_string()],
    ); // global only

    let log_n = 3;
    let n = 1 << log_n;

    let fibonacci_air = FibonacciAir {
        log_height: log_n,
        tamper_index: None,
    };
    let fib_air_lookups = FibAirLookups::new(fibonacci_air, true, None); // global lookups

    let mul_trace = mul_trace::<Val>(n, 2);
    let fib_trace = fib_trace::<Val>(0, 1, n);
    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(n))];

    // Use the enum wrapper for heterogeneous types
    let air1 = DemoAirWithLookups::MulLookups(mul_air_lookups);
    let air2 = DemoAirWithLookups::FibLookups(fib_air_lookups);

    // Get lookups from the lookup-enabled AIRs
    let airs = [air1, air2];
    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_n, log_n]).unwrap();
    let common = &prover_data.common;
    let traces = [&mul_trace, &fib_trace];

    let instances = StarkInstance::new_multiple(&airs, &traces, &[vec![], fib_pis.clone()]);

    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    let pvs = vec![vec![], fib_pis];
    verify_batch(&config, &airs, &proof, &pvs, common)
}

#[test]
fn bus_width_mismatch_across_instances_is_rejected() {
    let config = make_config(2025);
    let log_n = 3;
    let n = 1 << log_n;

    // Fixture state: two instances share the bus "MulFib".
    //
    //     instance 0 (mul)  sends     (a, b)        width 2
    //     instance 1 (fib)  receives  (left, right) width 2
    let mul_air_lookups = MulAirLookups::new(
        MulAir { reps: 2 },
        false,
        true,
        vec!["MulFib".to_string(), "MulFib".to_string()],
    );
    let fib_air_lookups = FibAirLookups::new(
        FibonacciAir {
            log_height: log_n,
            tamper_index: None,
        },
        true,
        None,
    );
    let airs = [
        DemoAirWithLookups::MulLookups(mul_air_lookups),
        DemoAirWithLookups::FibLookups(fib_air_lookups),
    ];
    let mut prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_n, log_n]).unwrap();

    let mul_trace = mul_trace::<Val>(n, 2);
    let fib_trace = fib_trace::<Val>(0, 1, n);
    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(n))];
    let traces = [&mul_trace, &fib_trace];
    let instances = StarkInstance::new_multiple(&airs, &traces, &[vec![], fib_pis.clone()]);
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Mutation: the verifier's receiver reads a third payload field.
    //
    //     instance 1 (fib)  receives  (left, right, left)  width 3
    //
    // The degree and the column count are unchanged, so every shape check still passes.
    let receive = &prover_data.common.lookups[1][0];
    let mut fields = receive.elements[0].clone();
    fields.push(fields[0].clone());
    prover_data.common.lookups[1] = Lookups::from_interactions(
        &[SymbolicInteraction {
            bus_name: "MulFib".to_string(),
            fields,
            count: receive.multiplicities[0].clone(),
            count_weight: receive.count_weight,
        }],
        &[],
        &[],
    )
    .unwrap();

    // Invariant: one bus carries one payload width, or a short tuple aliases a long one.
    // The verifier names the bus and both widths, in instance order.
    let err = verify_batch(
        &config,
        &airs,
        &proof,
        &[vec![], fib_pis],
        &prover_data.common,
    )
    .unwrap_err();
    assert!(
        matches!(
            &err,
            BatchVerificationError::Lookup(LookupError::BusWidthMismatch {
                bus,
                expected: 2,
                actual: 3,
            }) if bus == "MulFib"
        ),
        "unexpected error: {err:?}"
    );
}

/// Test with both local and global lookups using MulAirLookups and FibAirLookups
#[test]
fn test_batch_stark_both_lookups() -> Result<(), impl Debug> {
    let config = make_config(2026);

    let reps = 2;
    // Create instances with both local and global lookups configuration
    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(
        mul_air,
        true,
        true,
        vec!["MulFib".to_string(), "MulFib".to_string()],
    ); // both

    let log_height = 4;
    let height = 1 << log_height;

    let fibonacci_air = FibonacciAir {
        log_height,
        tamper_index: None,
    };
    let fib_air_lookups = FibAirLookups::new(fibonacci_air, true, None); // global lookups

    let mul_trace = mul_trace::<Val>(height, 2);
    let fib_trace = fib_trace::<Val>(0, 1, height);
    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(16))];

    // Use the enum wrapper for heterogeneous types
    let air1 = DemoAirWithLookups::MulLookups(mul_air_lookups);
    let air2 = DemoAirWithLookups::FibLookups(fib_air_lookups);

    let airs = [air1, air2];
    // Get lookups from the lookup-enabled AIRs
    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_height, log_height])
            .unwrap();
    let common = &prover_data.common;
    let traces = [&mul_trace, &fib_trace];

    let instances = StarkInstance::new_multiple(&airs, &traces, &[vec![], fib_pis.clone()]);

    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    let pvs = vec![vec![], fib_pis];
    verify_batch(&config, &airs, &proof, &pvs, common)
}

/// Test with both local and global lookups using MulAirLookups and FibAirLookups, with ZK mode activated
#[test]
fn test_batch_stark_both_lookups_zk() -> Result<(), impl Debug> {
    let config = make_config_zk(2026);

    let reps = 2;
    // Create instances with both local and global lookups configuration
    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(
        mul_air,
        true,
        true,
        vec!["MulFib".to_string(), "MulFib".to_string()],
    ); // both

    let log_height = 5;
    let height = 1 << log_height;

    let fibonacci_air = FibonacciAir {
        log_height,
        tamper_index: None,
    };
    let fib_air_lookups = FibAirLookups::new(fibonacci_air, true, None); // global lookups

    let mul_trace = mul_trace::<Val>(height, 2);
    let fib_trace = fib_trace::<Val>(0, 1, height);
    let fib_pis = vec![
        Val::from_u64(0),
        Val::from_u64(1),
        Val::from_u64(fib_n(height)),
    ];

    // Use the enum wrapper for heterogeneous types
    let air1 = DemoAirWithLookups::MulLookups(mul_air_lookups);
    let air2 = DemoAirWithLookups::FibLookups(fib_air_lookups);

    let airs = [air1, air2];
    // Get lookups from the lookup-enabled AIRs
    let prover_data = ProverData::<MyHidingConfig>::from_airs_and_degrees(
        &config,
        &airs,
        &[log_height + config.is_zk(), log_height + config.is_zk()],
    )
    .unwrap();
    let common = &prover_data.common;
    let traces = [&mul_trace, &fib_trace];

    let instances = StarkInstance::new_multiple(&airs, &traces, &[vec![], fib_pis.clone()]);

    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    let derived: usize = airs
        .iter()
        .zip(&proof.opened_values.instances)
        .enumerate()
        .map(|(i, (air, opened))| {
            p3_batch_stark::security::num_batched_openings(
                <DemoAirWithLookups as BaseAir<Val>>::width(air),
                !<DemoAirWithLookups as BaseAir<Val>>::main_next_row_columns(air).is_empty(),
                <DemoAirWithLookups as BaseAir<Val>>::preprocessed_width(air),
                !<DemoAirWithLookups as BaseAir<Val>>::preprocessed_next_row_columns(air)
                    .is_empty(),
                opened.base_opened_values.quotient_chunks.len(),
                common.lookups[i].len(),
                4,
                OpeningShape::hiding(4),
            )
        })
        .sum();
    let public: usize = proof
        .opened_values
        .instances
        .iter()
        .map(|opened| {
            let base = &opened.base_opened_values;
            base.trace_local.len()
                + base.trace_next.as_ref().map_or(0, Vec::len)
                + base.preprocessed_local().map_or(0, <[_]>::len)
                + base.preprocessed_next().map_or(0, <[_]>::len)
                + base.quotient_chunks.iter().map(Vec::len).sum::<usize>()
                + base.random.as_ref().map_or(0, Vec::len)
                + opened.permutation_local.len()
                + opened.permutation_next.len()
        })
        .sum();
    let hiding: usize = proof
        .opening_proof
        .0
        .iter()
        .flatten()
        .flatten()
        .map(Vec::len)
        .sum();
    assert_eq!(derived, public + hiding);

    let pvs = vec![vec![], fib_pis];
    verify_batch(&config, &airs, &proof, &pvs, common)
}

#[cfg(not(debug_assertions))]
#[test]
#[should_panic(expected = "Lookup(TerminalSumNonZero)")]
fn test_batch_stark_failed_global_lookup() {
    test_batch_stark_failed_global_lookup_inner();
}

#[cfg(debug_assertions)]
#[test]
#[should_panic(
    expected = "Lookup mismatch (global lookup 'MulFib2'): tuple [\"0\", \"1\"] has net multiplicity 2013265920. Locations: [Location { instance: 0, lookup: 1, row: 0 }]"
)]
fn test_batch_stark_failed_global_lookup() {
    test_batch_stark_failed_global_lookup_inner();
}

fn test_batch_stark_failed_global_lookup_inner() {
    let config = make_config(2025);

    let reps = 2;
    // Create instances with global lookups configuration
    let mul_air = MulAir { reps };
    // MulAir uses two different names for its reps, which will create two separate global lookups
    let mul_air_lookups = MulAirLookups::new(
        mul_air,
        false,
        true,
        vec!["MulFib1".to_string(), "MulFib2".to_string()], // Different names!
    );
    // This creates a mismatch: MulAir sends to "MulFib1" and "MulFib2"
    // but FibAir only receives from "MulFib1"
    let log_n = 3;
    let n = 1 << log_n;
    let fibonacci_air = FibonacciAir {
        log_height: log_n,
        tamper_index: None,
    };
    let fib_air_lookups = FibAirLookups::new(fibonacci_air, true, Some(("MulFib1".to_string(), 1)));

    let mul_trace = mul_trace::<Val>(n, 2);
    let fib_trace = fib_trace::<Val>(0, 1, n);

    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(n))];
    let traces = [&mul_trace, &fib_trace];
    let pvs = vec![vec![], fib_pis];
    // Use the enum wrapper for heterogeneous types
    let air1 = DemoAirWithLookups::MulLookups(mul_air_lookups);
    let air2 = DemoAirWithLookups::FibLookups(fib_air_lookups);

    // Get lookups from the lookup-enabled AIRs
    let airs = [air1, air2];
    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_n, log_n]).unwrap();
    let common = &prover_data.common;

    let instances = StarkInstance::new_multiple(&airs, &traces, &pvs);

    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Imbalance: MulAir sends on "MulFib1" and "MulFib2"; only "MulFib1" is received.
    //
    // - Debug:   the prover's lookup checker panics first, naming the bus.
    // - Release: the cross-AIR terminal sum is non-zero, so the verifier rejects.
    verify_batch(&config, &airs, &proof, &pvs, common).unwrap();
}

#[test]
fn test_batch_stark_rejects_missing_lookup_terminal() {
    let config = make_config(2025);

    let reps = 2;
    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(
        mul_air,
        false,
        true,
        vec!["MulFib".to_string(), "MulFib".to_string()],
    );

    let log_n = 3;
    let n = 1 << log_n;
    let fibonacci_air = FibonacciAir {
        log_height: log_n,
        tamper_index: None,
    };
    let fib_air_lookups = FibAirLookups::new(fibonacci_air, true, None);

    let mul_trace = mul_trace::<Val>(n, 2);
    let fib_trace = fib_trace::<Val>(0, 1, n);
    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(n))];

    let air1 = DemoAirWithLookups::MulLookups(mul_air_lookups);
    let air2 = DemoAirWithLookups::FibLookups(fib_air_lookups);

    let airs = [air1, air2];
    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_n, log_n]).unwrap();
    let common = &prover_data.common;
    let traces = [&mul_trace, &fib_trace];
    let pvs = vec![vec![], fib_pis];

    let instances = StarkInstance::new_multiple(&airs, &traces, &pvs);
    let mut proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // AIR 0 declares lookups so its terminal must be `Some(_)`.
    //
    // Mutation: drop the terminal → presence-check should reject the proof.
    proof.lookup_terminals[0] = None;

    let err = verify_batch(&config, &airs, &proof, &pvs, common)
        .expect_err("Verifier should reject a missing per-AIR lookup terminal");
    match err {
        BatchVerificationError::Lookup(LookupError::TerminalPresenceMismatch {
            air,
            expected_present,
            got_present,
        }) => {
            assert_eq!(air, 0);
            assert!(expected_present);
            assert!(!got_present);
        }
        _ => panic!("unexpected error: {err:?}"),
    }
}

#[test]
fn test_batch_stark_rejects_spurious_lookup_terminal() {
    // Invariant: a lookup-less AIR commits `None`, never a terminal.
    // Attack:    inject `Some(_)` there to skew the cross-AIR terminal sum.
    // Defense:   the presence check rejects the shape before any value is read.
    let config = make_config(2025);

    // Fixture state — a balanced batch with one genuinely lookup-less AIR:
    //
    //     AIR 0  MulAir  sends twice on bus "MulFib"  → terminal Some(_)
    //     AIR 1  FibAir  receives on bus "MulFib"     → terminal Some(_)
    //     AIR 2  FibAir  no lookups                   → terminal None
    let reps = 2;
    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(
        mul_air,
        false,
        true,
        vec!["MulFib".to_string(), "MulFib".to_string()],
    );

    let log_n = 3;
    let n = 1 << log_n;
    let fibonacci_air = FibonacciAir {
        log_height: log_n,
        tamper_index: None,
    };
    // Second arg `true` makes this AIR receive on the shared bus.
    let fib_air_receiver = FibAirLookups::new(fibonacci_air, true, None);
    // Second arg `false` leaves this AIR with no interactions at all.
    let fib_air_no_lookups = FibAirLookups::new(fibonacci_air, false, None);

    let mul_trace = mul_trace::<Val>(n, 2);
    let fib_trace = fib_trace::<Val>(0, 1, n);
    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(n))];

    let airs = [
        DemoAirWithLookups::MulLookups(mul_air_lookups),
        DemoAirWithLookups::FibLookups(fib_air_receiver),
        DemoAirWithLookups::FibLookups(fib_air_no_lookups),
    ];
    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_n, log_n, log_n])
            .unwrap();
    let common = &prover_data.common;
    let traces = [&mul_trace, &fib_trace, &fib_trace];
    let pvs = vec![vec![], fib_pis.clone(), fib_pis];

    let instances = StarkInstance::new_multiple(&airs, &traces, &pvs);
    let mut proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Mutation: AIR 2 declares no lookups, yet we attach an arbitrary terminal.
    //
    //     lookup_terminals: [Some(t0), Some(t1), None ]
    //                                              ↓ should stay None
    //                       [Some(t0), Some(t1), Some(42)]
    proof.lookup_terminals[2] = Some(LookupTerminal(Challenge::from_u64(42)));

    let err = verify_batch(&config, &airs, &proof, &pvs, common)
        .expect_err("Verifier should reject a spurious terminal on a lookup-less AIR");
    match err {
        BatchVerificationError::Lookup(LookupError::TerminalPresenceMismatch {
            air,
            expected_present,
            got_present,
        }) => {
            // AIR 2 is the lookup-less instance: expected absent, got present.
            assert_eq!(air, 2);
            assert!(!expected_present);
            assert!(got_present);
        }
        _ => panic!("unexpected error: {err:?}"),
    }
}

#[test]
fn test_batch_stark_rejects_mixed_tuple_widths_in_common_data() {
    let config = make_config(2025);

    // Fixture state: an honest batch whose lookups balance on bus "MulFib".
    //
    //     AIR 0  MulAir  sends twice on bus "MulFib"
    //     AIR 1  FibAir  receives on bus "MulFib"
    let reps = 2;
    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(
        mul_air,
        false,
        true,
        vec!["MulFib".to_string(), "MulFib".to_string()],
    );

    let log_n = 3;
    let n = 1 << log_n;
    let fibonacci_air = FibonacciAir {
        log_height: log_n,
        tamper_index: None,
    };
    let fib_air_lookups = FibAirLookups::new(fibonacci_air, true, None);

    let mul_trace = mul_trace::<Val>(n, 2);
    let fib_trace = fib_trace::<Val>(0, 1, n);
    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(n))];

    let airs = [
        DemoAirWithLookups::MulLookups(mul_air_lookups),
        DemoAirWithLookups::FibLookups(fib_air_lookups),
    ];
    let mut prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_n, log_n]).unwrap();
    let traces = [&mul_trace, &fib_trace];
    let pvs = vec![vec![], fib_pis];

    let instances = StarkInstance::new_multiple(&airs, &traces, &pvs);
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Mutation: AIR 0's first lookup gains a tuple one element wider than its others.
    //
    //     before   slot 0   [a, b]              width 2
    //     after    slot 0   [a, b], [1, 1, 1]   widths 2 and 3
    //
    // The lookups go through serialization, which rebuilds them as is.
    //
    // The slot count stays 2, so the proof's lookup columns still fit.
    let mut mixed = prover_data.common.lookups[0].to_vec();
    let width = mixed[0].elements[0].len();
    let one = SymbolicExpression::<Val>::from(Val::ONE);
    mixed[0].elements.push(vec![one.clone(); width + 1]);
    mixed[0].multiplicities.push(one);
    let bytes = postcard::to_allocvec(&mixed).unwrap();
    prover_data.common.lookups[0] = postcard::from_bytes::<Lookups<Val>>(&bytes).unwrap();

    // Invariant: the verifier refuses the layout before it draws the lookup challenges.
    let result = verify_batch(&config, &airs, &proof, &pvs, &prover_data.common);
    let Err(BatchVerificationError::Lookup(LookupError::TupleWidthMismatch {
        column,
        expected,
        actual,
    })) = result
    else {
        panic!("expected a tuple width mismatch, got {result:?}");
    };
    assert_eq!((column, expected, actual), (0, 2, 3));
}

#[test]
fn test_batch_stark_rejects_tampered_lookup_terminal_value() {
    // Invariant: every committed terminal is bound by the proof.
    //
    // It feeds the transcript before the folding challenge and OOD point.
    // Rewriting it desyncs the verifier and breaks the out-of-domain identity.
    let config = make_config(2025);

    // Fixture state — a balanced two-AIR bus:
    //
    //     AIR 0  MulAir  sends twice on bus "MulFib"  → genuine terminal
    //     AIR 1  FibAir  receives on bus "MulFib"
    let reps = 2;
    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(
        mul_air,
        false,
        true,
        vec!["MulFib".to_string(), "MulFib".to_string()],
    );

    let log_n = 3;
    let n = 1 << log_n;
    let fibonacci_air = FibonacciAir {
        log_height: log_n,
        tamper_index: None,
    };
    let fib_air_lookups = FibAirLookups::new(fibonacci_air, true, None);

    let mul_trace = mul_trace::<Val>(n, 2);
    let fib_trace = fib_trace::<Val>(0, 1, n);
    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(n))];

    let airs = [
        DemoAirWithLookups::MulLookups(mul_air_lookups),
        DemoAirWithLookups::FibLookups(fib_air_lookups),
    ];
    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_n, log_n]).unwrap();
    let common = &prover_data.common;
    let traces = [&mul_trace, &fib_trace];
    let pvs = vec![vec![], fib_pis];

    let instances = StarkInstance::new_multiple(&airs, &traces, &pvs);
    let mut proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Mutation: bump AIR 0's terminal by one field element.
    //
    //     terminal[0]: t  →  t + 1
    //
    // Shape stays `Some(_)`, so this tests value binding, not presence.
    let original = proof.lookup_terminals[0]
        .expect("AIR 0 declares lookups, so its terminal is present")
        .0;
    proof.lookup_terminals[0] = Some(LookupTerminal(original + Challenge::ONE));

    verify_batch(&config, &airs, &proof, &pvs, common)
        .expect_err("Verifier should reject a tampered terminal value");
}

/// Test mixing instances with lookups and instances without lookups.
/// We have the following instances:
/// - MulAir with both local and global lookups (looking into two different FibAir instances for each rep)
/// - FibAir without lookups
/// - FibAir with global lookups (sends values for first rep of MulAir)
/// - MulAir without lookups
/// - FibAir with global lookups (sends values for second rep of MulAir)
/// - MulAir with local lookups only
macro_rules! run_batch_stark_mixed_lookups {
    ($config:expr, $ConfigTy:ty) => {{
        let config: $ConfigTy = $config;

        let reps = 2;

        // Create instances with different lookup configurations:
        let mul_air_with_lookups = MulAir { reps };
        // This AIR has two different global lookups (one for each rep) with two different names.
        // It also has two local lookups (one for each rep).
        let mul_air_lookups = MulAirLookups::new(
            mul_air_with_lookups,
            true,
            true,
            vec!["MulFib1".to_string(), "MulFib2".to_string()],
        );
        // This AIR has no lookups.
        let mul_air_no_lookups =
            MulAirLookups::new(mul_air_with_lookups, false, false, vec![]);
        // This AIR only has local lookups.
        let mul_air_local_lookups =
            MulAirLookups::new(mul_air_with_lookups, true, false, vec![]); // local lookups only

        let log_n1 = 4; // 16 rows
        let log_n2 = 3; // 8 rows
        let n1 = 1 << log_n1;
        let n2 = 1 << log_n2;

        let fib_air_lookups = FibonacciAir {
            log_height: log_n1,
            tamper_index: None,
        };

        let fib_air_no_lookups = FibonacciAir {
            log_height: log_n2,
            tamper_index: None,
        };

        // The mul air with global lookups looks into two different Fibonacci instances.
        // So we have to create two separate FibAir instances with a different global lookup name.
        let fib_air_with_lookups1 = FibAirLookups::new(
            fib_air_lookups,
            true,
            Some(("MulFib1".to_string(), 1)),
        ); // global lookups
        let fib_air_with_lookups2 = FibAirLookups::new(
            fib_air_lookups,
            true,
            Some(("MulFib2".to_string(), 1)),
        ); // global lookups
        let fib_air_no_lookups =
            FibAirLookups::new(fib_air_no_lookups, false, None); // global lookups

        // Generate traces. The airs with and without lookups have different heights.
        let mul_with_lookups_trace = mul_trace::<Val>(n1, reps);
        let fib_with_lookups_trace = fib_trace::<Val>(0, 1, n1);
        let mul_no_lookups_trace = mul_trace::<Val>(n2, reps);
        let fib_no_lookups_trace = fib_trace::<Val>(0, 1, n2);

        // Public values
        let fib_with_lookups_pis =
            vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(16))];
        let fib_no_lookups_pis =
            vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(8))];

        // Create lookup-enabled AIRs
        let air_mul_with_lookups = DemoAirWithLookups::MulLookups(mul_air_lookups);
        let air_fib_with_lookups1 = DemoAirWithLookups::FibLookups(fib_air_with_lookups1);
        let air_fib_with_lookups2 = DemoAirWithLookups::FibLookups(fib_air_with_lookups2);
        let air_mul_with_local_lookups =
            DemoAirWithLookups::MulLookups(mul_air_local_lookups);

        // Create non-lookup AIRs
        let air_mul_no_lookups = DemoAirWithLookups::MulLookups(mul_air_no_lookups);
        let air_fib_no_lookups = DemoAirWithLookups::FibLookups(fib_air_no_lookups);

        let mut all_airs = vec![
            air_mul_with_lookups,
            air_fib_no_lookups,
            air_fib_with_lookups1,
            air_mul_no_lookups,
            air_fib_with_lookups2,
            air_mul_with_local_lookups,
        ];

        // Get all lookups
        let prover_data = ProverData::<$ConfigTy>::from_airs_and_degrees(
            &config,
            &mut all_airs,
            &[log_n1, log_n2, log_n1, log_n2, log_n1, log_n1],
        ).unwrap();
        let common = &prover_data.common;

        let traces = [&mul_with_lookups_trace, &fib_no_lookups_trace, &fib_with_lookups_trace, &mul_no_lookups_trace, &fib_with_lookups_trace, &mul_with_lookups_trace];

        // Get all public values
        let all_pvs = vec![
            vec![],                       // mul with lookups
            fib_no_lookups_pis,           // fib no lookups
            fib_with_lookups_pis.clone(), // fib with lookups
            vec![],                       // mul no lookups
            fib_with_lookups_pis,         // fib with lookups
            vec![],                       // mul with local lookups
        ];

        // Create instances - mixing lookup and non-lookup instances
        let instances = StarkInstance::new_multiple(&all_airs, &traces, &all_pvs);

        let proof = prove_batch(&config, &instances, &prover_data).unwrap();

        // Verify with mixed AIRs
        verify_batch(&config, &all_airs, &proof, &all_pvs, common)
    }};
}

#[test]
fn test_batch_stark_mixed_lookups() -> Result<(), impl Debug> {
    run_batch_stark_mixed_lookups!(make_config(2027), MyConfig)
}

#[test]
fn test_batch_stark_mixed_lookups_wide() -> Result<(), impl Debug> {
    run_batch_stark_mixed_lookups!(make_config_wide(2027), MyConfigWide)
}

// Single table with local lookup involving the Lagrange selectors. Since the selectors are not normalized,
// we need to add multiplicity columns and multiply them by the selectors.
#[derive(Debug, Clone, Copy)]
struct SingleTableLocalLookupAir;

impl<F> BaseAir<F> for SingleTableLocalLookupAir {
    fn width(&self) -> usize {
        7
    }
}

impl<AB> Air<AB> for SingleTableLocalLookupAir
where
    AB::Var: Debug,
    AB: AirBuilder + PermutationAirBuilder + InteractionBuilder,
{
    fn eval(&self, builder: &mut AB) {
        let main = builder.main();
        let local = main.current_slice();

        let sender1 = local[0];
        let sender2 = local[1];
        let sender3 = local[2];
        let table = local[3];
        let mul1 = local[4];
        let mul2 = local[5];
        let mul3 = local[6];

        let is_first = builder.is_first_row();
        let is_trans = builder.is_transition();
        let is_last = builder.is_last_row();

        // Three independent local lookups, each with a different selector.
        // Lagrange selectors are not normalized, so we multiply on both sides.
        builder.push_local_interaction(vec![
            (vec![sender1.into()], Count::bounded(is_first.clone(), 1)),
            (
                vec![table.into()],
                Count::provided(-(is_first * mul1.into())),
            ),
        ]);

        builder.push_local_interaction(vec![
            (vec![sender2.into()], Count::bounded(is_trans.clone(), 1)),
            (
                vec![table.into()],
                Count::provided(-(is_trans * mul2.into())),
            ),
        ]);

        builder.push_local_interaction(vec![
            (vec![sender3.into()], Count::bounded(is_last.clone(), 1)),
            (
                vec![table.into()],
                Count::provided(-(is_last * mul3.into())),
            ),
        ]);
    }
}

// Trace generation function for single table with local lookup
fn single_table_local_lookup_trace<F: Field>(height: usize) -> RowMajorMatrix<F> {
    assert!(height.is_power_of_two());
    assert!(height >= 2); // Need at least some transition rows and last row

    let width = 7;
    let mut v = F::zero_vec(height * width); // 2 columns
    // Column 0: all rows: value height - 1
    // Column 1: all rows except last: 7 to 1, and last value is 11
    // Column 2: all rows are 11 except last row which is 0
    // Column 3: Lookup table column: values 7 to 0
    // Column 4: (mult1) 1 at row 0, 0 elsewhere
    // Column 5: (mult2) 1 everywhere except last row, which is 0
    // Column 6: (mult3) 1 at last row, 0 elsewhere
    for i in 0..height {
        // Sender columns:
        // Column 0
        v[i * width] = F::from_u64((height - 1) as u64);
        // Column 1
        v[i * width + 1] = if i < height - 1 {
            F::from_u64((height - i - 1) as u64)
        } else {
            F::from_u64(11) // Last row value
        };
        // Column 2
        if i != height - 1 {
            v[i * width + 2] = F::from_u64(11);
        }
        // Column 3: lookup table column
        v[i * width + 3] = F::from_u64((height - i - 1) as u64);
        // Multiplicity columns
        v[i * width + 4] = if i == 0 { F::ONE } else { F::ZERO }; // mult1: is_first_row
        v[i * width + 5] = if i < height - 1 { F::ONE } else { F::ZERO }; // mult2: is_transition
        v[i * width + 6] = if i == height - 1 { F::ONE } else { F::ZERO }; // mult3: is_last_row
    }

    RowMajorMatrix::new(v, width)
}

/// Test with a single table doing local lookup between its two columns.
/// The goal of this test is to check that the use of (non-normalized) Lagrange selectors does not cause issues.
#[test]
fn test_single_table_local_lookup() -> Result<(), impl Debug> {
    let config = make_config(2029);

    let log_height = 3;
    let height = 1 << log_height; // Single table with 8 rows

    let air = SingleTableLocalLookupAir;
    let airs = [air];

    // Get lookups from the lookup-enabled AIR
    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_height]).unwrap();
    let common = &prover_data.common;

    // Generate trace
    let trace = single_table_local_lookup_trace::<Val>(height);

    let traces = [&trace];
    let pvs = vec![vec![]]; // No public values

    let instances = StarkInstance::new_multiple(&airs, &traces, &pvs);

    let proof = prove_batch(&config, &instances, &prover_data).unwrap();

    verify_batch(&config, &airs, &proof, &pvs, common)
}

#[test]
fn test_invalid_permutation_opening_len_rejected() {
    // Tampering with permutation_local length should return Err, not panic.
    let config = make_config(9999);

    let log_height = 4;
    let height = 1 << log_height;
    let mul_air = MulAir { reps: 2 };
    let mul_air_lookups = MulAirLookups::new(mul_air, true, false, vec![]);
    let fib_air_lookups = FibAirLookups::new(
        FibonacciAir {
            log_height,
            tamper_index: None,
        },
        false,
        None,
    );

    let mul_trace = mul_trace::<Val>(height, 2);
    let fib_trace = fib_trace::<Val>(0, 1, 16);
    let fib_pis = vec![Val::from_u64(0), Val::from_u64(1), Val::from_u64(fib_n(16))];

    let air1 = DemoAirWithLookups::MulLookups(mul_air_lookups);
    let air2 = DemoAirWithLookups::FibLookups(fib_air_lookups);
    let airs = [air1, air2];

    let prover_data =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_height, log_height])
            .unwrap();
    let common = &prover_data.common;
    let traces = [&mul_trace, &fib_trace];

    let instances = StarkInstance::new_multiple(&airs, &traces, &[vec![], fib_pis.clone()]);
    let mut proof = prove_batch(&config, &instances, &prover_data).unwrap();

    // Find the instance with non-empty permutation openings and truncate it.
    let inst = proof
        .opened_values
        .instances
        .iter_mut()
        .find(|i| !i.permutation_local.is_empty())
        .expect("should have an instance with permutation openings");
    inst.permutation_local.pop();

    let pvs = vec![vec![], fib_pis];
    let res = verify_batch(&config, &airs, &proof, &pvs, common);
    assert!(
        res.is_err(),
        "Verifier should reject permutation opening with wrong length"
    );
}

// --- Lookup-packing budget override ---

/// The `log_blowup` every `FriParameters::new_testing` config in this file uses, and so the
/// quotient-chunk ceiling `from_airs_and_degrees_with_lookup_budgets` holds overrides to.
const TESTING_LOG_BLOWUP: usize = 2;

/// Build a single `MulAirLookups` instance whose global lookups all target the same bus,
/// so `pack_same_bus` has multiple same-bus interactions available to fold.
fn mul_air_with_n_same_bus_lookups(reps: usize) -> (DemoAirWithLookups, usize) {
    let mul_air = MulAir { reps };
    let mul_air_lookups = MulAirLookups::new(mul_air, false, true, vec!["Bus".to_string(); reps]);
    let log_height = 4; // 16 rows
    (DemoAirWithLookups::MulLookups(mul_air_lookups), log_height)
}

#[test]
fn from_airs_and_degrees_with_lookup_budgets_at_zero_matches_the_free_budget() {
    let config = make_config(2028);
    let (air, log_height) = mul_air_with_n_same_bus_lookups(4);
    let airs = [air];

    let default =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_height]).unwrap();
    let overridden = ProverData::<MyConfig>::from_airs_and_degrees_with_lookup_budgets(
        &config,
        &airs,
        &[log_height],
        &[0],
        TESTING_LOG_BLOWUP,
    )
    .unwrap();

    assert_eq!(
        format!("{:?}", default.common.lookups),
        format!("{:?}", overridden.common.lookups),
        "a zero override must reproduce the free-budget packing exactly"
    );
}

#[test]
fn from_airs_and_degrees_with_lookup_budgets_packs_past_the_free_budget() {
    let config = make_config(2029);
    let (air, log_height) = mul_air_with_n_same_bus_lookups(4);
    let airs = [air];

    let free =
        ProverData::<MyConfig>::from_airs_and_degrees(&config, &airs, &[log_height]).unwrap();
    let free_num_lookups = free.common.lookups[0].len();

    // An override past the free ceiling forces same-bus interactions into fewer columns,
    // spending quotient chunks to do it. `4` keeps the resulting bucket inside the testing
    // config's blowup; see the panic test below for what happens when it doesn't.
    let forced = ProverData::<MyConfig>::from_airs_and_degrees_with_lookup_budgets(
        &config,
        &airs,
        &[log_height],
        &[4],
        TESTING_LOG_BLOWUP,
    )
    .unwrap();
    let forced_num_lookups = forced.common.lookups[0].len();

    assert!(
        forced_num_lookups < free_num_lookups,
        "override must pack past the free ceiling: free={free_num_lookups}, forced={forced_num_lookups}"
    );
}

#[test]
#[should_panic(expected = "past the PCS blowup")]
fn from_airs_and_degrees_with_lookup_budgets_rejects_overshooting_the_blowup() {
    let config = make_config(2030);
    let (air, log_height) = mul_air_with_n_same_bus_lookups(6);
    let airs = [air];

    // Folding six same-bus interactions into one column pushes the quotient bucket well past
    // the rate budget of a `log_blowup = 1` low-degree test. Nothing downstream detects that,
    // so it has to fail here, at setup.
    let _ = ProverData::<MyConfig>::from_airs_and_degrees_with_lookup_budgets(
        &config,
        &airs,
        &[log_height],
        &[usize::MAX],
        1,
    )
    .unwrap();
}

/// The three protocols a batch-STARK proof over `p3-fri` layers, outermost first.
///
/// Each brackets the next, and each seeds its own transcript, so the same step
/// label in two of them is two different steps.
const BATCH_STARK_STACK: [&str; 3] = ["p3-batch-stark", "p3-fri-pcs", "p3-fri"];

/// Every grinding difficulty the three transcripts of one configuration demand.
///
/// Fixture state: two traces of width 2 and 3, one preprocessed commitment.
///
/// Nothing but the difficulties and whether the lookup phase runs reaches the result.
fn demanded_grinding(
    fri: &FriParameters<()>,
    num_lookup_instances: usize,
    lookup_pow_bits: usize,
    ood_pow_bits: usize,
) -> Vec<RecordedGrind> {
    let batch = BatchShape {
        trace_widths: vec![2, 3],
        public_value_counts: vec![0, 3],
        preprocessed_widths: vec![0, 1],
        has_preprocessed_commitment: true,
        num_lookup_instances,
        lookup_pow_bits,
        has_randomization_commitment: false,
        ood_pow_bits,
    };
    let opening = PcsShape {
        claimed_evaluation_counts: vec![vec![vec![3]]],
        batch_pow_bits: fri.batch_proof_of_work_bits,
    };
    let ldt = FriShape::with_schedule(fri, vec![2, 2], 8);

    let patterns = [
        batch.pattern::<Val, Challenge>(),
        opening.pattern::<Val, Challenge>(),
        ldt.pattern::<Val, Challenge>(),
    ];

    BATCH_STARK_STACK
        .iter()
        .zip(&patterns)
        .flat_map(|(protocol, pattern)| {
            pow_difficulties(pattern)
                .into_iter()
                .map(|(label, bits)| RecordedGrind::new(protocol, label, bits))
        })
        .collect()
}

#[test]
fn recorded_grinding_matches_what_the_security_model_credits() {
    // Property: recorded difficulty == credited difficulty, at every site.
    //
    // A batch-STARK exercises all three zero-bit conventions in one stack:
    //
    //     ood_pow     ->  always described
    //     lookup_pow  ->  described only while the lookup phase runs
    //     FRI sites   ->  elided at zero
    //
    // Reading an absent step as zero bits would therefore be wrong twice over.

    // The parameters the config feeds its PCS, with the commitment scheme
    // dropped: only the difficulties matter here.
    let base = FriParameters::new_testing((), 2);

    for batch_pow_bits in [0, 10] {
        for lookup_pow_bits in [0, 12] {
            for ood_pow_bits in [0, 8] {
                for num_lookup_instances in [0, 2] {
                    let fri = FriParameters {
                        batch_proof_of_work_bits: batch_pow_bits,
                        ..base
                    };

                    // The FRI sites, plus the two the batch itself enforces.
                    let credited = GrindingBudget::from_sites(&GrindingSites {
                        out_of_domain: ood_pow_bits,
                        lookup_challenge: lookup_pow_bits,
                        ..fri.grinding_sites()
                    })
                    .with_fri(&fri.security_regime());

                    credited
                        .check(
                            &BATCH_STARK_STACK,
                            &demanded_grinding(
                                &fri,
                                num_lookup_instances,
                                lookup_pow_bits,
                                ood_pow_bits,
                            ),
                        )
                        .unwrap_or_else(|mismatch| {
                            panic!(
                                "batch={batch_pow_bits} lookup={lookup_pow_bits} \
                                 ood={ood_pow_bits} instances={num_lookup_instances}: {mismatch}"
                            )
                        });
                }
            }
        }
    }
}

#[test]
fn the_lookup_grinding_configuration_is_accounted_for() {
    // The config the lookup-grinding tests prove with is itself accounted for.
    //
    // The numbers it hands the prover are the numbers a security report is built from.
    let config = make_config(2024).with_lookup_proof_of_work_bits(LOOKUP_POW_BITS);
    let fri = FriParameters::new_testing((), 2);

    let lookup_pow_bits = config.lookup_proof_of_work_bits();
    let ood_pow_bits = config.ood_proof_of_work_bits();
    assert_eq!((lookup_pow_bits, ood_pow_bits), (LOOKUP_POW_BITS, 0));

    GrindingBudget::from_sites(&GrindingSites {
        out_of_domain: ood_pow_bits,
        lookup_challenge: lookup_pow_bits,
        ..fri.grinding_sites()
    })
    .with_fri(&fri.security_regime())
    .check(
        &BATCH_STARK_STACK,
        &demanded_grinding(&fri, 2, lookup_pow_bits, ood_pow_bits),
    )
    .unwrap_or_else(|mismatch| panic!("{mismatch}"));
}

// Direct helper calls do not inherit verify_batch's preflight checks.
fn opening_helper_inputs() -> (
    p3_batch_stark::proof::BatchCommitments<p3_batch_stark::config::Commitment<MyConfig>>,
    p3_batch_stark::proof::BatchOpenedValues<Challenge>,
) {
    let commitment = p3_symmetric::MerkleCap::new(vec![[Val::ZERO; 8]]);
    (
        p3_batch_stark::proof::BatchCommitments {
            main: commitment.clone(),
            quotient_chunks: commitment,
            permutation: None,
            random: None,
        },
        p3_batch_stark::proof::BatchOpenedValues {
            instances: vec![OpenedValuesWithLookups {
                base_opened_values: p3_uni_stark::OpenedValues {
                    trace_local: vec![Challenge::ONE; 2],
                    trace_next: Some(vec![Challenge::ONE; 2]),
                    preprocessed: None,
                    quotient_chunks: vec![vec![Challenge::ONE; 4]],
                    random: None,
                },
                permutation_local: vec![],
                permutation_next: vec![],
            }],
        },
    )
}

#[test]
fn opening_helper_rejects_mismatched_instance_counts() {
    let config = make_config(0);
    let air = FibonacciAir {
        log_height: 3,
        tamper_index: None,
    };
    for collection in 0..6 {
        let (commitments, mut opened) = opening_helper_inputs();
        let airs = if collection == 0 { vec![] } else { vec![air] };
        if collection == 1 {
            opened.instances.clear();
        }
        let degrees = if collection == 2 { vec![] } else { vec![3] };
        let widths = if collection == 3 { vec![] } else { vec![0] };
        let chunks = if collection == 4 { vec![] } else { vec![0] };
        let common = p3_batch_stark::CommonData::empty(if collection == 5 { 0 } else { 1 });
        let result = commitments_with_opening_points(
            &config,
            &airs,
            Challenge::from(Val::from_u64(11)),
            &commitments,
            &opened,
            &common,
            &degrees,
            &widths,
            &chunks,
        );
        assert!(
            matches!(
                result,
                Err(BatchVerificationError::Verification(
                    VerificationError::InvalidProofShape(
                        InvalidProofShapeError::InstanceCountMismatch
                    )
                ))
            ),
            "collection {collection}: {result:?}"
        );
    }
}

#[test]
fn opening_helper_rejects_missing_or_short_next_rows() {
    let config = make_config(0);
    let air = FibonacciAir {
        log_height: 3,
        tamper_index: None,
    };
    for next in [None, Some(vec![Challenge::ONE])] {
        let (commitments, mut opened) = opening_helper_inputs();
        opened.instances[0].base_opened_values.trace_next = next;
        let result = commitments_with_opening_points(
            &config,
            &[air],
            Challenge::from(Val::from_u64(11)),
            &commitments,
            &opened,
            &p3_batch_stark::CommonData::empty(1),
            &[3],
            &[0],
            &[0],
        );
        assert!(matches!(
            result,
            Err(BatchVerificationError::Verification(
                VerificationError::InvalidProofShape(InvalidProofShapeError::TraceNextMismatch {
                    air: Some(0)
                })
            ))
        ));
    }
}

#[test]
fn opening_helper_rejects_random_openings_without_zk() {
    let config = make_config(0);
    let air = FibonacciAir {
        log_height: 3,
        tamper_index: None,
    };
    let (mut commitments, mut opened) = opening_helper_inputs();
    commitments.random = Some(commitments.main.clone());
    for random in [None, Some(vec![Challenge::ONE; 4])] {
        opened.instances[0].base_opened_values.random = random;
        let result = commitments_with_opening_points(
            &config,
            &[air],
            Challenge::from(Val::from_u64(11)),
            &commitments,
            &opened,
            &p3_batch_stark::CommonData::empty(1),
            &[3],
            &[0],
            &[0],
        );
        assert!(matches!(
            result,
            Err(BatchVerificationError::Verification(
                VerificationError::RandomizationError
            ))
        ));
    }
}

#[test]
fn opening_helper_accepts_well_shaped_inputs() {
    let config = make_config(0);
    let air = FibonacciAir {
        log_height: 3,
        tamper_index: None,
    };
    let (commitments, opened) = opening_helper_inputs();
    let (claims, domains, preprocessed_index) = commitments_with_opening_points(
        &config,
        &[air],
        Challenge::from(Val::from_u64(11)),
        &commitments,
        &opened,
        &p3_batch_stark::CommonData::empty(1),
        &[3],
        &[0],
        &[0],
    )
    .unwrap();
    assert_eq!(claims.len(), 2);
    assert_eq!(domains.len(), 1);
    assert_eq!(domains[0].len(), 1);
    assert_eq!(preprocessed_index, None);
}

#[test]
fn opening_helper_rejects_missing_zk_random_openings() {
    let config = make_config_zk(0);
    let air = FibonacciAir {
        log_height: 3,
        tamper_index: None,
    };
    let (mut commitments, mut opened) = opening_helper_inputs();
    commitments.random = Some(commitments.main.clone());
    for random in [None, Some(vec![Challenge::ONE])] {
        opened.instances[0].base_opened_values.random = random;
        let result = commitments_with_opening_points(
            &config,
            &[air],
            Challenge::from(Val::from_u64(11)),
            &commitments,
            &opened,
            &p3_batch_stark::CommonData::empty(1),
            &[4],
            &[0],
            &[0],
        );
        assert!(matches!(
            result,
            Err(BatchVerificationError::Verification(
                VerificationError::RandomizationError
            ))
        ));
    }
}

#[test]
fn opening_helper_rejects_invalid_preprocessed_metadata() {
    use p3_batch_stark::common::{GlobalPreprocessed, PreprocessedInstanceMeta};
    let config = make_config(0);
    let air = FibonacciAir {
        log_height: 3,
        tamper_index: None,
    };
    for case in 0..5 {
        let (commitments, mut opened) = opening_helper_inputs();
        opened.instances[0].base_opened_values.preprocessed =
            Some(p3_uni_stark::PreprocessedOpenedValues {
                local: vec![Challenge::ONE],
                next: Some(vec![Challenge::ONE]),
            });
        let common = p3_batch_stark::CommonData::new(
            Some(GlobalPreprocessed {
                commitment: commitments.main.clone(),
                instances: if case == 0 {
                    vec![]
                } else {
                    vec![Some(PreprocessedInstanceMeta {
                        matrix_index: 0,
                        width: 1,
                        degree_bits: 3,
                    })]
                },
                matrix_to_instance: match case {
                    1 => vec![1],
                    2 => vec![],
                    _ => vec![0],
                },
            }),
            vec![Default::default()],
        );
        let width = if case == 3 { 2 } else { 1 };
        let degree = if case == 4 { 4 } else { 3 };
        let result = commitments_with_opening_points(
            &config,
            &[air],
            Challenge::from(Val::from_u64(11)),
            &commitments,
            &opened,
            &common,
            &[degree],
            &[width],
            &[0],
        );
        assert!(
            matches!(
                result,
                Err(BatchVerificationError::Verification(
                    VerificationError::InvalidProofShape(
                        InvalidProofShapeError::InstanceCountMismatch
                            | InvalidProofShapeError::PreprocessedMetadataMismatch { .. }
                    )
                ))
            ),
            "case {case}: {result:?}"
        );
    }
}

#[test]
fn opening_helper_rejects_missing_or_short_preprocessed_next_rows() {
    use p3_batch_stark::common::{GlobalPreprocessed, PreprocessedInstanceMeta};
    let config = make_config(0);
    let air = FibonacciAir {
        log_height: 3,
        tamper_index: None,
    };
    for next in [None, Some(vec![])] {
        let (commitments, mut opened) = opening_helper_inputs();
        opened.instances[0].base_opened_values.preprocessed =
            Some(p3_uni_stark::PreprocessedOpenedValues {
                local: vec![Challenge::ONE],
                next,
            });
        let common = p3_batch_stark::CommonData::new(
            Some(GlobalPreprocessed {
                commitment: commitments.main.clone(),
                instances: vec![Some(PreprocessedInstanceMeta {
                    matrix_index: 0,
                    width: 1,
                    degree_bits: 3,
                })],
                matrix_to_instance: vec![0],
            }),
            vec![Default::default()],
        );
        let result = commitments_with_opening_points(
            &config,
            &[air],
            Challenge::from(Val::from_u64(11)),
            &commitments,
            &opened,
            &common,
            &[3],
            &[1],
            &[0],
        );
        assert!(matches!(
            result,
            Err(BatchVerificationError::Verification(
                VerificationError::InvalidProofShape(
                    InvalidProofShapeError::PreprocessedWidthMismatch { air: 0 }
                )
            ))
        ));
    }
}

#[test]
fn opening_helper_and_verify_batch_agree_on_missing_preprocessed_opening() {
    let config = make_config(2447);
    let (air, trace, public_values) = create_fib_instance(3);
    let instances = [StarkInstance {
        air: &air,
        trace: &trace,
        public_values: public_values.clone(),
    }];
    let data = ProverData::from_instances(&config, &instances).unwrap();
    let mut proof = prove_batch(&config, &instances, &data).unwrap();
    verify_batch(
        &config,
        from_ref(&air),
        &proof,
        from_ref(&public_values),
        &data.common,
    )
    .expect("untampered proof verifies");
    proof.opened_values.instances[0]
        .base_opened_values
        .preprocessed = None;

    let batch_result = verify_batch(
        &config,
        from_ref(&air),
        &proof,
        from_ref(&public_values),
        &data.common,
    );
    let log_num_chunks = proof.opened_values.instances[0]
        .base_opened_values
        .quotient_chunks
        .len()
        .ilog2() as usize;
    let helper_result = commitments_with_opening_points(
        &config,
        from_ref(&air),
        Challenge::from(Val::from_u64(11)),
        &proof.commitments,
        &proof.opened_values,
        &data.common,
        &proof.degree_bits,
        &[1],
        &[log_num_chunks],
    );
    for result in [batch_result, helper_result.map(|_| ())] {
        assert!(
            matches!(
                result,
                Err(BatchVerificationError::Verification(
                    VerificationError::InvalidProofShape(
                        InvalidProofShapeError::PreprocessedWidthMismatch { air: 0 }
                    )
                ))
            ),
            "{result:?}"
        );
    }
}

#[test]
fn batch_preflight_preserves_shape_error_order() {
    let config = make_config(2447);
    let (air, trace, public_values) = create_fib_instance(3);
    let instances = [StarkInstance {
        air: &air,
        trace: &trace,
        public_values: public_values.clone(),
    }];
    let data = ProverData::from_instances(&config, &instances).unwrap();
    let proof = prove_batch(&config, &instances, &data).unwrap();
    verify_batch(
        &config,
        from_ref(&air),
        &proof,
        from_ref(&public_values),
        &data.common,
    )
    .expect("untampered proof verifies");
    let encoded = postcard::to_allocvec(&proof).unwrap();

    for case in 0..5 {
        let mut proof: BatchProof<MyConfig> = postcard::from_bytes(&encoded).unwrap();
        let mut public_values = public_values.clone();
        let opened = &mut proof.opened_values.instances[0].base_opened_values;
        match case {
            0 => {
                public_values.pop();
                opened.trace_next = None;
            }
            1 => {
                opened.trace_local.pop();
                opened.trace_next = None;
            }
            2 => {
                opened.trace_next = None;
                opened.quotient_chunks.clear();
            }
            3 => {
                opened.quotient_chunks[0].pop();
                opened.preprocessed = None;
            }
            _ => {
                opened.preprocessed = None;
                proof.opened_values.instances[0]
                    .permutation_local
                    .push(Challenge::ONE);
            }
        };
        let result = verify_batch(
            &config,
            from_ref(&air),
            &proof,
            from_ref(&public_values),
            &data.common,
        );
        let Err(BatchVerificationError::Verification(VerificationError::InvalidProofShape(error))) =
            result
        else {
            panic!("case {case}: {result:?}")
        };
        assert!(
            matches!(
                (case, &error),
                (
                    0,
                    InvalidProofShapeError::PublicValuesLengthMismatch {
                        expected: 3,
                        got: 2
                    }
                ) | (
                    1,
                    InvalidProofShapeError::TraceLocalWidthMismatch {
                        air: 0,
                        expected: 2,
                        got: 1
                    }
                ) | (
                    2,
                    InvalidProofShapeError::TraceNextMismatch { air: Some(0) }
                ) | (
                    3,
                    InvalidProofShapeError::QuotientChunkDimensionMismatch { air: 0 }
                ) | (
                    4,
                    InvalidProofShapeError::PreprocessedWidthMismatch { air: 0 }
                )
            ),
            "case {case}: {error:?}"
        );
    }
}

/// One column pinned to a periodic column, looked up against it under a periodic count.
#[derive(Clone)]
struct PeriodicLookupAir;

impl<F: Field> BaseAir<F> for PeriodicLookupAir {
    fn width(&self) -> usize {
        1
    }

    fn num_periodic_columns(&self) -> usize {
        2
    }

    fn periodic_columns(&self) -> Cow<'_, [Vec<F>]> {
        // Column 0: the values. Column 1: the count, active on even rows.
        Cow::Owned(vec![
            vec![
                F::from_u64(3),
                F::from_u64(5),
                F::from_u64(7),
                F::from_u64(9),
            ],
            vec![F::ONE, F::ZERO],
        ])
    }
}

impl<AB> Air<AB> for PeriodicLookupAir
where
    AB: AirBuilder + PermutationAirBuilder + InteractionBuilder,
{
    fn eval(&self, builder: &mut AB) {
        let value: AB::Expr = builder.main().current_slice()[0].into();
        let expected: AB::Expr = builder.periodic_values()[0].into();
        let count: AB::Expr = builder.periodic_values()[1].into();
        builder.assert_eq(value.clone(), expected.clone());
        builder.push_local_interaction(vec![
            (vec![value], Count::bounded(count.clone(), 1)),
            (vec![expected], Count::provided(-count)),
        ]);
    }
}

#[test]
fn a_lookup_may_read_periodic_columns() {
    // Invariant: lookup tuples and counts see the same periodic values as the constraints.
    //
    // Fixture state: 64 rows, values [3, 5, 7, 9] repeating, count [1, 0] repeating.
    let config = make_config(42);
    let air = PeriodicLookupAir;
    let values: Vec<Val> = (0..64)
        .map(|i| Val::from_u64([3, 5, 7, 9][i % 4]))
        .collect();
    let trace = RowMajorMatrix::new(values, 1);
    let instances = vec![StarkInstance {
        air: &air,
        trace: &trace,
        public_values: vec![],
    }];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let common = &prover_data.common;
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    verify_batch(&config, &[air], &proof, &[vec![]], common).expect("the proof verifies");
}

#[test]
fn empty_batch_is_rejected_by_prover() {
    // Fixture state: zero instances, and common data sized for zero instances.
    let config = make_config(0);
    let instances: [StarkInstance<'_, MyConfig, DemoAir>; 0] = [];
    let prover_data = ProverData::empty(0);

    // Invariant: an empty batch is a typed error, not a panic inside the commitment scheme.
    //
    //     instances = []  ->  Err(EmptyBatch), before any commitment
    let result = prove_batch(&config, &instances, &prover_data);
    assert!(matches!(result, Err(ProvingError::EmptyBatch)));
}

/// A counter: the first row is zero and each row adds one to the previous.
///
/// The transition reads column 1 of the next row.
/// Column 0 is a copy of column 1, so the declaration can omit exactly one read column.
#[derive(Clone, Debug)]
struct CounterAir {
    /// The main columns the AIR declares it reads on the next row.
    declared_next: Vec<usize>,
}

impl<F> BaseAir<F> for CounterAir {
    fn width(&self) -> usize {
        2
    }

    fn main_next_row_columns(&self) -> Vec<usize> {
        self.declared_next.clone()
    }
}

impl<AB: AirBuilder> Air<AB> for CounterAir {
    fn eval(&self, builder: &mut AB) {
        let main = builder.main();
        let copy = main.current(0).unwrap();
        let local = main.current(1).unwrap();
        let next = main.next(1).unwrap();
        builder.assert_eq(copy, local);
        builder.when_first_row().assert_zero(local);
        builder
            .when_transition()
            .assert_eq(next, local + AB::Expr::ONE);
    }
}

/// Eight rows counting from zero, each value written to both columns.
fn counter_trace() -> RowMajorMatrix<Val> {
    let values = (0..8u64).flat_map(|i| [Val::from_u64(i); 2]).collect();
    RowMajorMatrix::new(values, 2)
}

#[test]
fn prover_rejects_an_undeclared_next_row_read() {
    let config = make_config(0);
    let trace = counter_trace();

    // Fixture state: two counters, both satisfied on their real rows.
    //
    // Mutation: instance 1 declares no next-row column, yet its transition reads column 1.
    //
    //     instance 0: declared {1}, read {1}
    //     instance 1: declared {},  read {1}   <- undeclared
    let honest = CounterAir {
        declared_next: vec![1],
    };
    let misdeclared = CounterAir {
        declared_next: vec![],
    };
    let instances = [
        StarkInstance {
            air: &honest,
            trace: &trace,
            public_values: vec![],
        },
        StarkInstance {
            air: &misdeclared,
            trace: &trace,
            public_values: vec![],
        },
    ];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();

    // Invariant: the prover names the instance and the read before committing to anything.
    let result = prove_batch(&config, &instances, &prover_data);
    assert!(matches!(
        result,
        Err(ProvingError::UndeclaredNextRowRead {
            air: Some(1),
            trace: NextRowTrace::Main,
            column: 1,
        })
    ));
}

#[test]
fn verifier_rejects_an_undeclared_next_row_read() {
    let config = make_config(0);
    let trace = counter_trace();

    // Fixture state: an honest batch of two counters, each declaring its next-row read.
    let honest = CounterAir {
        declared_next: vec![1],
    };
    let instances = [
        StarkInstance {
            air: &honest,
            trace: &trace,
            public_values: vec![],
        },
        StarkInstance {
            air: &honest,
            trace: &trace,
            public_values: vec![],
        },
    ];
    let prover_data = ProverData::from_instances(&config, &instances).unwrap();
    let proof = prove_batch(&config, &instances, &prover_data).unwrap();
    let public_values = [vec![], vec![]];
    let airs = [honest.clone(), honest.clone()];
    assert!(matches!(
        verify_batch(&config, &airs, &proof, &public_values, &prover_data.common),
        Ok(())
    ));

    // Mutation: the verifier's second AIR declares only column 0, which no transition reads.
    //
    //     declared next row:  {0}
    //     read next row:      {1}   <- undeclared
    let misdeclared = CounterAir {
        declared_next: vec![0],
    };
    let airs = [honest, misdeclared];

    // Invariant: the verifier names the instance and the read.
    let result = verify_batch(&config, &airs, &proof, &public_values, &prover_data.common);
    assert!(matches!(
        result,
        Err(BatchVerificationError::Verification(
            VerificationError::UndeclaredNextRowRead {
                air: Some(1),
                trace: NextRowTrace::Main,
                column: 1,
            }
        ))
    ));
}
