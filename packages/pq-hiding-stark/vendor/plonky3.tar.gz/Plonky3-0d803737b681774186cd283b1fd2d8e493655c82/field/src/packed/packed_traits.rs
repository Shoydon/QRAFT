use alloc::vec::Vec;
use core::iter::{Product, Sum};
use core::mem::MaybeUninit;
use core::ops::{Div, DivAssign};
use core::{array, slice};

use crate::field::Field;
use crate::{Algebra, BasedVectorSpace, ExtensionField, Powers, PrimeCharacteristicRing};

/// A trait to constrain types that can be packed into a packed value.
///
/// The `Packable` trait allows us to specify implementations for potentially conflicting types.
pub trait Packable: 'static + Default + Copy + Send + Sync + PartialEq + Eq {
    /// Transpose a row-major matrix.
    /// Audited integer representations can override this to use register kernels; other types keep typed copies.
    #[inline]
    fn transpose(input: &[Self], output: &mut [Self], width: usize, height: usize) {
        p3_util::transpose::transpose(input, output, width, height);
    }

    /// Transpose into an owned vector of exactly input.len() elements.
    ///
    /// This independent hook defaults to typed copies. Overriding transpose
    /// does not change it; audited representations can override both hooks.
    /// Panics if dimensions overflow or input has the wrong length.
    #[inline]
    #[must_use]
    fn transpose_owned(input: &[Self], width: usize, height: usize) -> Vec<Self> {
        p3_util::transpose::transpose_owned(input, width, height)
    }

    /// Transpose separately stored rows into contiguous columns.
    #[inline]
    fn transpose_rows<'a>(
        rows: usize,
        cols: usize,
        row: impl Fn(usize) -> &'a [Self],
        dst: &mut [Self],
    ) {
        p3_util::transpose::transpose_rows(rows, cols, row, dst);
    }
}

/// A trait for array-like structs made up of multiple scalar elements.
///
/// # Safety
/// - If `P` implements `PackedField` then `P` must be castable to/from `[P::Value; P::WIDTH]`
///   without UB.
pub unsafe trait PackedValue: 'static + Copy + Send + Sync {
    /// The scalar type that is packed into this value.
    type Value: Packable;

    /// Number of scalar values packed together.
    const WIDTH: usize;

    /// Constructs a packed value using a function to generate each element.
    ///
    /// Similar to [`core::array::from_fn`].
    #[must_use]
    fn from_fn<F>(f: F) -> Self
    where
        F: FnMut(usize) -> Self::Value;

    /// Create a packed value with all lanes set to the same scalar value.
    #[inline]
    #[must_use]
    fn broadcast(value: Self::Value) -> Self {
        Self::from_fn(|_| value)
    }

    /// Interprets a slice of scalar values as a packed value reference.
    ///
    /// # Panics:
    /// This function will panic if `slice.len() != Self::WIDTH`
    #[must_use]
    fn from_slice(slice: &[Self::Value]) -> &Self;

    /// Interprets a mutable slice of scalar values as a mutable packed value.
    ///
    /// # Panics:
    /// This function will panic if `slice.len() != Self::WIDTH`
    #[must_use]
    fn from_slice_mut(slice: &mut [Self::Value]) -> &mut Self;

    /// Returns the underlying scalar values as an immutable slice.
    #[must_use]
    fn as_slice(&self) -> &[Self::Value];

    /// Returns the underlying scalar values as a mutable slice.
    #[must_use]
    fn as_slice_mut(&mut self) -> &mut [Self::Value];

    /// Extract the scalar value at the given SIMD lane.
    ///
    /// This is equivalent to `self.as_slice()[lane]` but more explicit about the
    /// SIMD extraction semantics.
    #[inline]
    #[must_use]
    fn extract(&self, lane: usize) -> Self::Value {
        self.as_slice()[lane]
    }

    /// Packs a slice of scalar values into a slice of packed values.
    ///
    /// # Panics
    /// Panics if the slice length is not divisible by `WIDTH`.
    #[inline]
    #[must_use]
    fn pack_slice(buf: &[Self::Value]) -> &[Self] {
        // Sources vary, but this should be true on all platforms we care about.
        const {
            assert!(align_of::<Self>() <= align_of::<Self::Value>());
        }
        assert!(
            buf.len().is_multiple_of(Self::WIDTH),
            "Slice length (got {}) must be a multiple of packed field width ({}).",
            buf.len(),
            Self::WIDTH
        );
        let buf_ptr = buf.as_ptr().cast::<Self>();
        let n = buf.len() / Self::WIDTH;
        // SAFETY: `buf_ptr` is valid for `n * WIDTH` values of `Self::Value`, which is
        // the same region as `n` values of `Self` given the alignment and length checks above.
        unsafe { slice::from_raw_parts(buf_ptr, n) }
    }

    /// Converts a mutable slice of scalar values into a mutable slice of packed values.
    ///
    /// # Panics
    /// Panics if the slice length is not divisible by `WIDTH`.
    #[inline]
    #[must_use]
    fn pack_slice_mut(buf: &mut [Self::Value]) -> &mut [Self] {
        const {
            assert!(align_of::<Self>() <= align_of::<Self::Value>());
        }
        assert!(
            buf.len().is_multiple_of(Self::WIDTH),
            "Slice length (got {}) must be a multiple of packed field width ({}).",
            buf.len(),
            Self::WIDTH
        );
        let buf_ptr = buf.as_mut_ptr().cast::<Self>();
        let n = buf.len() / Self::WIDTH;
        // SAFETY: `buf_ptr` is valid for `n * WIDTH` values of `Self::Value`, which is
        // the same region as `n` values of `Self` given the alignment and length checks above.
        unsafe { slice::from_raw_parts_mut(buf_ptr, n) }
    }

    /// Converts a mutable slice of possibly uninitialized scalar values into
    /// a mutable slice of possibly uninitialized packed values.
    ///
    /// # Panics
    /// Panics if the slice length is not divisible by `WIDTH`.
    #[inline]
    #[must_use]
    fn pack_maybe_uninit_slice_mut(
        buf: &mut [MaybeUninit<Self::Value>],
    ) -> &mut [MaybeUninit<Self>] {
        const {
            assert!(align_of::<Self>() <= align_of::<Self::Value>());
        }
        assert!(
            buf.len().is_multiple_of(Self::WIDTH),
            "Slice length (got {}) must be a multiple of packed field width ({}).",
            buf.len(),
            Self::WIDTH
        );
        let buf_ptr = buf.as_mut_ptr().cast::<MaybeUninit<Self>>();
        let n = buf.len() / Self::WIDTH;
        // SAFETY: `buf_ptr` is valid for `n * WIDTH` values of `MaybeUninit<Self::Value>`,
        // which is the same region as `n` values of `MaybeUninit<Self>` given the
        // alignment and length checks above.
        unsafe { slice::from_raw_parts_mut(buf_ptr, n) }
    }

    /// Packs a slice into packed values and returns the packed portion and any remaining suffix.
    #[inline]
    #[must_use]
    fn pack_slice_with_suffix(buf: &[Self::Value]) -> (&[Self], &[Self::Value]) {
        let (packed, suffix) = buf.split_at(buf.len() - buf.len() % Self::WIDTH);
        (Self::pack_slice(packed), suffix)
    }

    /// Converts a mutable slice of scalar values into a pair:
    /// - a slice of packed values covering the largest aligned portion,
    /// - and a remainder slice of scalar values that couldn't be packed.
    #[inline]
    #[must_use]
    fn pack_slice_with_suffix_mut(buf: &mut [Self::Value]) -> (&mut [Self], &mut [Self::Value]) {
        let (packed, suffix) = buf.split_at_mut(buf.len() - buf.len() % Self::WIDTH);
        (Self::pack_slice_mut(packed), suffix)
    }

    /// Converts a mutable slice of possibly uninitialized scalar values into a pair:
    /// - a slice of possibly uninitialized packed values covering the largest aligned portion,
    /// - and a remainder slice of possibly uninitialized scalar values that couldn't be packed.
    #[inline]
    #[must_use]
    fn pack_maybe_uninit_slice_with_suffix_mut(
        buf: &mut [MaybeUninit<Self::Value>],
    ) -> (&mut [MaybeUninit<Self>], &mut [MaybeUninit<Self::Value>]) {
        let (packed, suffix) = buf.split_at_mut(buf.len() - buf.len() % Self::WIDTH);
        (Self::pack_maybe_uninit_slice_mut(packed), suffix)
    }

    /// Reinterprets a slice of packed values as a flat slice of scalar values.
    ///
    /// Each packed value contains `Self::WIDTH` scalar values, which are laid out
    /// contiguously in memory. This function allows direct access to those scalars.
    #[inline]
    #[must_use]
    fn unpack_slice(buf: &[Self]) -> &[Self::Value] {
        const {
            assert!(align_of::<Self>() >= align_of::<Self::Value>());
        }
        let buf_ptr = buf.as_ptr().cast::<Self::Value>();
        let n = buf.len() * Self::WIDTH;
        unsafe { slice::from_raw_parts(buf_ptr, n) }
    }

    /// Pack columns from `WIDTH` rows of scalar values into `N` packed values.
    ///
    /// Given `WIDTH` rows of `N` scalar values, extract each column and pack it
    /// into a single packed value. This is the inverse of `unpack_into`.
    ///
    /// ## Panics
    /// Panics if `rows.len() != WIDTH`.
    #[inline]
    #[must_use]
    fn pack_columns<const N: usize>(rows: &[[Self::Value; N]]) -> [Self; N] {
        assert_eq!(rows.len(), Self::WIDTH);
        array::from_fn(|col| Self::from_fn(|lane| rows[lane][col]))
    }

    /// Pack columns using a closure that provides each row's data.
    ///
    /// Calls `row_fn(lane)` for each lane `0..WIDTH` to get `[Self::Value; N]`,
    /// then transposes columns into packed values. Useful when rows aren't
    /// contiguous in memory (e.g., strided access).
    #[inline]
    #[must_use]
    fn pack_columns_fn<const N: usize>(row_fn: impl Fn(usize) -> [Self::Value; N]) -> [Self; N] {
        array::from_fn(|col| Self::from_fn(|lane| row_fn(lane)[col]))
    }

    /// Unpack `N` packed values into `WIDTH` rows of `N` scalars.
    ///
    /// ## Inputs
    /// - `packed`: An array of `N` packed values.
    /// - `rows`: A mutable slice of exactly `WIDTH` arrays to write the unpacked values.
    ///
    /// ## Panics
    /// Panics if `rows.len() != WIDTH`.
    #[inline]
    fn unpack_into<const N: usize>(packed: &[Self; N], rows: &mut [[Self::Value; N]]) {
        assert_eq!(rows.len(), Self::WIDTH);
        for (lane, row) in rows.iter_mut().enumerate() {
            *row = array::from_fn(|col| packed[col].extract(lane));
        }
    }

    /// Unpack `N` packed values into an iterator of `WIDTH` rows.
    ///
    /// This is the iterator equivalent of `unpack_into`, yielding each row
    /// without requiring a pre-allocated buffer.
    #[inline]
    fn unpack_iter<const N: usize>(packed: [Self; N]) -> impl Iterator<Item = [Self::Value; N]> {
        (0..Self::WIDTH).map(move |lane| array::from_fn(|col| packed[col].extract(lane)))
    }
}

unsafe impl<T: Packable, const WIDTH: usize> PackedValue for [T; WIDTH] {
    type Value = T;
    const WIDTH: usize = WIDTH;

    #[inline]
    fn from_slice(slice: &[Self::Value]) -> &Self {
        assert_eq!(slice.len(), Self::WIDTH);
        unsafe { &*slice.as_ptr().cast() }
    }

    #[inline]
    fn from_slice_mut(slice: &mut [Self::Value]) -> &mut Self {
        assert_eq!(slice.len(), Self::WIDTH);
        unsafe { &mut *slice.as_mut_ptr().cast() }
    }

    #[inline]
    fn from_fn<Fn>(f: Fn) -> Self
    where
        Fn: FnMut(usize) -> Self::Value,
    {
        core::array::from_fn(f)
    }

    #[inline]
    fn as_slice(&self) -> &[Self::Value] {
        self
    }

    #[inline]
    fn as_slice_mut(&mut self) -> &mut [Self::Value] {
        self
    }
}

/// An array of field elements which can be packed into a vector for SIMD operations.
///
/// # Safety
/// - See `PackedValue` above.
pub unsafe trait PackedField:
    Algebra<Self::Scalar>
    + PackedValue<Value = Self::Scalar>
    + Div<Self, Output = Self>
    + Div<Self::Scalar, Output = Self>
    + DivAssign<Self>
    + DivAssign<Self::Scalar>
    + Sum<Self::Scalar>
    + Product<Self::Scalar>
{
    type Scalar: Field;

    /// Terms a blocked dot product over this packing should group per call to `dot_product`.
    ///
    /// A caller splitting a long dot product into fixed blocks sizes them by this.
    ///
    /// A packing sets it to the longest power of two its `dot_product` sums with one reduction.
    ///
    /// Must be one of 1, 2, 4, 8 or 16.
    const DOT_PRODUCT_BLOCK: usize = 8;

    /// Lanes one multiplication of this packing computes at once.
    ///
    /// It equals `WIDTH` for a packing backed by a vector multiply.
    ///
    /// A packing that multiplies lane by lane sets it to 1.
    ///
    /// A caller can then skip packing values whose products gain nothing from it.
    const MUL_LANES: usize = Self::WIDTH;

    /// Construct an iterator which returns powers of `base` packed into packed field elements.
    ///
    /// E.g. if `Self::WIDTH = 4`, returns: `[base^0, base^1, base^2, base^3], [base^4, base^5, base^6, base^7], ...`.
    #[must_use]
    fn packed_powers(base: Self::Scalar) -> Powers<Self> {
        Self::packed_shifted_powers(base, Self::Scalar::ONE)
    }

    /// Construct an iterator which returns powers of `base` multiplied by `start` and packed into packed field elements.
    ///
    /// E.g. if `Self::WIDTH = 4`, returns: `[start, start*base, start*base^2, start*base^3], [start*base^4, start*base^5, start*base^6, start*base^7], ...`.
    #[must_use]
    fn packed_shifted_powers(base: Self::Scalar, start: Self::Scalar) -> Powers<Self> {
        let mut current: Self = start.into();
        let slice = current.as_slice_mut();
        for i in 1..Self::WIDTH {
            slice[i] = slice[i - 1] * base;
        }

        Powers {
            base: base.exp_u64(Self::WIDTH as u64).into(),
            current,
        }
    }

    /// Accumulate the products of `d` coefficient streams against a shared stream of
    /// packed base values.
    ///
    /// For each `(coeffs, base)` pair produced by the iterator, performs
    /// `acc[k] += coeffs[k] * base` for all `k < d`, and returns the accumulators
    /// (entries at `d..` are zero). Coefficient slices shorter than `d` only
    /// contribute their available entries.
    ///
    /// This is the inner kernel of mixed base-times-extension dot products, where each
    /// extension element contributes `d` base-field coefficient words. Implementations
    /// may override it to defer modular reductions across iterations.
    ///
    /// # Panics
    /// Debug builds panic if `d > 8`.
    #[must_use]
    fn coeffwise_dot_product<'a, I>(d: usize, pairs: I) -> [Self; 8]
    where
        Self: 'a,
        I: Iterator<Item = (&'a [Self], Self)>,
    {
        debug_assert!(d <= 8, "Extension degree > 8 not supported");
        let mut acc = [Self::ZERO; 8];
        for (coeffs, base) in pairs {
            for (acc_k, &coeff) in acc[..d].iter_mut().zip(coeffs) {
                *acc_k += coeff * base;
            }
        }
        acc
    }
}

/// # Safety
/// - `WIDTH` is assumed to be a power of 2.
pub unsafe trait PackedFieldPow2: PackedField {
    /// Take interpret two vectors as chunks of `block_len` elements. Unpack and interleave those
    /// chunks. This is best seen with an example. If we have:
    /// ```text
    /// A = [x0, y0, x1, y1]
    /// B = [x2, y2, x3, y3]
    /// ```
    ///
    /// then
    ///
    /// ```text
    /// interleave(A, B, 1) = ([x0, x2, x1, x3], [y0, y2, y1, y3])
    /// ```
    ///
    /// Pairs that were adjacent in the input are at corresponding positions in the output.
    ///
    /// `r` lets us set the size of chunks we're interleaving. If we set `block_len = 2`, then for
    ///
    /// ```text
    /// A = [x0, x1, y0, y1]
    /// B = [x2, x3, y2, y3]
    /// ```
    ///
    /// we obtain
    ///
    /// ```text
    /// interleave(A, B, block_len) = ([x0, x1, x2, x3], [y0, y1, y2, y3])
    /// ```
    ///
    /// We can also think about this as stacking the vectors, dividing them into 2x2 matrices, and
    /// transposing those matrices.
    ///
    /// When `block_len = WIDTH`, this operation is a no-op.
    ///
    /// # Panics
    /// This may panic if `block_len` does not divide `WIDTH`. Since `WIDTH` is specified to be a power of 2,
    /// `block_len` must also be a power of 2. It cannot be 0 and it cannot exceed `WIDTH`.
    #[must_use]
    fn interleave(&self, other: Self, block_len: usize) -> (Self, Self);
}

/// Fix a field `F` a packing width `W` and an extension field `EF` of `F`.
///
/// By choosing a basis `B`, `EF` can be transformed into an array `[F; D]`.
///
/// A type should implement PackedFieldExtension if it can be transformed into `[F::Packing; D] ~ [[F; W]; D]`
///
/// This is interpreted by taking a transpose to get `[[F; D]; W]` which can then be reinterpreted
/// as `[EF; W]` by making use of the chosen basis `B` again.
pub trait PackedFieldExtension<
    BaseField: Field,
    ExtField: ExtensionField<BaseField, ExtensionPacking = Self>,
>: Algebra<ExtField> + Algebra<BaseField::Packing> + BasedVectorSpace<BaseField::Packing>
{
    /// Construct a packed extension by applying `f` to each lane.
    ///
    /// This is the extension-field analog of [`PackedValue::from_fn`] and the canonical
    /// primitive constructor for packed extensions: every other constructor in this
    /// trait (`from_ext_slice`, `pack_ext_columns`, etc.) routes through it.
    ///
    /// `f` is called once per `(basis_coefficient, lane)` pair (`D * W` calls total),
    /// hence the [`Fn`] bound — closures with side effects are unsuitable.
    ///
    /// The default impl uses only the [`BasedVectorSpace`] machinery the trait already
    /// requires. Concrete impls should override when the extension struct exposes its
    /// base packings directly, e.g. `Self::new(F::Packing::pack_columns_fn(|l| f(l).value))`.
    #[inline]
    #[must_use]
    fn from_ext_fn(f: impl Fn(usize) -> ExtField) -> Self {
        Self::from_basis_coefficients_fn(|d| {
            BaseField::Packing::from_fn(|lane| f(lane).as_basis_coefficients_slice()[d])
        })
    }

    /// Pack a length-`WIDTH` slice of extension field elements into one packed extension.
    ///
    /// ## Panics
    /// Panics if `slice.len() != BaseField::Packing::WIDTH`.
    #[inline]
    #[must_use]
    fn from_ext_slice(slice: &[ExtField]) -> Self {
        assert_eq!(slice.len(), BaseField::Packing::WIDTH);
        Self::from_ext_fn(|lane| slice[lane])
    }

    /// Pack `N` columns from `W` rows of extension field elements into `N` packed extensions.
    ///
    /// This is the extension-field analog of [`PackedValue::pack_columns`]: given `W` rows
    /// of `N` extension elements, lane `lane` of output column `col` is `rows[lane][col]`.
    ///
    /// ## Panics
    /// Panics if `rows.len() != BaseField::Packing::WIDTH`.
    #[inline]
    #[must_use]
    fn pack_ext_columns<const N: usize>(rows: &[[ExtField; N]]) -> [Self; N] {
        assert_eq!(rows.len(), BaseField::Packing::WIDTH);
        array::from_fn(|col| Self::from_ext_fn(|lane| rows[lane][col]))
    }

    /// Pack `N` columns using a closure that produces each row.
    ///
    /// Analog of [`PackedValue::pack_columns_fn`].
    #[inline]
    #[must_use]
    fn pack_ext_columns_fn<const N: usize>(row_fn: impl Fn(usize) -> [ExtField; N]) -> [Self; N] {
        array::from_fn(|col| Self::from_ext_fn(|lane| row_fn(lane)[col]))
    }

    /// Extract the extension field element at the given SIMD lane.
    #[inline]
    #[must_use]
    fn extract(&self, lane: usize) -> ExtField {
        ExtField::from_basis_coefficients_fn(|d| {
            self.as_basis_coefficients_slice()[d].as_slice()[lane]
        })
    }

    /// Accumulate `value` into a single SIMD lane, leaving the other `W - 1` lanes unchanged.
    ///
    /// This is the accumulating dual of the per-lane read [`PackedFieldExtension::extract`].
    /// It scatters one scalar extension element into a packed buffer, one lane at a time.
    ///
    /// The default rebuilds a full packed element and adds it.
    /// Concrete types override it to touch only the `D` base lanes at the target lane.
    #[inline]
    fn add_assign_lane(&mut self, lane: usize, value: ExtField) {
        *self += Self::from_ext_fn(|l| if l == lane { value } else { ExtField::ZERO });
    }

    /// Write all `W` lanes into the given slice.
    ///
    /// This is the extension-field analog of [`PackedValue::as_slice`], but the lanes of
    /// a packed extension are not contiguous in memory (the layout is `[[F; W]; D]`,
    /// indexed first by basis coefficient), so the lanes must be copied rather than
    /// borrowed.
    ///
    /// ## Panics
    /// Panics if `out.len() != BaseField::Packing::WIDTH`.
    #[inline]
    fn to_ext_slice(&self, out: &mut [ExtField]) {
        assert_eq!(out.len(), BaseField::Packing::WIDTH);
        for (lane, slot) in out.iter_mut().enumerate() {
            *slot = self.extract(lane);
        }
    }

    /// Unpack `N` packed extensions into `W` rows of `N` extension elements.
    ///
    /// Inverse of [`PackedFieldExtension::pack_ext_columns`]. Lane `lane` of input
    /// column `col` is written to `rows[lane][col]`.
    ///
    /// ## Panics
    /// Panics if `rows.len() != BaseField::Packing::WIDTH`.
    #[inline]
    fn unpack_ext_into<const N: usize>(packed: &[Self; N], rows: &mut [[ExtField; N]]) {
        assert_eq!(rows.len(), BaseField::Packing::WIDTH);
        for (lane, row) in rows.iter_mut().enumerate() {
            *row = array::from_fn(|col| {
                ExtField::from_basis_coefficients_fn(|d| {
                    packed[col].as_basis_coefficients_slice()[d].as_slice()[lane]
                })
            });
        }
    }

    /// Iterator equivalent of [`PackedFieldExtension::unpack_ext_into`].
    ///
    /// Yields `WIDTH` rows of `N` extension elements without requiring a pre-allocated
    /// buffer. Analog of [`PackedValue::unpack_iter`].
    #[inline]
    fn unpack_ext_iter<const N: usize>(packed: [Self; N]) -> impl Iterator<Item = [ExtField; N]> {
        (0..BaseField::Packing::WIDTH).map(move |lane| {
            array::from_fn(|col| {
                ExtField::from_basis_coefficients_fn(|d| {
                    packed[col].as_basis_coefficients_slice()[d].as_slice()[lane]
                })
            })
        })
    }

    /// Convert an iterator of packed extension field elements to an iterator of
    /// extension field elements (flat — one `ExtField` per lane per packed value).
    #[inline]
    fn to_ext_iter(iter: impl IntoIterator<Item = Self>) -> impl Iterator<Item = ExtField> {
        iter.into_iter()
            .flat_map(|x| (0..BaseField::Packing::WIDTH).map(move |lane| x.extract(lane)))
    }

    /// Unpacks a packed row-major matrix into its scalar transpose, in one pass.
    ///
    /// `src` is a row-major matrix of logical scalars, `src_width` columns wide.
    /// `WIDTH` consecutive logical scalars share one packed element:
    ///
    /// ```text
    ///     src_logical[i] = src[i / WIDTH].extract(i % WIDTH)
    /// ```
    ///
    /// The scalar transpose lands in `dst`, now `src_height` columns wide:
    ///
    /// ```text
    ///     dst[c * src_height + r] = src_logical[r * src_width + c]
    /// ```
    ///
    /// Every scalar is read once and written once: half the traffic of unpack-then-transpose.
    ///
    /// ## Panics
    /// - `dst.len()` must equal `src.len() * WIDTH`.
    /// - `src_width` must divide `dst.len()`.
    fn unpack_transpose_into(src: &[Self], dst: &mut [ExtField], src_width: usize) {
        let w = BaseField::Packing::WIDTH;
        assert!(src_width != 0);
        assert_eq!(dst.len(), src.len() * w);
        assert!(
            dst.len().is_multiple_of(src_width),
            "src_width must divide the scalar count"
        );
        let src_height = dst.len() / src_width;

        // Fast path: both dimensions split into whole `W`-blocks.
        //   src_width  % W == 0  ->  every row starts on a packed boundary
        //   src_height % W == 0  ->  every dst run is exactly `W` long, no overrun
        if w > 1 && src_width.is_multiple_of(w) && src_height.is_multiple_of(w) {
            let packed_width = src_width / w;
            // Walk `W x W` scalar blocks; reads stream `W` rows, writes are contiguous runs.
            for r0 in (0..src_height).step_by(w) {
                for cp in 0..packed_width {
                    for l in 0..w {
                        // Lane `l` of packed (row r0+j, packed-col cp) = src_logical[r0+j][cp*W + l].
                        // It lands at column `cp*W + l`, row `r0+j`.
                        let run = &mut dst[(cp * w + l) * src_height + r0..][..w];
                        for (j, slot) in run.iter_mut().enumerate() {
                            *slot = src[(r0 + j) * packed_width + cp].extract(l);
                        }
                    }
                }
            }
        } else {
            // Fallback: gather each scalar straight to its transposed slot.
            for r in 0..src_height {
                for c in 0..src_width {
                    let idx = r * src_width + c;
                    dst[c * src_height + r] = src[idx / w].extract(idx % w);
                }
            }
        }
    }

    /// Similar to `packed_powers`, construct an iterator which returns
    /// powers of `base` packed into `PackedFieldExtension` elements.
    #[must_use]
    fn packed_ext_powers(base: ExtField) -> Powers<Self>;

    /// Similar to `packed_ext_powers` but only returns `unpacked_len` powers of `base`.
    ///
    /// Note that the length of the returned iterator will be `unpacked_len / WIDTH` and
    /// not `len` as the iterator is over packed extension field elements. If `unpacked_len`
    /// is not divisible by `WIDTH`, `unpacked_len` will be rounded up to the next multiple of `WIDTH`.
    fn packed_ext_powers_capped(base: ExtField, unpacked_len: usize) -> impl Iterator<Item = Self> {
        Self::packed_ext_powers(base).take(unpacked_len.div_ceil(BaseField::Packing::WIDTH))
    }
}

unsafe impl<T: Packable> PackedValue for T {
    type Value = Self;

    const WIDTH: usize = 1;

    #[inline]
    fn from_slice(slice: &[Self::Value]) -> &Self {
        assert_eq!(slice.len(), Self::WIDTH);
        &slice[0]
    }

    #[inline]
    fn from_slice_mut(slice: &mut [Self::Value]) -> &mut Self {
        assert_eq!(slice.len(), Self::WIDTH);
        &mut slice[0]
    }

    #[inline]
    fn from_fn<Fn>(mut f: Fn) -> Self
    where
        Fn: FnMut(usize) -> Self::Value,
    {
        f(0)
    }

    #[inline]
    fn as_slice(&self) -> &[Self::Value] {
        slice::from_ref(self)
    }

    #[inline]
    fn as_slice_mut(&mut self) -> &mut [Self::Value] {
        slice::from_mut(self)
    }
}

unsafe impl<F: Field> PackedField for F {
    type Scalar = Self;
}

unsafe impl<F: Field> PackedFieldPow2 for F {
    #[inline]
    fn interleave(&self, other: Self, block_len: usize) -> (Self, Self) {
        match block_len {
            1 => (*self, other),
            _ => panic!("unsupported block length"),
        }
    }
}

impl<F: Field> PackedFieldExtension<F, F> for F::Packing {
    #[inline]
    fn from_ext_fn(f: impl Fn(usize) -> F) -> Self {
        F::Packing::from_fn(f)
    }

    #[inline]
    fn from_ext_slice(slice: &[F]) -> Self {
        *F::Packing::from_slice(slice)
    }

    #[inline]
    fn packed_ext_powers(base: F) -> Powers<Self> {
        F::Packing::packed_powers(base)
    }

    #[inline]
    fn add_assign_lane(&mut self, lane: usize, value: F) {
        // Degree-1 case: the lane is a single base element.
        self.as_slice_mut()[lane] += value;
    }
}

impl Packable for u8 {}

impl Packable for u16 {}

impl Packable for u32 {
    #[inline]
    fn transpose_owned(input: &[Self], width: usize, height: usize) -> Vec<Self> {
        // SAFETY: integers have initialized, padding-free, pointer-free representations.
        unsafe { p3_util::transpose::transpose_words_owned(input, width, height) }
    }

    #[inline]
    fn transpose(input: &[Self], output: &mut [Self], width: usize, height: usize) {
        // SAFETY: integers have initialized, padding-free, pointer-free representations.
        unsafe { p3_util::transpose::transpose_words(input, output, width, height) };
    }

    #[inline]
    fn transpose_rows<'a>(
        rows: usize,
        cols: usize,
        row: impl Fn(usize) -> &'a [Self],
        dst: &mut [Self],
    ) {
        // SAFETY: integers have initialized, padding-free, pointer-free representations.
        unsafe { p3_util::transpose::transpose_rows_words(rows, cols, row, dst) };
    }
}

impl Packable for u64 {
    #[inline]
    fn transpose_owned(input: &[Self], width: usize, height: usize) -> Vec<Self> {
        // SAFETY: integers have initialized, padding-free, pointer-free representations.
        unsafe { p3_util::transpose::transpose_words_owned(input, width, height) }
    }

    #[inline]
    fn transpose(input: &[Self], output: &mut [Self], width: usize, height: usize) {
        // SAFETY: integers have initialized, padding-free, pointer-free representations.
        unsafe { p3_util::transpose::transpose_words(input, output, width, height) };
    }

    #[inline]
    fn transpose_rows<'a>(
        rows: usize,
        cols: usize,
        row: impl Fn(usize) -> &'a [Self],
        dst: &mut [Self],
    ) {
        // SAFETY: integers have initialized, padding-free, pointer-free representations.
        unsafe { p3_util::transpose::transpose_rows_words(rows, cols, row, dst) };
    }
}

impl Packable for u128 {}
