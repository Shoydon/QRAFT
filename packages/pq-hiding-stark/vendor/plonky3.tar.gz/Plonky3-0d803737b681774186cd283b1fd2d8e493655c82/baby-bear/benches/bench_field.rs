use std::hint::black_box;

use criterion::{BatchSize, Criterion, criterion_group, criterion_main};
use p3_baby_bear::BabyBear;
use p3_field::{Field, PrimeCharacteristicRing};
use p3_field_testing::bench_func::{
    benchmark_add_latency, benchmark_add_throughput, benchmark_chunked_linear_combination,
    benchmark_inv, benchmark_iter_sum, benchmark_mul_latency, benchmark_mul_throughput,
    benchmark_sub_latency, benchmark_sub_throughput,
};
use p3_field_testing::{benchmark_dot_array, benchmark_exp_const};
use p3_util::pretty_name;
use rand::rngs::SmallRng;
use rand::{RngExt, SeedableRng};

type F = BabyBear;

fn bench_field(c: &mut Criterion) {
    let name = "BabyBear";
    const REPS: usize = 1000;
    benchmark_inv::<F>(c, name);
    // `BabyBear::try_sqrt` is an inherent method (the two-adic specialization), so
    // it must be benchmarked through the concrete type rather than the generic
    // `benchmark_sqrt` helper, which would resolve to the slower trait default.
    {
        let mut rng = SmallRng::seed_from_u64(1);
        let x = rng.random::<F>().square();
        c.bench_function("BabyBear sqrt", |b| {
            b.iter(|| black_box(black_box(x).try_sqrt()));
        });
    }
    benchmark_iter_sum::<F, 4, REPS>(c, name);
    benchmark_iter_sum::<F, 8, REPS>(c, name);
    benchmark_iter_sum::<F, 12, REPS>(c, name);

    benchmark_dot_array::<F, 2>(c, name);
    benchmark_dot_array::<F, 3>(c, name);
    benchmark_dot_array::<F, 4>(c, name);
    benchmark_dot_array::<F, 5>(c, name);
    benchmark_dot_array::<F, 6>(c, name);
    benchmark_dot_array::<F, 7>(c, name);
    benchmark_dot_array::<F, 8>(c, name);
    benchmark_dot_array::<F, 9>(c, name);
    benchmark_dot_array::<F, 16>(c, name);
    benchmark_dot_array::<F, 64>(c, name);

    // Note that each round of throughput has 10 operations
    // So we should have 10 * more repetitions for latency tests.
    const L_REPS: usize = 10 * REPS;
    benchmark_add_latency::<F, L_REPS>(c, name);
    benchmark_add_throughput::<F, REPS>(c, name);
    benchmark_sub_latency::<F, L_REPS>(c, name);
    benchmark_sub_throughput::<F, REPS>(c, name);
    benchmark_mul_latency::<F, L_REPS>(c, name);
    benchmark_mul_throughput::<F, REPS>(c, name);

    benchmark_chunked_linear_combination::<F, F, 100>(c, name);

    let mut rng = SmallRng::seed_from_u64(1);
    c.bench_function("7th_root", |b| {
        b.iter_batched(
            || rng.random::<F>(),
            |x| x.exp_u64(1725656503),
            BatchSize::SmallInput,
        );
    });
}

fn bench_packedfield(c: &mut Criterion) {
    let name = pretty_name::<<F as Field>::Packing>();
    // Note that each round of throughput has 10 operations
    // So we should have 10 * more repetitions for latency tests.
    const REPS: usize = 100;
    const L_REPS: usize = 10 * REPS;

    benchmark_add_latency::<<F as Field>::Packing, L_REPS>(c, &name);
    benchmark_add_throughput::<<F as Field>::Packing, REPS>(c, &name);
    benchmark_sub_latency::<<F as Field>::Packing, L_REPS>(c, &name);
    benchmark_sub_throughput::<<F as Field>::Packing, REPS>(c, &name);
    benchmark_mul_latency::<<F as Field>::Packing, L_REPS>(c, &name);
    benchmark_mul_throughput::<<F as Field>::Packing, REPS>(c, &name);

    const EXP_REPS: usize = 1000;
    benchmark_exp_const::<<F as Field>::Packing, 3, EXP_REPS>(c, &name);
    benchmark_exp_const::<<F as Field>::Packing, 4, EXP_REPS>(c, &name);
    benchmark_exp_const::<<F as Field>::Packing, 5, EXP_REPS>(c, &name);
    benchmark_exp_const::<<F as Field>::Packing, 7, EXP_REPS>(c, &name);

    type PF = <F as Field>::Packing;
    benchmark_chunked_linear_combination::<F, PF, 100>(c, &name);

    // Delayed-reduction dot products, with `4` as the control.
    // Lengths `5` to `8` each pay one Montgomery reduction.
    benchmark_dot_array::<PF, 4>(c, &name);
    benchmark_dot_array::<PF, 5>(c, &name);
    benchmark_dot_array::<PF, 6>(c, &name);
    benchmark_dot_array::<PF, 7>(c, &name);
    benchmark_dot_array::<PF, 8>(c, &name);
    benchmark_dot_array::<PF, 64>(c, &name);
}

criterion_group!(baby_bear_arithmetic, bench_field, bench_packedfield);
criterion_main!(baby_bear_arithmetic);
